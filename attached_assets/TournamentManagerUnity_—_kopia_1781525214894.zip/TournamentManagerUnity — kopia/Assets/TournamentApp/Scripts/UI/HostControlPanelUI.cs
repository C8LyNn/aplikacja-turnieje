using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class HostControlPanelUI
    {
        public static void Render(Transform parent, TournamentManager manager, string activeView, System.Action<string> switchView)
        {
            GameObject row = UIFactory.CreateRow(parent, "HostControls", 4);
            row.GetComponent<HorizontalLayoutGroup>().childForceExpandWidth = false;

            string selectedView = string.IsNullOrWhiteSpace(activeView) ? "current" : activeView;
            TournamentThemePalette theme = TournamentThemeManager.Current;
            Color activeColor = theme.ActiveColor;
            Color normalColor = theme.ButtonPrimaryColor;

            CreateViewButton(row.transform, "Prowadzenie", "current", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Wyniki", "results", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Drabinka", "bracket", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Schemat", "bracketMap", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Tabela", "standings", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Korekta bledow", "correction", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Widok dla widzow", "viewer", selectedView, switchView, activeColor, normalColor);
            CreateViewButton(row.transform, "Dane", "data", selectedView, switchView, activeColor, normalColor);
        }

        private static void CreateViewButton(
            Transform parent,
            string label,
            string view,
            string selectedView,
            System.Action<string> switchView,
            Color activeColor,
            Color normalColor)
        {
            bool isSelected = selectedView == view;
            Button button = UIFactory.CreateButton(
                parent,
                label,
                () => switchView(view),
                isSelected ? activeColor : normalColor
            );

            Text text = button.GetComponentInChildren<Text>();
            if (text != null && isSelected)
            {
                text.color = TournamentThemeManager.TextForBackground(activeColor);
                text.fontStyle = FontStyle.Bold;
                text.fontSize = 17;
            }
        }
    }
}
