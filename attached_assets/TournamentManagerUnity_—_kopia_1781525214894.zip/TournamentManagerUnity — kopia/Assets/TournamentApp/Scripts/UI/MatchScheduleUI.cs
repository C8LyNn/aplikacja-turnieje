using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class MatchScheduleUI
    {
        public static void Render(Transform parent, TournamentManager manager, bool admin)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Wyniki i harmonogram", 24, FontStyle.Bold);
            RenderQueueSummary(parent, manager, tournament);
            RenderSection(parent, manager, "Aktualnie grane", manager.Schedule.GetLiveMatches(tournament), admin);
            RenderSection(parent, manager, "Nastepne mecze", manager.Schedule.GetNextMatches(tournament, 20), admin);
            RenderSection(parent, manager, "Poprzednie mecze", manager.Schedule.GetPreviousMatches(tournament, 20), admin);
        }

        private static void RenderQueueSummary(Transform parent, TournamentManager manager, Tournament tournament)
        {
            GameObject panel = UIFactory.CreatePanel(parent, "QueueSummary", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minWidth = 860;
            layout.preferredWidth = 980;
            layout.minHeight = 128;
            layout.preferredHeight = 148;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 10, 10);
            vertical.spacing = 5;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Match current = manager.GetCurrentMatch();
            string currentLine = current == null
                ? "Teraz grany: brak wybranego meczu"
                : "Teraz grany: " + TournamentUIText.ParticipantName(tournament, current.participantAId) + " vs " + TournamentUIText.ParticipantName(tournament, current.participantBId) + " | Status: " + TournamentUIText.Status(current.status);
            UIFactory.CreateText(panel.transform, "Current", currentLine, 16, FontStyle.Bold);

            List<Match> nextMatches = manager.Schedule.GetNextMatches(tournament, 3);
            if (nextMatches.Count == 0)
            {
                UIFactory.CreateText(panel.transform, "NextEmpty", "Nastepne: brak meczow w kolejce.", 14);
                return;
            }

            UIFactory.CreateText(panel.transform, "NextTitle", "Nastepne:", 14, FontStyle.Bold);
            for (int i = 0; i < nextMatches.Count; i++)
            {
                Match match = nextMatches[i];
                UIFactory.CreateText(
                    panel.transform,
                    "Next" + i,
                    (i + 1) + ". " + TournamentUIText.RoundMatchLabel(tournament, match) + " - " + TournamentUIText.ParticipantName(tournament, match.participantAId) + " vs " + TournamentUIText.ParticipantName(tournament, match.participantBId) + " (" + TournamentUIText.Status(match.status) + ")",
                    13
                );
            }
        }

        private static void RenderSection(Transform parent, TournamentManager manager, string title, List<Match> matches, bool admin)
        {
            UIFactory.CreateText(parent, title, title, 18, FontStyle.Bold);
            if (matches == null || matches.Count == 0)
            {
                UIFactory.CreateText(parent, title + "Empty", "Brak meczow.", 14);
                return;
            }

            Tournament tournament = manager.CurrentTournament;
            for (int i = 0; i < matches.Count; i++)
            {
                Match match = matches[i];
                GameObject row = UIFactory.CreatePanel(parent, "ScheduleRow", new Color(0.1f, 0.13f, 0.19f, 1f));
                LayoutElement rowLayout = row.AddComponent<LayoutElement>();
                rowLayout.minWidth = 860;
                rowLayout.preferredWidth = 980;
                rowLayout.minHeight = admin ? 96 : 74;
                rowLayout.preferredHeight = admin ? 104 : 78;

                VerticalLayoutGroup vertical = row.AddComponent<VerticalLayoutGroup>();
                vertical.padding = new RectOffset(10, 10, 8, 8);
                vertical.spacing = 4;
                vertical.childControlWidth = true;
                vertical.childControlHeight = true;

                Text label = UIFactory.CreateText(
                    row.transform,
                    "Label",
                    "#" + (i + 1) + "  " + TournamentUIText.RoundMatchLabel(tournament, match) + "\n" +
                    TournamentUIText.ParticipantName(tournament, match.participantAId) + " vs " + TournamentUIText.ParticipantName(tournament, match.participantBId) +
                    "\nStatus: " + TournamentUIText.Status(match.status),
                    14,
                    FontStyle.Bold
                );
                label.color = TournamentUIText.StatusColor(match.status, tournament.currentMatchId == match.id);

                if (admin)
                {
                    GameObject actions = UIFactory.CreateRow(row.transform, "Actions", 6);
                    UIFactory.CreateButton(actions.transform, "Ustaw jako aktualny", () => manager.SetCurrentMatch(match.id), new Color(0.18f, 0.34f, 0.62f, 1f));
                    UIFactory.CreateButton(actions.transform, "Przesun wyzej", () => manager.MoveMatch(match.id, -1), new Color(0.17f, 0.23f, 0.34f, 1f));
                    UIFactory.CreateButton(actions.transform, "Przesun nizej", () => manager.MoveMatch(match.id, 1), new Color(0.17f, 0.23f, 0.34f, 1f));
                }
            }
        }
    }
}
