using System.Linq;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class AudienceViewUI
    {
        public static void Render(Transform parent, TournamentManager manager)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 28, FontStyle.Bold, TextAnchor.MiddleCenter);
                return;
            }

            Match match = manager.GetCurrentMatch();
            UIFactory.CreateText(parent, "Title", tournament.tournamentName.ToUpperInvariant(), 42, FontStyle.Bold, TextAnchor.MiddleCenter);

            if (match == null)
            {
                UIFactory.CreateText(parent, "NoMatch", "Brak aktualnego meczu", 34, FontStyle.Bold, TextAnchor.MiddleCenter);
                return;
            }

            UIFactory.CreateText(parent, "Meta", TournamentUIText.RoundMatchLabel(tournament, match).ToUpperInvariant(), 24, FontStyle.Bold, TextAnchor.MiddleCenter);

            GameObject scorePanel = UIFactory.CreatePanel(parent, "AudienceScorePanel", new Color(0.07f, 0.09f, 0.14f, 1f));
            LayoutElement scoreLayoutElement = scorePanel.AddComponent<LayoutElement>();
            scoreLayoutElement.minWidth = 1080;
            scoreLayoutElement.preferredWidth = 1280;
            scoreLayoutElement.minHeight = 260;
            scoreLayoutElement.preferredHeight = 300;

            HorizontalLayoutGroup row = scorePanel.AddComponent<HorizontalLayoutGroup>();
            row.padding = new RectOffset(24, 24, 22, 22);
            row.spacing = 24;
            row.childAlignment = TextAnchor.MiddleCenter;
            row.childControlWidth = true;
            row.childControlHeight = true;
            row.childForceExpandWidth = true;
            row.childForceExpandHeight = false;

            AddPlayer(scorePanel.transform, TournamentUIText.ParticipantName(tournament, match.participantAId));
            Text score = UIFactory.CreateText(scorePanel.transform, "Score", match.scoreA + " : " + match.scoreB, 68, FontStyle.Bold, TextAnchor.MiddleCenter);
            LayoutElement scoreElement = score.gameObject.AddComponent<LayoutElement>();
            scoreElement.minWidth = 260;
            scoreElement.preferredWidth = 300;
            AddPlayer(scorePanel.transform, TournamentUIText.ParticipantName(tournament, match.participantBId));

            Text status = UIFactory.CreateText(parent, "Status", "Status: " + TournamentUIText.Status(match.status), 22, FontStyle.Bold, TextAnchor.MiddleCenter);
            status.color = TournamentUIText.StatusColor(match.status, tournament.currentMatchId == match.id);

            Match next = manager.Schedule.GetNextMatches(tournament, 3).FirstOrDefault(candidate => candidate.id != match.id);
            string nextText = next == null
                ? "Nastepny mecz: brak"
                : "Nastepny mecz: " + TournamentUIText.ParticipantName(tournament, next.participantAId) + " vs " + TournamentUIText.ParticipantName(tournament, next.participantBId);
            UIFactory.CreateText(parent, "NextMatch", nextText, 20, FontStyle.Bold, TextAnchor.MiddleCenter);
        }

        private static void AddPlayer(Transform parent, string name)
        {
            Text player = UIFactory.CreateText(parent, "Player", name.ToUpperInvariant(), 34, FontStyle.Bold, TextAnchor.MiddleCenter);
            LayoutElement layout = player.gameObject.AddComponent<LayoutElement>();
            layout.minWidth = 360;
            layout.preferredWidth = 420;
            layout.minHeight = 150;
            layout.preferredHeight = 180;
        }
    }
}
