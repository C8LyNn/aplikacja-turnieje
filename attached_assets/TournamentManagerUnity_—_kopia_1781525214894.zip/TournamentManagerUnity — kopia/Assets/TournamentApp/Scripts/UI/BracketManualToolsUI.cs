using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace TournamentApp.UI
{
    public static class BracketManualToolsUI
    {
        public static void Render(Transform parent, TournamentManager manager)
        {
            Tournament tournament = manager == null ? null : manager.CurrentTournament;
            if (tournament == null)
            {
                return;
            }

            GameObject panel = UIFactory.CreatePanel(parent, "BracketManualTools", new Color(0.055f, 0.07f, 0.105f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minHeight = 122;
            panelLayout.preferredHeight = 136;
            panelLayout.flexibleWidth = 1f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(8, 8, 6, 6);
            vertical.spacing = 5;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            GameObject row = UIFactory.CreateRow(panel.transform, "ManualActions", 6);
            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.minHeight = 34;
            rowLayout.preferredHeight = 36;
            rowLayout.flexibleWidth = 1f;

            string heldName = string.IsNullOrEmpty(manager.HeldBracketParticipantId)
                ? "Przenoszenie: przytrzymaj gracza i przeciagnij"
                : "Neutralny slot: " + TournamentLookup.ParticipantName(tournament, manager.HeldBracketParticipantId);

            Text neutral = UIFactory.CreateText(row.transform, "NeutralSlot", heldName, 15, FontStyle.Bold, TextAnchor.MiddleCenter);
            neutral.color = string.IsNullOrEmpty(manager.HeldBracketParticipantId)
                ? new Color(1f, 1f, 1f, 0.72f)
                : new Color(1f, 0.82f, 0.24f, 1f);

            LayoutElement neutralLayout = neutral.gameObject.AddComponent<LayoutElement>();
            neutralLayout.minWidth = 300;
            neutralLayout.preferredWidth = 380;
            neutralLayout.preferredHeight = 34;

            if (!string.IsNullOrEmpty(manager.HeldBracketParticipantId))
            {
                Button clearButton = UIFactory.CreateButton(row.transform, "Wyczysc neutralny", () => manager.ClearHeldBracketParticipant(), new Color(0.12f, 0.16f, 0.24f, 1f));
                AddLayout(clearButton.gameObject, 160f, 34f);

                Button dqHeld = UIFactory.CreateButton(row.transform, "DQ neutralny", () => manager.DisqualifyParticipant(manager.HeldBracketParticipantId), new Color(0.62f, 0.22f, 0.18f, 1f));
                AddLayout(dqHeld.gameObject, 130f, 34f);
            }

            Button rerollButton = UIFactory.CreateButton(row.transform, "Losuj ponownie", () => manager.RandomizeCurrentBracketParticipants(), new Color(0.18f, 0.34f, 0.62f, 1f));
            AddLayout(rerollButton.gameObject, 150f, 34f);

            RenderLobby(panel.transform, manager, tournament);
            RenderDisqualified(panel.transform, manager, tournament);
        }

        private static void RenderLobby(Transform parent, TournamentManager manager, Tournament tournament)
        {
            GameObject lobby = UIFactory.CreatePanel(parent, "BracketLobbyDropZone", new Color(0.08f, 0.1f, 0.15f, 1f));
            LayoutElement lobbyLayout = lobby.AddComponent<LayoutElement>();
            lobbyLayout.minHeight = 40;
            lobbyLayout.preferredHeight = 42;
            lobbyLayout.flexibleWidth = 1f;

            BracketParticipantDropZone dropZone = lobby.AddComponent<BracketParticipantDropZone>();
            dropZone.ConfigureLobby(manager);

            HorizontalLayoutGroup row = lobby.AddComponent<HorizontalLayoutGroup>();
            row.padding = new RectOffset(8, 8, 4, 4);
            row.spacing = 6;
            row.childControlWidth = true;
            row.childControlHeight = true;
            row.childForceExpandWidth = false;
            row.childForceExpandHeight = false;

            Text title = UIFactory.CreateText(lobby.transform, "LobbyTitle", "Lobby:", 14, FontStyle.Bold, TextAnchor.MiddleLeft);
            title.color = new Color(1f, 0.82f, 0.24f, 1f);
            AddLayout(title.gameObject, 58f, 32f);

            List<string> lobbyIds = manager.GetCurrentBracketLobbyParticipantIds();
            if (lobbyIds.Count == 0)
            {
                Text empty = UIFactory.CreateText(lobby.transform, "EmptyLobby", "przeciagnij tutaj gracza, zeby zdjac go z drabinki", 13, FontStyle.Normal, TextAnchor.MiddleLeft);
                empty.color = new Color(1f, 1f, 1f, 0.58f);
                AddLayout(empty.gameObject, 420f, 32f);
                return;
            }

            int shown = Mathf.Min(lobbyIds.Count, 9);
            for (int i = 0; i < shown; i++)
            {
                string participantId = lobbyIds[i];
                CreateLobbyChip(lobby.transform, manager, tournament, participantId);
            }

            if (lobbyIds.Count > shown)
            {
                Text more = UIFactory.CreateText(lobby.transform, "MoreLobby", "+" + (lobbyIds.Count - shown), 13, FontStyle.Bold, TextAnchor.MiddleCenter);
                more.color = new Color(1f, 1f, 1f, 0.72f);
                AddLayout(more.gameObject, 44f, 32f);
            }
        }

        private static void RenderDisqualified(Transform parent, TournamentManager manager, Tournament tournament)
        {
            List<string> disqualifiedIds = manager.GetDisqualifiedParticipantIds();
            if (disqualifiedIds.Count == 0)
            {
                return;
            }

            GameObject row = UIFactory.CreateRow(parent, "DisqualifiedPlayers", 6);
            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.minHeight = 32;
            rowLayout.preferredHeight = 34;

            Text title = UIFactory.CreateText(row.transform, "DQTitle", "DQ:", 13, FontStyle.Bold, TextAnchor.MiddleLeft);
            title.color = new Color(1f, 0.46f, 0.40f, 1f);
            AddLayout(title.gameObject, 38f, 30f);

            int shown = Mathf.Min(disqualifiedIds.Count, 6);
            for (int i = 0; i < shown; i++)
            {
                string participantId = disqualifiedIds[i];
                Button button = UIFactory.CreateButton(
                    row.transform,
                    TournamentLookup.ParticipantName(tournament, participantId) + " - cofnij",
                    () => manager.ReinstateParticipant(participantId),
                    new Color(0.22f, 0.14f, 0.14f, 1f)
                );
                AddLayout(button.gameObject, 150f, 30f);
                Text label = button.GetComponentInChildren<Text>();
                if (label != null)
                {
                    label.fontSize = 11;
                }
            }
        }

        private static void CreateLobbyChip(Transform parent, TournamentManager manager, Tournament tournament, string participantId)
        {
            GameObject chip = UIFactory.CreatePanel(parent, "LobbyChip", new Color(0.13f, 0.18f, 0.30f, 1f));
            AddLayout(chip, 150f, 32f);

            HorizontalLayoutGroup row = chip.AddComponent<HorizontalLayoutGroup>();
            row.padding = new RectOffset(6, 4, 3, 3);
            row.spacing = 4;
            row.childControlWidth = true;
            row.childControlHeight = true;
            row.childForceExpandWidth = false;
            row.childForceExpandHeight = false;

            string name = TournamentLookup.ParticipantName(tournament, participantId);
            Text label = UIFactory.CreateText(chip.transform, "Name", ShortName(name), 12, FontStyle.Bold, TextAnchor.MiddleLeft);
            label.color = Color.white;
            AddLayout(label.gameObject, 88f, 26f);

            BracketParticipantDragItem drag = chip.AddComponent<BracketParticipantDragItem>();
            drag.Configure(participantId, string.Empty, MatchSlot.A, false, name);

            Button dq = UIFactory.CreateButton(chip.transform, "DQ", () => manager.DisqualifyParticipant(participantId), new Color(0.62f, 0.22f, 0.18f, 1f));
            AddLayout(dq.gameObject, 42f, 26f);
            Text dqText = dq.GetComponentInChildren<Text>();
            if (dqText != null)
            {
                dqText.fontSize = 11;
            }
        }

        private static string ShortName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "TBD";
            }

            return value.Length <= 12 ? value : value.Substring(0, 11) + ".";
        }

        private static void AddLayout(GameObject target, float width, float height)
        {
            LayoutElement layout = target.GetComponent<LayoutElement>();
            if (layout == null)
            {
                layout = target.AddComponent<LayoutElement>();
            }

            layout.minWidth = width;
            layout.preferredWidth = width;
            layout.minHeight = height;
            layout.preferredHeight = height;
        }
    }
}
