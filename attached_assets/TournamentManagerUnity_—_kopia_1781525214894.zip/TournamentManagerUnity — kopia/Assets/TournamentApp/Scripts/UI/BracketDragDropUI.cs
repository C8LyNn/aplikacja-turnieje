using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public class BracketParticipantDragItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        public static string DraggedParticipantId { get; private set; }
        public static string SourceMatchId { get; private set; }
        public static MatchSlot SourceSlot { get; private set; }
        public static bool HasSourceSlot { get; private set; }

        private string participantId;
        private string sourceMatchId;
        private MatchSlot sourceSlot;
        private bool hasSourceSlot;
        private string label;
        private GameObject ghost;

        public void Configure(string participantId, string sourceMatchId, MatchSlot sourceSlot, bool hasSourceSlot, string label)
        {
            this.participantId = participantId;
            this.sourceMatchId = sourceMatchId;
            this.sourceSlot = sourceSlot;
            this.hasSourceSlot = hasSourceSlot;
            this.label = label;
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (string.IsNullOrEmpty(participantId))
            {
                return;
            }

            DraggedParticipantId = participantId;
            SourceMatchId = sourceMatchId;
            SourceSlot = sourceSlot;
            HasSourceSlot = hasSourceSlot;

            Canvas canvas = GetComponentInParent<Canvas>();
            if (canvas == null)
            {
                return;
            }

            ghost = UIFactory.CreatePanel(canvas.transform, "DraggedParticipant", new Color(0.98f, 0.78f, 0.20f, 0.94f));
            RectTransform ghostRect = ghost.GetComponent<RectTransform>();
            ghostRect.sizeDelta = new Vector2(190f, 42f);
            ghostRect.position = eventData.position;

            CanvasGroup group = ghost.AddComponent<CanvasGroup>();
            group.blocksRaycasts = false;

            Text text = UIFactory.CreateText(ghost.transform, "Label", label, 16, FontStyle.Bold, TextAnchor.MiddleCenter);
            text.color = new Color(0.03f, 0.04f, 0.07f, 1f);
            UIFactory.Stretch(text.rectTransform, 6, 3, 6, 3);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (ghost != null)
            {
                ghost.GetComponent<RectTransform>().position = eventData.position;
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (ghost != null)
            {
                Destroy(ghost);
            }

            DraggedParticipantId = string.Empty;
            SourceMatchId = string.Empty;
            HasSourceSlot = false;
        }
    }

    public class BracketParticipantDropZone : MonoBehaviour, IDropHandler
    {
        private TournamentManager manager;
        private bool lobby;
        private string matchId;
        private MatchSlot slot;

        public void ConfigureSlot(TournamentManager manager, string matchId, MatchSlot slot)
        {
            this.manager = manager;
            this.matchId = matchId;
            this.slot = slot;
            lobby = false;
        }

        public void ConfigureLobby(TournamentManager manager)
        {
            this.manager = manager;
            lobby = true;
            matchId = string.Empty;
        }

        public void OnDrop(PointerEventData eventData)
        {
            string participantId = BracketParticipantDragItem.DraggedParticipantId;
            if (manager == null || string.IsNullOrEmpty(participantId))
            {
                return;
            }

            if (lobby)
            {
                manager.MoveBracketParticipantToLobby(participantId);
                return;
            }

            manager.MoveBracketParticipantToSlot(
                participantId,
                matchId,
                slot,
                BracketParticipantDragItem.HasSourceSlot ? BracketParticipantDragItem.SourceMatchId : string.Empty,
                BracketParticipantDragItem.SourceSlot
            );
        }
    }
}
