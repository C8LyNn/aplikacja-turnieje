using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class CurrentMatchViewUI
    {
        public static void Render(Transform parent, TournamentManager manager, bool broadcast)
        {
            if (broadcast)
            {
                AudienceViewUI.Render(parent, manager);
                return;
            }

            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 22, FontStyle.Bold, TextAnchor.MiddleCenter);
                return;
            }

            Match match = manager.GetCurrentMatch();
            RenderHostCurrentMatch(parent, manager, tournament, match);
        }

        private static void RenderHostCurrentMatch(Transform parent, TournamentManager manager, Tournament tournament, Match match)
        {
            ConfigureParent(parent);

            GameObject screen = UIFactory.CreatePanel(parent, "CurrentMatchScreen", Color.clear);
            LayoutElement screenLayout = screen.AddComponent<LayoutElement>();
            screenLayout.minWidth = 1320;
            screenLayout.preferredWidth = 1620;
            screenLayout.minHeight = 660;
            screenLayout.preferredHeight = 740;
            screenLayout.flexibleWidth = 1f;
            screenLayout.flexibleHeight = 1f;

            VerticalLayoutGroup screenVertical = screen.AddComponent<VerticalLayoutGroup>();
            screenVertical.padding = new RectOffset(18, 18, 16, 10);
            screenVertical.spacing = 10;
            screenVertical.childAlignment = TextAnchor.UpperCenter;
            screenVertical.childControlWidth = true;
            screenVertical.childControlHeight = true;
            screenVertical.childForceExpandWidth = false;
            screenVertical.childForceExpandHeight = false;

            UIFactory.CreateText(screen.transform, "Title", "AKTUALNY MECZ", 34, FontStyle.Bold, TextAnchor.MiddleCenter);
            UIFactory.CreateText(screen.transform, "Tournament", tournament.tournamentName, 22, FontStyle.Bold, TextAnchor.MiddleCenter);

            if (match == null)
            {
                UIFactory.CreateText(screen.transform, "NoMatch", "Nie wybrano aktualnego meczu.", 22, FontStyle.Bold, TextAnchor.MiddleCenter);
                UIFactory.CreateButton(screen.transform, "Wybierz nastepny mecz", () => manager.SelectNextPlayableMatch());
                return;
            }

            Text meta = UIFactory.CreateText(screen.transform, "Meta", TournamentUIText.RoundMatchLabel(tournament, match) + "   |   BO" + match.bestOf, 20, FontStyle.Bold, TextAnchor.MiddleCenter);
            meta.color = new Color(1f, 1f, 1f, 0.84f);

            Text status = UIFactory.CreateText(screen.transform, "Status", "Status: " + TournamentUIText.Status(match.status), 20, FontStyle.Bold, TextAnchor.MiddleCenter);
            status.color = TournamentUIText.StatusColor(match.status, tournament.currentMatchId == match.id);

            GameObject spacer = new GameObject("CurrentMatchSpacer", typeof(RectTransform));
            spacer.transform.SetParent(screen.transform, false);
            LayoutElement spacerLayout = spacer.AddComponent<LayoutElement>();
            spacerLayout.preferredHeight = 32f;

            GameObject scorePanel = UIFactory.CreatePanel(screen.transform, "CurrentMatchScorePanel", new Color(0.09f, 0.12f, 0.18f, 1f));
            LayoutElement scoreLayoutElement = scorePanel.AddComponent<LayoutElement>();
            scoreLayoutElement.minWidth = 1220;
            scoreLayoutElement.preferredWidth = 1440;
            scoreLayoutElement.minHeight = 295;
            scoreLayoutElement.preferredHeight = 320;

            VerticalLayoutGroup scoreVertical = scorePanel.AddComponent<VerticalLayoutGroup>();
            scoreVertical.padding = new RectOffset(26, 26, 24, 24);
            scoreVertical.spacing = 18;
            scoreVertical.childAlignment = TextAnchor.MiddleCenter;
            scoreVertical.childControlWidth = true;
            scoreVertical.childControlHeight = true;
            scoreVertical.childForceExpandWidth = false;
            scoreVertical.childForceExpandHeight = false;

            GameObject scoreRow = UIFactory.CreateRow(scorePanel.transform, "ScoreRow", 16);
            scoreRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            AddFixedLayout(scoreRow, 1360, 116);

            AddPlayerName(scoreRow.transform, TournamentUIText.ParticipantName(tournament, match.participantAId), match.participantAId == match.winnerId);
            AddScore(scoreRow.transform, match.scoreA.ToString());
            Text separator = UIFactory.CreateText(scoreRow.transform, "Separator", ":", 42, FontStyle.Bold, TextAnchor.MiddleCenter);
            AddFixedLayout(separator.gameObject, 34, 104);
            AddScore(scoreRow.transform, match.scoreB.ToString());
            AddPlayerName(scoreRow.transform, TournamentUIText.ParticipantName(tournament, match.participantBId), match.participantBId == match.winnerId);

            GameObject adjustRow = UIFactory.CreateRow(scorePanel.transform, "AdjustRow", 8);
            adjustRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            AddFixedLayout(adjustRow, 1360, 54);

            CreateScoreButton(adjustRow.transform, "+1 " + ShortName(tournament, match.participantAId), () => manager.AdjustMatchScore(match.id, MatchSlot.A, 1));
            CreateScoreButton(adjustRow.transform, "-1 " + ShortName(tournament, match.participantAId), () => manager.AdjustMatchScore(match.id, MatchSlot.A, -1), new Color(0.17f, 0.23f, 0.34f, 1f));
            CreateScoreButton(adjustRow.transform, "+1 " + ShortName(tournament, match.participantBId), () => manager.AdjustMatchScore(match.id, MatchSlot.B, 1));
            CreateScoreButton(adjustRow.transform, "-1 " + ShortName(tournament, match.participantBId), () => manager.AdjustMatchScore(match.id, MatchSlot.B, -1), new Color(0.17f, 0.23f, 0.34f, 1f));

            GameObject actionRow = UIFactory.CreateRow(screen.transform, "CurrentMatchActions", 10);
            actionRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;

            UIFactory.CreateButton(actionRow.transform, "Zatwierdz wynik", () => manager.SubmitCurrentMatchResult(), new Color(0.18f, 0.48f, 0.28f, 1f));
            UIFactory.CreateButton(actionRow.transform, "Nastepny mecz", () => manager.SelectNextPlayableMatch(), new Color(0.18f, 0.34f, 0.62f, 1f));

            GameObject walkoverRow = UIFactory.CreateRow(screen.transform, "WalkoverActions", 8);
            walkoverRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            UIFactory.CreateButton(walkoverRow.transform, "Walkower A: nieobecny", () => manager.AssignWalkover(match.id, MatchSlot.A, "przeciwnik nieobecny"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower B: nieobecny", () => manager.AssignWalkover(match.id, MatchSlot.B, "przeciwnik nieobecny"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower A: decyzja admina", () => manager.AssignWalkover(match.id, MatchSlot.A, "decyzja admina"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower B: decyzja admina", () => manager.AssignWalkover(match.id, MatchSlot.B, "decyzja admina"), new Color(0.38f, 0.24f, 0.62f, 1f));

            Text hint = UIFactory.CreateText(screen.transform, "Hint", GetMatchInfoText(tournament, match), 18, FontStyle.Bold, TextAnchor.MiddleCenter);
            hint.color = new Color(1f, 1f, 1f, 0.78f);
        }

        private static void ConfigureParent(Transform parent)
        {
            VerticalLayoutGroup parentLayout = parent.GetComponent<VerticalLayoutGroup>();
            if (parentLayout == null)
            {
                return;
            }

            parentLayout.childAlignment = TextAnchor.UpperCenter;
            parentLayout.childForceExpandWidth = false;
            parentLayout.childControlWidth = true;
            parentLayout.spacing = 4;
        }

        private static void AddPlayerName(Transform parent, string name, bool winner)
        {
            GameObject box = UIFactory.CreatePanel(parent, "PlayerName", winner ? new Color(0.18f, 0.48f, 0.28f, 1f) : new Color(0.18f, 0.23f, 0.34f, 1f));
            AddFixedLayout(box, 430, 104);
            Text text = UIFactory.CreateText(box.transform, "Label", name, 34, FontStyle.Bold, TextAnchor.MiddleCenter);
            UIFactory.Stretch(text.rectTransform, 8, 4, 8, 4);
        }

        private static void AddScore(Transform parent, string value)
        {
            GameObject box = UIFactory.CreatePanel(parent, "ScoreBox", new Color(0.035f, 0.05f, 0.08f, 1f));
            AddFixedLayout(box, 112, 104);
            Text text = UIFactory.CreateText(box.transform, "Score", value, 58, FontStyle.Bold, TextAnchor.MiddleCenter);
            UIFactory.Stretch(text.rectTransform, 4, 2, 4, 2);
        }

        private static void CreateScoreButton(Transform parent, string label, UnityEngine.Events.UnityAction action, Color? color = null)
        {
            Button button = UIFactory.CreateButton(parent, label, action, color ?? new Color(0.18f, 0.48f, 0.28f, 1f));
            AddFixedLayout(button.gameObject, 245, 48);
        }

        private static void AddFixedLayout(GameObject target, float width, float height)
        {
            LayoutElement layout = target.GetComponent<LayoutElement>();
            if (layout == null)
            {
                layout = target.AddComponent<LayoutElement>();
            }

            layout.minWidth = width;
            layout.preferredWidth = width;
            layout.minHeight = height;
            layout.preferredHeight = height;
        }

        private static string ShortName(Tournament tournament, string participantId)
        {
            string name = TournamentUIText.ParticipantName(tournament, participantId);
            return name.Length <= 14 ? name : name.Substring(0, 14);
        }

        private static string GetMatchInfoText(Tournament tournament, Match match)
        {
            if (match == null)
            {
                return "-";
            }

            if (!string.IsNullOrEmpty(match.winnerId))
            {
                return "Zwyciezca: " + TournamentUIText.ParticipantName(tournament, match.winnerId);
            }

            if (match.scoreA > match.scoreB)
            {
                return "Prowadzi: " + TournamentUIText.ParticipantName(tournament, match.participantAId);
            }

            if (match.scoreB > match.scoreA)
            {
                return "Prowadzi: " + TournamentUIText.ParticipantName(tournament, match.participantBId);
            }

            return "Mecz gotowy do rozegrania.";
        }
    }
}
