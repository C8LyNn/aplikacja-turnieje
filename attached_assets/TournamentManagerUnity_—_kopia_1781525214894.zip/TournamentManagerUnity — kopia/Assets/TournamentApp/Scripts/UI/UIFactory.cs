using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class UIFactory
    {
        private static Font cachedFont;

        public static Font DefaultFont
        {
            get
            {
                if (cachedFont == null)
                {
                    cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                    if (cachedFont == null)
                    {
                        cachedFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
                    }
                }

                return cachedFont;
            }
        }

        public static GameObject CreatePanel(Transform parent, string name, Color color)
        {
            GameObject panel = new GameObject(name, typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(parent, false);
            panel.GetComponent<Image>().color = TournamentThemeManager.ResolvePanelColor(name, color);
            return panel;
        }

        public static Text CreateText(Transform parent, string name, string value, int size, FontStyle style = FontStyle.Normal, TextAnchor alignment = TextAnchor.MiddleLeft)
        {
            GameObject textObject = new GameObject(name, typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(parent, false);

            Text text = textObject.GetComponent<Text>();
            text.text = value;
            text.font = DefaultFont;
            text.fontSize = size;
            text.fontStyle = style;
            text.alignment = alignment;
            text.color = TournamentThemeManager.Current.TextPrimaryColor;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;

            return text;
        }

        public static Button CreateButton(Transform parent, string label, UnityAction onClick, Color? color = null)
        {
            Color buttonColor = TournamentThemeManager.ResolveButtonColor(color);
            GameObject buttonObject = CreatePanel(parent, "Button_" + label, buttonColor);
            Button button = buttonObject.AddComponent<Button>();
            button.targetGraphic = buttonObject.GetComponent<Image>();

            Text text = CreateText(buttonObject.transform, "Label", label, 16, FontStyle.Bold, TextAnchor.MiddleCenter);
            text.color = TournamentThemeManager.TextForBackground(buttonColor);
            Stretch(text.rectTransform, 8, 4, 8, 4);

            button.onClick.AddListener(onClick);

            LayoutElement layout = buttonObject.AddComponent<LayoutElement>();
            layout.minHeight = 38;
            layout.preferredHeight = 42;
            layout.minWidth = 110;
            layout.preferredWidth = Mathf.Max(110f, label.Length * 11f + 28f);

            return button;
        }

        public static InputField CreateInput(Transform parent, string placeholder, string value = "")
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject inputObject = CreatePanel(parent, "Input_" + placeholder, theme.InputColor);
            InputField input = inputObject.AddComponent<InputField>();

            Text text = CreateText(inputObject.transform, "Text", value, 15, FontStyle.Normal, TextAnchor.MiddleLeft);
            Text placeholderText = CreateText(inputObject.transform, "Placeholder", placeholder, 15, FontStyle.Italic, TextAnchor.MiddleLeft);
            text.color = theme.TextPrimaryColor;
            placeholderText.color = TournamentThemeManager.WithAlpha(theme.TextSecondaryColor, 0.55f);

            Stretch(text.rectTransform, 10, 4, 10, 4);
            Stretch(placeholderText.rectTransform, 10, 4, 10, 4);

            input.textComponent = text;
            input.placeholder = placeholderText;
            input.text = value;

            LayoutElement layout = inputObject.AddComponent<LayoutElement>();
            layout.minHeight = 36;
            layout.preferredHeight = 38;
            layout.minWidth = 120;
            layout.preferredWidth = 320;

            return input;
        }

        public static InputField CreateLabeledInput(Transform parent, string label, string placeholder, string value = "", string helpText = "")
        {
            GameObject column = CreateColumn(parent, "LabeledInput_" + label, 4f);

            LayoutElement columnLayout = column.AddComponent<LayoutElement>();
            columnLayout.minWidth = 420;
            columnLayout.preferredWidth = 420;
            columnLayout.minHeight = string.IsNullOrWhiteSpace(helpText) ? 64 : 86;
            columnLayout.preferredHeight = string.IsNullOrWhiteSpace(helpText) ? 68 : 90;

            Text labelText = CreateText(column.transform, "Label", label, 15, FontStyle.Bold, TextAnchor.MiddleLeft);
            LayoutElement labelLayout = labelText.gameObject.AddComponent<LayoutElement>();
            labelLayout.minWidth = 420;
            labelLayout.preferredWidth = 420;
            labelLayout.preferredHeight = 20;

            InputField input = CreateInput(column.transform, placeholder, value);
            LayoutElement inputLayout = input.gameObject.GetComponent<LayoutElement>();
            if (inputLayout != null)
            {
                inputLayout.minWidth = 420;
                inputLayout.preferredWidth = 420;
            }

            if (!string.IsNullOrWhiteSpace(helpText))
            {
                Text help = CreateText(column.transform, "Help", helpText, 12, FontStyle.Normal, TextAnchor.MiddleLeft);
                help.color = TournamentThemeManager.Current.TextSecondaryColor;

                LayoutElement helpLayout = help.gameObject.AddComponent<LayoutElement>();
                helpLayout.minWidth = 420;
                helpLayout.preferredWidth = 420;
                helpLayout.preferredHeight = 18;
            }

            return input;
        }

        public static Toggle CreateToggle(Transform parent, string label, bool isOn)
        {
            GameObject row = new GameObject("Toggle_" + label, typeof(RectTransform));
            row.transform.SetParent(parent, false);

            HorizontalLayoutGroup horizontal = row.AddComponent<HorizontalLayoutGroup>();
            horizontal.spacing = 8;
            horizontal.childAlignment = TextAnchor.MiddleLeft;
            horizontal.childControlWidth = false;
            horizontal.childControlHeight = false;
            horizontal.childForceExpandWidth = false;
            horizontal.childForceExpandHeight = false;

            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.minHeight = 30;
            rowLayout.preferredHeight = 32;
            rowLayout.minWidth = 320;
            rowLayout.preferredWidth = 320;

            Toggle toggle = row.AddComponent<Toggle>();

            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject box = CreatePanel(row.transform, "Box", theme.InputColor);
            RectTransform boxRect = box.GetComponent<RectTransform>();
            boxRect.sizeDelta = new Vector2(24f, 24f);

            LayoutElement boxLayout = box.AddComponent<LayoutElement>();
            boxLayout.minWidth = 24;
            boxLayout.minHeight = 24;
            boxLayout.preferredWidth = 24;
            boxLayout.preferredHeight = 24;

            GameObject checkmark = CreatePanel(box.transform, "Checkmark", theme.SuccessColor);
            Stretch(checkmark.GetComponent<RectTransform>(), 5, 5, 5, 5);

            toggle.targetGraphic = box.GetComponent<Image>();
            toggle.graphic = checkmark.GetComponent<Image>();
            toggle.isOn = isOn;

            Text text = CreateText(row.transform, "Label", label, 15);
            LayoutElement textLayout = text.gameObject.AddComponent<LayoutElement>();
            textLayout.minWidth = 120;
            textLayout.preferredWidth = 220;
            textLayout.preferredHeight = 28;

            return toggle;
        }

        public static Transform CreateScrollContent(Transform parent, string name)
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject scroll = CreatePanel(parent, name, theme.BackgroundColor);
            ScrollRect scrollRect = scroll.AddComponent<ScrollRect>();
            scrollRect.horizontal = false;
            scrollRect.vertical = true;
            scrollRect.movementType = ScrollRect.MovementType.Clamped;
            scrollRect.scrollSensitivity = 45f;

            LayoutElement scrollLayout = scroll.AddComponent<LayoutElement>();
            scrollLayout.minHeight = 520f;
            scrollLayout.preferredHeight = 900f;
            scrollLayout.flexibleHeight = 1f;
            scrollLayout.flexibleWidth = 1f;

            GameObject viewport = CreatePanel(scroll.transform, "Viewport", Color.clear);
            viewport.AddComponent<RectMask2D>();
            Stretch(viewport.GetComponent<RectTransform>(), 0, 0, 18, 0);

            GameObject content = new GameObject("Content", typeof(RectTransform));
            content.transform.SetParent(viewport.transform, false);

            VerticalLayoutGroup vertical = content.AddComponent<VerticalLayoutGroup>();
            vertical.spacing = 8;
            vertical.padding = new RectOffset(12, 12, 12, 12);
            vertical.childControlHeight = true;
            vertical.childControlWidth = true;
            vertical.childForceExpandHeight = false;
            vertical.childForceExpandWidth = false;

            ContentSizeFitter fitter = content.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;

            RectTransform contentRect = content.GetComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0f, 1f);
            contentRect.anchorMax = new Vector2(1f, 1f);
            contentRect.pivot = new Vector2(0f, 1f);
            contentRect.anchoredPosition = Vector2.zero;
            contentRect.sizeDelta = new Vector2(0f, 0f);

            scrollRect.viewport = viewport.GetComponent<RectTransform>();
            scrollRect.content = contentRect;

            GameObject scrollbarObject = CreatePanel(scroll.transform, "VerticalScrollbar", theme.PanelSecondaryColor);
            RectTransform scrollbarRect = scrollbarObject.GetComponent<RectTransform>();
            scrollbarRect.anchorMin = new Vector2(1f, 0f);
            scrollbarRect.anchorMax = new Vector2(1f, 1f);
            scrollbarRect.pivot = new Vector2(1f, 0.5f);
            scrollbarRect.anchoredPosition = Vector2.zero;
            scrollbarRect.sizeDelta = new Vector2(16f, 0f);

            Scrollbar scrollbar = scrollbarObject.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.BottomToTop;

            GameObject slidingArea = new GameObject("Sliding Area", typeof(RectTransform));
            slidingArea.transform.SetParent(scrollbarObject.transform, false);
            Stretch(slidingArea.GetComponent<RectTransform>(), 2, 2, 2, 2);

            GameObject handle = CreatePanel(slidingArea.transform, "Handle", theme.ActiveColor);
            RectTransform handleRect = handle.GetComponent<RectTransform>();
            Stretch(handleRect);

            scrollbar.handleRect = handleRect;
            scrollbar.targetGraphic = handle.GetComponent<Image>();
            scrollbar.value = 1f;

            scrollRect.verticalScrollbar = scrollbar;
            scrollRect.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
            scrollRect.verticalNormalizedPosition = 1f;

            return content.transform;
        }

        public static GameObject CreateRow(Transform parent, string name, float spacing = 8f)
        {
            GameObject row = new GameObject(name, typeof(RectTransform));
            row.transform.SetParent(parent, false);

            HorizontalLayoutGroup horizontal = row.AddComponent<HorizontalLayoutGroup>();
            horizontal.spacing = spacing;
            horizontal.childControlWidth = true;
            horizontal.childControlHeight = true;
            horizontal.childForceExpandWidth = false;
            horizontal.childForceExpandHeight = false;

            ContentSizeFitter fitter = row.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            return row;
        }

        public static GameObject CreateColumn(Transform parent, string name, float spacing = 8f)
        {
            GameObject column = new GameObject(name, typeof(RectTransform));
            column.transform.SetParent(parent, false);

            VerticalLayoutGroup vertical = column.AddComponent<VerticalLayoutGroup>();
            vertical.spacing = spacing;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            ContentSizeFitter fitter = column.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            return column;
        }

        public static void Stretch(RectTransform rect, float left = 0, float top = 0, float right = 0, float bottom = 0)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }

        public static Color ColorFromHex(string hex, Color fallback)
        {
            Color parsed;
            if (!string.IsNullOrWhiteSpace(hex) && ColorUtility.TryParseHtmlString(hex, out parsed))
            {
                return parsed;
            }

            return fallback;
        }
    }
}
