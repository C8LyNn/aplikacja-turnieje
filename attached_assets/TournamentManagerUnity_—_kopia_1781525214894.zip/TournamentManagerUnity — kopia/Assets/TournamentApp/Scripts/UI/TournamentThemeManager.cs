using System.Collections.Generic;
using UnityEngine;

namespace TournamentApp.UI
{
    public enum TournamentThemeId
    {
        DarkBlue,
        DarkGold,
        LightClean,
        HighContrast
    }

    public sealed class TournamentThemePalette
    {
        public TournamentThemeId Id;
        public string DisplayName;
        public string Description;
        public Color BackgroundColor;
        public Color PanelColor;
        public Color PanelSecondaryColor;
        public Color HeaderColor;
        public Color InputColor;
        public Color ScoreBoxColor;
        public Color ButtonPrimaryColor;
        public Color ButtonSecondaryColor;
        public Color ButtonDangerColor;
        public Color ButtonTextColor;
        public Color TextPrimaryColor;
        public Color TextSecondaryColor;
        public Color BorderColor;
        public Color ActiveColor;
        public Color SuccessColor;
        public Color WarningColor;
        public Color ErrorColor;
        public Color MatchPendingColor;
        public Color MatchReadyColor;
        public Color MatchActiveColor;
        public Color MatchCompletedColor;
        public Color MatchProblemColor;
        public Color WalkoverColor;
    }

    public static class TournamentThemeManager
    {
        private const string PlayerPrefsKey = "TournamentTheme";
        private static Dictionary<TournamentThemeId, TournamentThemePalette> palettes;
        private static TournamentThemeId currentId;
        private static bool loaded;

        public static TournamentThemeId CurrentId
        {
            get
            {
                EnsureLoaded();
                return currentId;
            }
        }

        public static TournamentThemePalette Current
        {
            get
            {
                EnsureLoaded();
                return palettes[currentId];
            }
        }

        public static IEnumerable<TournamentThemePalette> AllPalettes
        {
            get
            {
                EnsureLoaded();
                return palettes.Values;
            }
        }

        public static void Select(TournamentThemeId id)
        {
            EnsurePalettes();
            currentId = palettes.ContainsKey(id) ? id : TournamentThemeId.DarkBlue;
            loaded = true;
            PlayerPrefs.SetString(PlayerPrefsKey, currentId.ToString());
            PlayerPrefs.Save();
        }

        public static Color ResolvePanelColor(string objectName, Color requested)
        {
            TournamentThemePalette theme = Current;
            if (requested.a <= 0.01f)
            {
                return requested;
            }

            if (!string.IsNullOrEmpty(objectName))
            {
                if (objectName.Contains("TopBar") || objectName.Contains("Header"))
                {
                    return theme.HeaderColor;
                }

                if (objectName.Contains("ScoreBox") || objectName.Contains("Input_"))
                {
                    return theme.ScoreBoxColor;
                }

                if (objectName.StartsWith("Button_"))
                {
                    return requested;
                }
            }

            if (IsClose(requested, 0.06f, 0.08f, 0.12f) || IsClose(requested, 0.055f, 0.07f, 0.105f) || IsClose(requested, 0.035f, 0.045f, 0.07f))
            {
                return theme.BackgroundColor;
            }

            if (IsClose(requested, 0.08f, 0.10f, 0.15f) || IsClose(requested, 0.08f, 0.11f, 0.16f) || IsClose(requested, 0.10f, 0.13f, 0.19f))
            {
                return theme.PanelColor;
            }

            if (IsClose(requested, 0.13f, 0.17f, 0.27f) || IsClose(requested, 0.13f, 0.18f, 0.30f) || IsClose(requested, 0.16f, 0.22f, 0.34f))
            {
                return theme.PanelSecondaryColor;
            }

            if (requested.a < 0.55f)
            {
                return requested;
            }

            return requested;
        }

        public static Color ResolveButtonColor(Color? requested)
        {
            TournamentThemePalette theme = Current;
            if (!requested.HasValue)
            {
                return theme.ButtonPrimaryColor;
            }

            Color color = requested.Value;
            if (color.a <= 0.01f)
            {
                return color;
            }

            if (color.r > 0.45f && color.g < 0.30f && color.b < 0.30f)
            {
                return theme.ButtonDangerColor;
            }

            if (color.g > color.r && color.g > color.b)
            {
                return theme.SuccessColor;
            }

            if (color.r > 0.75f && color.g > 0.55f && color.b < 0.35f)
            {
                return theme.ActiveColor;
            }

            if (color.b > color.r && color.b > color.g)
            {
                return theme.ButtonPrimaryColor;
            }

            return theme.ButtonSecondaryColor;
        }

        public static Color TextForBackground(Color background)
        {
            float luminance = background.r * 0.299f + background.g * 0.587f + background.b * 0.114f;
            return luminance > 0.58f ? new Color(0.04f, 0.05f, 0.07f, 1f) : Color.white;
        }

        public static Color WithAlpha(Color color, float alpha)
        {
            color.a = alpha;
            return color;
        }

        private static void EnsureLoaded()
        {
            EnsurePalettes();
            if (loaded)
            {
                return;
            }

            string saved = PlayerPrefs.GetString(PlayerPrefsKey, TournamentThemeId.DarkBlue.ToString());
            TournamentThemeId id;
            currentId = System.Enum.TryParse(saved, out id) && palettes.ContainsKey(id) ? id : TournamentThemeId.DarkBlue;
            loaded = true;
        }

        private static void EnsurePalettes()
        {
            if (palettes != null)
            {
                return;
            }

            palettes = new Dictionary<TournamentThemeId, TournamentThemePalette>
            {
                {
                    TournamentThemeId.DarkBlue,
                    new TournamentThemePalette
                    {
                        Id = TournamentThemeId.DarkBlue,
                        DisplayName = "Dark Blue",
                        Description = "Ciemny esportowy motyw z niebieskim akcentem.",
                        BackgroundColor = C(0x08, 0x0D, 0x18),
                        PanelColor = C(0x10, 0x18, 0x27),
                        PanelSecondaryColor = C(0x22, 0x2C, 0x44),
                        HeaderColor = C(0x11, 0x1B, 0x2C),
                        InputColor = C(0x12, 0x1B, 0x29),
                        ScoreBoxColor = C(0x05, 0x09, 0x12),
                        ButtonPrimaryColor = C(0x2F, 0x5F, 0xB3),
                        ButtonSecondaryColor = C(0x1D, 0x2A, 0x42),
                        ButtonDangerColor = C(0x9B, 0x31, 0x2A),
                        ButtonTextColor = Color.white,
                        TextPrimaryColor = C(0xF5, 0xF7, 0xFB),
                        TextSecondaryColor = C(0xB7, 0xC1, 0xD4),
                        BorderColor = C(0x45, 0x7E, 0xD8),
                        ActiveColor = C(0x4F, 0xA4, 0xFF),
                        SuccessColor = C(0x2F, 0x8A, 0x4F),
                        WarningColor = C(0xF2, 0xC9, 0x4C),
                        ErrorColor = C(0xC9, 0x3C, 0x33),
                        MatchPendingColor = C(0x6D, 0x76, 0x86),
                        MatchReadyColor = C(0x4F, 0xA4, 0xFF),
                        MatchActiveColor = C(0xF2, 0xC9, 0x4C),
                        MatchCompletedColor = C(0x2F, 0xB8, 0x69),
                        MatchProblemColor = C(0xD7, 0x45, 0x3D),
                        WalkoverColor = C(0x8A, 0x5C, 0xD6)
                    }
                },
                {
                    TournamentThemeId.DarkGold,
                    new TournamentThemePalette
                    {
                        Id = TournamentThemeId.DarkGold,
                        DisplayName = "Dark Gold",
                        Description = "Ciemny turniejowy motyw premium ze zlotem.",
                        BackgroundColor = C(0x0B, 0x0B, 0x0D),
                        PanelColor = C(0x1A, 0x19, 0x18),
                        PanelSecondaryColor = C(0x2B, 0x28, 0x22),
                        HeaderColor = C(0x1F, 0x1C, 0x18),
                        InputColor = C(0x21, 0x20, 0x1F),
                        ScoreBoxColor = C(0x07, 0x07, 0x08),
                        ButtonPrimaryColor = C(0x9A, 0x6A, 0x23),
                        ButtonSecondaryColor = C(0x2E, 0x2A, 0x24),
                        ButtonDangerColor = C(0x8F, 0x2D, 0x26),
                        ButtonTextColor = C(0xFF, 0xF5, 0xDD),
                        TextPrimaryColor = C(0xFF, 0xF5, 0xDD),
                        TextSecondaryColor = C(0xD3, 0xC5, 0xAA),
                        BorderColor = C(0xC7, 0x95, 0x2B),
                        ActiveColor = C(0xD6, 0xA4, 0x2F),
                        SuccessColor = C(0x2D, 0x8A, 0x4B),
                        WarningColor = C(0xE4, 0xB8, 0x42),
                        ErrorColor = C(0xC9, 0x3B, 0x32),
                        MatchPendingColor = C(0x79, 0x74, 0x68),
                        MatchReadyColor = C(0xB9, 0x83, 0x2A),
                        MatchActiveColor = C(0xD6, 0xA4, 0x2F),
                        MatchCompletedColor = C(0x2F, 0x9E, 0x58),
                        MatchProblemColor = C(0xD3, 0x3C, 0x32),
                        WalkoverColor = C(0x8B, 0x58, 0xB6)
                    }
                },
                {
                    TournamentThemeId.LightClean,
                    new TournamentThemePalette
                    {
                        Id = TournamentThemeId.LightClean,
                        DisplayName = "Light Clean",
                        Description = "Jasny panel organizatora z mocnym niebieskim.",
                        BackgroundColor = C(0xE9, 0xEC, 0xF2),
                        PanelColor = C(0xFF, 0xFF, 0xFF),
                        PanelSecondaryColor = C(0xD8, 0xE0, 0xEE),
                        HeaderColor = C(0xF7, 0xF9, 0xFC),
                        InputColor = C(0xFF, 0xFF, 0xFF),
                        ScoreBoxColor = C(0x1F, 0x2A, 0x3B),
                        ButtonPrimaryColor = C(0x1E, 0x62, 0xC8),
                        ButtonSecondaryColor = C(0xCF, 0xD9, 0xEA),
                        ButtonDangerColor = C(0xB7, 0x32, 0x2C),
                        ButtonTextColor = Color.white,
                        TextPrimaryColor = C(0x1A, 0x20, 0x2C),
                        TextSecondaryColor = C(0x4D, 0x5A, 0x6E),
                        BorderColor = C(0x2E, 0x6F, 0xD6),
                        ActiveColor = C(0x1E, 0x62, 0xC8),
                        SuccessColor = C(0x2C, 0x8B, 0x4E),
                        WarningColor = C(0xC4, 0x7D, 0x00),
                        ErrorColor = C(0xC5, 0x2F, 0x2A),
                        MatchPendingColor = C(0x6D, 0x78, 0x88),
                        MatchReadyColor = C(0x1E, 0x62, 0xC8),
                        MatchActiveColor = C(0xD9, 0x8B, 0x00),
                        MatchCompletedColor = C(0x24, 0x8A, 0x48),
                        MatchProblemColor = C(0xC5, 0x2F, 0x2A),
                        WalkoverColor = C(0x7D, 0x4E, 0xB6)
                    }
                },
                {
                    TournamentThemeId.HighContrast,
                    new TournamentThemePalette
                    {
                        Id = TournamentThemeId.HighContrast,
                        DisplayName = "High Contrast",
                        Description = "Najczytelniejszy motyw dla widzow i streama.",
                        BackgroundColor = Color.black,
                        PanelColor = C(0x07, 0x08, 0x0C),
                        PanelSecondaryColor = C(0x14, 0x18, 0x24),
                        HeaderColor = C(0x0D, 0x10, 0x18),
                        InputColor = C(0x10, 0x12, 0x18),
                        ScoreBoxColor = C(0x00, 0x00, 0x00),
                        ButtonPrimaryColor = C(0x00, 0x74, 0xFF),
                        ButtonSecondaryColor = C(0x19, 0x22, 0x35),
                        ButtonDangerColor = C(0xE8, 0x1E, 0x1E),
                        ButtonTextColor = Color.white,
                        TextPrimaryColor = Color.white,
                        TextSecondaryColor = C(0xD4, 0xD8, 0xE2),
                        BorderColor = C(0xFF, 0xD1, 0x2A),
                        ActiveColor = C(0xFF, 0xD1, 0x2A),
                        SuccessColor = C(0x00, 0xE0, 0x62),
                        WarningColor = C(0xFF, 0xD1, 0x2A),
                        ErrorColor = C(0xFF, 0x28, 0x28),
                        MatchPendingColor = C(0xA8, 0xB0, 0xC0),
                        MatchReadyColor = C(0x00, 0xA2, 0xFF),
                        MatchActiveColor = C(0xFF, 0xD1, 0x2A),
                        MatchCompletedColor = C(0x00, 0xE0, 0x62),
                        MatchProblemColor = C(0xFF, 0x28, 0x28),
                        WalkoverColor = C(0xB8, 0x74, 0xFF)
                    }
                }
            };
        }

        private static bool IsClose(Color color, float r, float g, float b)
        {
            const float tolerance = 0.035f;
            return Mathf.Abs(color.r - r) < tolerance &&
                   Mathf.Abs(color.g - g) < tolerance &&
                   Mathf.Abs(color.b - b) < tolerance;
        }

        private static Color C(byte r, byte g, byte b)
        {
            return new Color(r / 255f, g / 255f, b / 255f, 1f);
        }
    }
}
