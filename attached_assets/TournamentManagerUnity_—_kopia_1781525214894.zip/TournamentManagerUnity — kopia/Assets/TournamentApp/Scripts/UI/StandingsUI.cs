using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class StandingsUI
    {
        public static void Render(Transform parent, TournamentManager manager)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Tabela", 24, FontStyle.Bold);
            Text info = UIFactory.CreateText(parent, "Rules", "Zasady sortowania: punkty -> tie-break -> roznica wynikow -> rozstawienie. Tie-break = suma punktow przeciwnikow gracza.", 14);
            info.color = new Color(1f, 1f, 1f, 0.72f);

            RenderRow(parent, "Miejsce", "Gracz", "Punkty", "Bilans", "Tie-break", "Roznica", "Rozstawienie", true);
            List<Standing> standings = manager.GetStandings();
            foreach (Standing standing in standings)
            {
                Participant participant = TournamentLookup.Participant(tournament, standing.participantId);
                RenderRow(
                    parent,
                    standing.rank.ToString(),
                    participant == null ? "Do ustalenia" : participant.displayName,
                    standing.points.ToString(),
                    standing.wins + "-" + standing.draws + "-" + standing.losses,
                    standing.buchholz.ToString(),
                    standing.smallPointDiff.ToString(),
                    participant == null ? "-" : participant.seed.ToString(),
                    false);
            }
        }

        private static void RenderRow(Transform parent, string rank, string nick, string points, string score, string buchholz, string diff, string seed, bool header)
        {
            GameObject row = UIFactory.CreateRow(parent, "StandingRow", 6);
            Color color = header ? new Color(0.16f, 0.22f, 0.34f, 1f) : new Color(0.1f, 0.13f, 0.19f, 1f);
            row.AddComponent<Image>().color = color;
            AddCell(row.transform, rank, 80, header);
            AddCell(row.transform, nick, 210, header);
            AddCell(row.transform, points, 80, header);
            AddCell(row.transform, score, 95, header);
            AddCell(row.transform, buchholz, 100, header);
            AddCell(row.transform, diff, 85, header);
            AddCell(row.transform, seed, 115, header);
        }

        private static void AddCell(Transform parent, string value, float width, bool header)
        {
            TextAnchor anchor = width > 130 ? TextAnchor.MiddleLeft : TextAnchor.MiddleCenter;
            Text text = UIFactory.CreateText(parent, "Cell", value, header ? 15 : 14, header ? FontStyle.Bold : FontStyle.Normal, anchor);
            LayoutElement layout = text.gameObject.AddComponent<LayoutElement>();
            layout.preferredWidth = width;
            layout.minHeight = 30;
        }
    }
}
