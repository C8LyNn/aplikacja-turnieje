using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class PlayerCardUI
    {
        public static GameObject Render(Transform parent, TournamentManager manager, string participantId, bool broadcast)
        {
            Tournament tournament = manager.CurrentTournament;
            TournamentVisualSettings visual = tournament == null ? TournamentVisualSettings.CreateDefault() : tournament.visualSettings;
            Participant participant = TournamentLookup.Participant(tournament, participantId);
            Color cardColor = UIFactory.ColorFromHex(visual.matchCardColor, new Color(0.13f, 0.17f, 0.27f, 1f));
            GameObject card = UIFactory.CreatePanel(parent, "PlayerCard", cardColor);
            VerticalLayoutGroup vertical = card.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 10, 10);
            vertical.spacing = 4;
            LayoutElement layout = card.AddComponent<LayoutElement>();
            layout.minWidth = broadcast ? 340 : 220;
            layout.preferredWidth = broadcast ? 420 : 260;
            layout.minHeight = broadcast ? 160 : 110;

            string name = participant == null ? "Do ustalenia" : participant.displayName;
            UIFactory.CreateText(card.transform, "Name", name, broadcast ? visual.fontSizeLarge : 20, FontStyle.Bold, TextAnchor.MiddleCenter);

            if (participant != null)
            {
                if (visual.showSeeds)
                {
                    UIFactory.CreateText(card.transform, "Seed", "Rozstawienie #" + participant.seed, visual.fontSizeSmall, FontStyle.Normal, TextAnchor.MiddleCenter);
                }

                if (visual.showRanks && !string.IsNullOrWhiteSpace(participant.rankName))
                {
                    UIFactory.CreateText(card.transform, "Rank", participant.rankName, visual.fontSizeSmall, FontStyle.Normal, TextAnchor.MiddleCenter);
                }

                if (visual.showTeams && !string.IsNullOrWhiteSpace(participant.teamId))
                {
                    UIFactory.CreateText(card.transform, "Team", participant.teamId, visual.fontSizeSmall, FontStyle.Normal, TextAnchor.MiddleCenter);
                }

                UIFactory.CreateText(card.transform, "ScoreLine", participant.points + " pkt  Bilans " + participant.wins + "-" + participant.draws + "-" + participant.losses, visual.fontSizeSmall, FontStyle.Normal, TextAnchor.MiddleCenter);
            }

            return card;
        }
    }
}
