using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class CorrectionViewUI
    {
        private static string pendingRevertMatchId;

        public static void Render(Transform parent, TournamentManager manager)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20, FontStyle.Bold);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Korekta bledow", 26, FontStyle.Bold);
            Text warning = UIFactory.CreateText(
                parent,
                "Warning",
                "To jest panel naprawczy. Cofanie wyniku wymaga potwierdzenia i moze wymagac sprawdzenia kolejnych rund.",
                15,
                FontStyle.Bold
            );
            warning.color = new Color(1f, 0.82f, 0.24f, 1f);

            Match pending = string.IsNullOrEmpty(pendingRevertMatchId) ? null : TournamentLookup.Match(tournament, pendingRevertMatchId);
            if (pending != null)
            {
                RenderConfirmation(parent, manager, tournament, pending);
            }

            RenderLatestResult(parent, manager, tournament);
            RenderCompletedMatches(parent, manager, tournament);
            RenderAuditLog(parent, tournament);
        }

        private static void RenderConfirmation(Transform parent, TournamentManager manager, Tournament tournament, Match match)
        {
            GameObject box = UIFactory.CreatePanel(parent, "ConfirmRevert", new Color(0.20f, 0.11f, 0.08f, 1f));
            LayoutElement boxLayout = box.AddComponent<LayoutElement>();
            boxLayout.minWidth = 760;
            boxLayout.preferredWidth = 860;
            boxLayout.minHeight = 150;
            boxLayout.preferredHeight = 165;

            VerticalLayoutGroup vertical = box.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 10, 10);
            vertical.spacing = 6;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;

            UIFactory.CreateText(box.transform, "Title", "Czy na pewno cofnac wynik?", 20, FontStyle.Bold);
            UIFactory.CreateText(box.transform, "Match", TournamentUIText.RoundMatchLabel(tournament, match), 15, FontStyle.Bold);
            UIFactory.CreateText(box.transform, "Score", TournamentUIText.ScoreLine(tournament, match), 16, FontStyle.Bold);
            UIFactory.CreateText(box.transform, "Info", "To usunie wynik meczu i moze wymagac przeliczenia albo recznego sprawdzenia kolejnych rund.", 14);

            GameObject row = UIFactory.CreateRow(box.transform, "Actions", 8);
            UIFactory.CreateButton(row.transform, "Cofnij wynik", () =>
            {
                manager.RevertMatchResult(match.id);
                pendingRevertMatchId = string.Empty;
            }, new Color(0.62f, 0.22f, 0.18f, 1f));

            UIFactory.CreateButton(row.transform, "Anuluj", () =>
            {
                pendingRevertMatchId = string.Empty;
                manager.SetMessage("Anulowano cofanie wyniku.");
            }, new Color(0.18f, 0.34f, 0.62f, 1f));
        }

        private static void RenderLatestResult(Transform parent, TournamentManager manager, Tournament tournament)
        {
            UIFactory.CreateText(parent, "LastResultTitle", "Szybka akcja", 19, FontStyle.Bold);
            ResultRecord latest = tournament.resultHistory == null || tournament.resultHistory.Count == 0
                ? null
                : tournament.resultHistory[tournament.resultHistory.Count - 1];

            if (latest == null)
            {
                UIFactory.CreateText(parent, "NoResults", "Brak wynikow do cofniecia.", 14);
                return;
            }

            GameObject row = UIFactory.CreateRow(parent, "LatestResult", 8);
            row.AddComponent<Image>().color = new Color(0.1f, 0.13f, 0.19f, 1f);
            Text label = UIFactory.CreateText(row.transform, "Label", "Ostatni wynik: " + FormatRecord(tournament, latest), 14, FontStyle.Bold);
            LayoutElement labelLayout = label.gameObject.AddComponent<LayoutElement>();
            labelLayout.preferredWidth = 680;
            UIFactory.CreateButton(row.transform, "Cofnij ostatni wynik", () => pendingRevertMatchId = latest.matchId, new Color(0.62f, 0.22f, 0.18f, 1f));
        }

        private static void RenderCompletedMatches(Transform parent, TournamentManager manager, Tournament tournament)
        {
            UIFactory.CreateText(parent, "CompletedTitle", "Cofnij konkretny wynik", 19, FontStyle.Bold);
            int count = 0;
            for (int i = tournament.resultHistory.Count - 1; i >= 0 && count < 12; i--)
            {
                ResultRecord record = tournament.resultHistory[i];
                Match match = TournamentLookup.Match(tournament, record.matchId);
                if (match == null || (!match.IsFinished() && match.status != MatchStatus.ResultDisputed))
                {
                    continue;
                }

                GameObject row = UIFactory.CreateRow(parent, "CompletedResult", 8);
                row.AddComponent<Image>().color = new Color(0.1f, 0.13f, 0.19f, 1f);
                Text label = UIFactory.CreateText(row.transform, "Label", FormatRecord(tournament, record), 14);
                LayoutElement labelLayout = label.gameObject.AddComponent<LayoutElement>();
                labelLayout.preferredWidth = 680;
                UIFactory.CreateButton(row.transform, "Przygotuj cofniecie", () => pendingRevertMatchId = record.matchId, new Color(0.42f, 0.16f, 0.15f, 1f));
                count++;
            }
        }

        private static void RenderAuditLog(Transform parent, Tournament tournament)
        {
            UIFactory.CreateText(parent, "AuditTitle", "Ostatnie wazne akcje", 19, FontStyle.Bold);
            List<AuditLogEntry> log = tournament.auditLog;
            if (log == null || log.Count == 0)
            {
                UIFactory.CreateText(parent, "NoAudit", "Brak wpisow w logu.", 14);
                return;
            }

            int start = Mathf.Max(0, log.Count - 12);
            for (int i = log.Count - 1; i >= start; i--)
            {
                AuditLogEntry entry = log[i];
                string text = entry.timestamp + " - " + entry.actionType + "\n" + entry.description;
                if (!string.IsNullOrEmpty(entry.relatedMatchId))
                {
                    Match match = TournamentLookup.Match(tournament, entry.relatedMatchId);
                    if (match != null)
                    {
                        text += "\n" + TournamentUIText.RoundMatchLabel(tournament, match) + " | " + TournamentUIText.ScoreLine(tournament, match);
                    }
                }

                if (!string.IsNullOrEmpty(entry.oldValue) || !string.IsNullOrEmpty(entry.newValue))
                {
                    text += "\nPoprzednio: " + entry.oldValue + "   Nowe: " + entry.newValue;
                }

                Text label = UIFactory.CreateText(parent, "AuditEntry", text, 13);
                label.color = new Color(1f, 1f, 1f, 0.82f);
                LayoutElement layout = label.gameObject.AddComponent<LayoutElement>();
                layout.preferredWidth = 860;
                layout.preferredHeight = 58;
            }
        }

        private static string FormatRecord(Tournament tournament, ResultRecord record)
        {
            return "Runda " + (record.roundIndex + 1) + ", Mecz " + (TournamentLookup.Match(tournament, record.matchId)?.matchIndex + 1 ?? 0) +
                   " - " + TournamentUIText.ParticipantName(tournament, record.participantAId) + " " + record.scoreA +
                   " : " + record.scoreB + " " + TournamentUIText.ParticipantName(tournament, record.participantBId) +
                   " | Zwyciezca: " + TournamentUIText.ParticipantName(tournament, record.winnerId);
        }
    }
}
