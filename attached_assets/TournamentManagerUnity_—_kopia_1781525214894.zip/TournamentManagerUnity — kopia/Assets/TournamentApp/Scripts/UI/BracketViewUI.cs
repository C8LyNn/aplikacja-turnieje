using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class BracketViewUI
    {
        private const float RoundColumnWidth = 360f;
        private const float RoundColumnMinWidth = 340f;
        private const float RoundSpacing = 8f;
        private const float ViewportPreferredHeight = 790f;
        private const float ViewportMinHeight = 520f;
        private const float ScrollbarThickness = 18f;

        public static void Render(Transform parent, TournamentManager manager, bool admin)
        {
            Tournament tournament = manager.CurrentTournament;

            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Drabinka", 24, FontStyle.Bold);

            if (admin)
            {
                BracketManualToolsUI.Render(parent, manager);
                RenderSelectedMatchPanel(parent, manager, tournament);
            }

            foreach (TournamentPhase phase in tournament.phases)
            {
                UIFactory.CreateText(
                    parent,
                    "Phase",
                    phase.name + " (" + TournamentUIText.FormatName(phase.formatType) + ")",
                    20,
                    FontStyle.Bold
                );

                RenderPhaseBracket(parent, manager, phase, admin);
            }
        }

        private static void RenderSelectedMatchPanel(Transform parent, TournamentManager manager, Tournament tournament)
        {
            Match match = manager.GetCurrentMatch();
            GameObject panel = UIFactory.CreatePanel(parent, "SelectedMatchPanel", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minWidth = 920;
            panelLayout.preferredWidth = 1180;
            panelLayout.minHeight = 214;
            panelLayout.preferredHeight = 232;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 10, 10);
            vertical.spacing = 6;
            vertical.childAlignment = TextAnchor.UpperCenter;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            UIFactory.CreateText(panel.transform, "Title", "Wybrany mecz", 18, FontStyle.Bold, TextAnchor.MiddleCenter);

            if (match == null)
            {
                UIFactory.CreateText(panel.transform, "NoMatch", "Kliknij karte meczu w drabince, zeby ja wybrac.", 14, FontStyle.Bold, TextAnchor.MiddleCenter);
                return;
            }

            Text summary = UIFactory.CreateText(
                panel.transform,
                "Summary",
                TournamentUIText.RoundMatchLabel(tournament, match) + " | " + TournamentUIText.ScoreLine(tournament, match) + " | Status: " + TournamentUIText.Status(match.status),
                15,
                FontStyle.Bold,
                TextAnchor.MiddleCenter
            );
            summary.color = TournamentUIText.StatusColor(match.status, tournament.currentMatchId == match.id);

            GameObject editRow = UIFactory.CreateRow(panel.transform, "EditScore", 6);
            editRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;

            Text editLabel = UIFactory.CreateText(editRow.transform, "EditLabel", "Edytuj wynik:", 14, FontStyle.Bold, TextAnchor.MiddleCenter);
            SetLayout(editLabel.gameObject, 115f, 38f);

            InputField scoreAInput = UIFactory.CreateInput(editRow.transform, "A", match.scoreA.ToString());
            SetLayout(scoreAInput.gameObject, 74f, 38f);
            ConfigureScoreInput(scoreAInput);

            Text separator = UIFactory.CreateText(editRow.transform, "Separator", ":", 20, FontStyle.Bold, TextAnchor.MiddleCenter);
            SetLayout(separator.gameObject, 18f, 38f);

            InputField scoreBInput = UIFactory.CreateInput(editRow.transform, "B", match.scoreB.ToString());
            SetLayout(scoreBInput.gameObject, 74f, 38f);
            ConfigureScoreInput(scoreBInput);

            UIFactory.CreateButton(editRow.transform, "Edytuj wynik", () =>
            {
                int editedA;
                int editedB;
                if (!TryParseScore(scoreAInput.text, out editedA) || !TryParseScore(scoreBInput.text, out editedB))
                {
                    manager.SetMessage("Wynik musi byc liczba 0 lub wieksza.");
                    return;
                }

                manager.SubmitMatchResult(match.id, editedA, editedB);
            }, new Color(0.18f, 0.34f, 0.62f, 1f));

            GameObject row = UIFactory.CreateRow(panel.transform, "Actions", 6);
            row.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;

            UIFactory.CreateButton(row.transform, "+1 A", () => manager.AdjustMatchScore(match.id, MatchSlot.A, 1), new Color(0.18f, 0.48f, 0.28f, 1f));
            UIFactory.CreateButton(row.transform, "-1 A", () => manager.AdjustMatchScore(match.id, MatchSlot.A, -1), new Color(0.17f, 0.23f, 0.34f, 1f));
            UIFactory.CreateButton(row.transform, "+1 B", () => manager.AdjustMatchScore(match.id, MatchSlot.B, 1), new Color(0.18f, 0.48f, 0.28f, 1f));
            UIFactory.CreateButton(row.transform, "-1 B", () => manager.AdjustMatchScore(match.id, MatchSlot.B, -1), new Color(0.17f, 0.23f, 0.34f, 1f));
            UIFactory.CreateButton(row.transform, "Zatwierdz wynik", () => manager.SubmitMatchResult(match.id, match.scoreA, match.scoreB), new Color(0.18f, 0.48f, 0.28f, 1f));
            UIFactory.CreateButton(row.transform, "Ustaw jako aktualny", () => manager.SetCurrentMatch(match.id), new Color(0.18f, 0.34f, 0.62f, 1f));

            GameObject walkoverRow = UIFactory.CreateRow(panel.transform, "WalkoverActions", 6);
            walkoverRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            UIFactory.CreateButton(walkoverRow.transform, "Walkower A: nieobecny", () => manager.AssignWalkover(match.id, MatchSlot.A, "przeciwnik nieobecny"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower B: nieobecny", () => manager.AssignWalkover(match.id, MatchSlot.B, "przeciwnik nieobecny"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower A: admin", () => manager.AssignWalkover(match.id, MatchSlot.A, "decyzja admina"), new Color(0.38f, 0.24f, 0.62f, 1f));
            UIFactory.CreateButton(walkoverRow.transform, "Walkower B: admin", () => manager.AssignWalkover(match.id, MatchSlot.B, "decyzja admina"), new Color(0.38f, 0.24f, 0.62f, 1f));
        }

        private static bool TryParseScore(string value, out int score)
        {
            if (!int.TryParse(value, out score))
            {
                score = 0;
                return false;
            }

            score = Mathf.Max(0, score);
            return true;
        }

        private static void RenderPhaseBracket(Transform parent, TournamentManager manager, TournamentPhase phase, bool admin)
        {
            GameObject bracketPanel = UIFactory.CreatePanel(
                parent,
                "BracketPanel",
                new Color(0.055f, 0.07f, 0.105f, 1f)
            );

            LayoutElement panelLayout = bracketPanel.AddComponent<LayoutElement>();
            panelLayout.minHeight = ViewportMinHeight + ScrollbarThickness + 48f;
            panelLayout.preferredHeight = ViewportPreferredHeight + ScrollbarThickness + 54f;
            panelLayout.flexibleHeight = 1f;
            panelLayout.flexibleWidth = 1f;

            VerticalLayoutGroup panelVertical = bracketPanel.AddComponent<VerticalLayoutGroup>();
            panelVertical.padding = new RectOffset(6, 6, 6, 6);
            panelVertical.spacing = 6;
            panelVertical.childAlignment = TextAnchor.UpperLeft;
            panelVertical.childControlWidth = true;
            panelVertical.childControlHeight = true;
            panelVertical.childForceExpandWidth = true;
            panelVertical.childForceExpandHeight = false;

            GameObject viewportRow = new GameObject("BracketViewportRow", typeof(RectTransform));
            viewportRow.transform.SetParent(bracketPanel.transform, false);

            LayoutElement viewportRowLayout = viewportRow.AddComponent<LayoutElement>();
            viewportRowLayout.minHeight = ViewportMinHeight;
            viewportRowLayout.preferredHeight = ViewportPreferredHeight;
            viewportRowLayout.flexibleWidth = 1f;

            HorizontalLayoutGroup viewportRowGroup = viewportRow.AddComponent<HorizontalLayoutGroup>();
            viewportRowGroup.spacing = 6;
            viewportRowGroup.childAlignment = TextAnchor.UpperLeft;
            viewportRowGroup.childControlWidth = true;
            viewportRowGroup.childControlHeight = true;
            viewportRowGroup.childForceExpandWidth = false;
            viewportRowGroup.childForceExpandHeight = true;

            GameObject viewport = UIFactory.CreatePanel(
                viewportRow.transform,
                "BracketViewport",
                new Color(0.045f, 0.058f, 0.09f, 1f)
            );

            LayoutElement viewportLayout = viewport.AddComponent<LayoutElement>();
            viewportLayout.minHeight = ViewportMinHeight;
            viewportLayout.preferredHeight = ViewportPreferredHeight;
            viewportLayout.flexibleWidth = 1f;
            viewportLayout.flexibleHeight = 1f;

            RectTransform viewportRect = viewport.GetComponent<RectTransform>();

            Mask mask = viewport.AddComponent<Mask>();
            mask.showMaskGraphic = false;

            ScrollRect scrollRect = viewport.AddComponent<ScrollRect>();
            scrollRect.horizontal = true;
            scrollRect.vertical = true;
            scrollRect.movementType = ScrollRect.MovementType.Clamped;
            scrollRect.inertia = true;
            scrollRect.scrollSensitivity = 45f;

            GameObject content = new GameObject("BracketContent", typeof(RectTransform));
            content.transform.SetParent(viewport.transform, false);

            RectTransform contentRect = content.GetComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0f, 1f);
            contentRect.anchorMax = new Vector2(0f, 1f);
            contentRect.pivot = new Vector2(0f, 1f);
            contentRect.anchoredPosition = Vector2.zero;
            contentRect.sizeDelta = Vector2.zero;

            HorizontalLayoutGroup horizontal = content.AddComponent<HorizontalLayoutGroup>();
            horizontal.padding = new RectOffset(0, 0, 0, 0);
            horizontal.spacing = RoundSpacing;
            horizontal.childAlignment = TextAnchor.UpperLeft;
            horizontal.childControlWidth = true;
            horizontal.childControlHeight = true;
            horizontal.childForceExpandWidth = false;
            horizontal.childForceExpandHeight = false;

            ContentSizeFitter contentFitter = content.AddComponent<ContentSizeFitter>();
            contentFitter.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
            contentFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            foreach (Round round in phase.rounds)
            {
                RenderRoundColumn(content.transform, manager, round, admin);
            }

            Scrollbar verticalScrollbar = CreateVerticalScrollbar(viewportRow.transform, "VerticalBracketSlider");
            Scrollbar horizontalScrollbar = CreateHorizontalScrollbar(bracketPanel.transform, "HorizontalBracketSlider");

            scrollRect.viewport = viewportRect;
            scrollRect.content = contentRect;
            scrollRect.verticalScrollbar = verticalScrollbar;
            scrollRect.horizontalScrollbar = horizontalScrollbar;
            scrollRect.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
            scrollRect.horizontalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
            scrollRect.verticalNormalizedPosition = 1f;
            scrollRect.horizontalNormalizedPosition = 0f;
        }

        private static void RenderRoundColumn(Transform parent, TournamentManager manager, Round round, bool admin)
        {
            GameObject column = UIFactory.CreatePanel(
                parent,
                "RoundColumn",
                new Color(0.08f, 0.1f, 0.15f, 1f)
            );

            VerticalLayoutGroup vertical = column.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(8, 8, 8, 8);
            vertical.spacing = 8;
            vertical.childAlignment = TextAnchor.UpperCenter;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            ContentSizeFitter fitter = column.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            LayoutElement columnLayout = column.AddComponent<LayoutElement>();
            columnLayout.preferredWidth = RoundColumnWidth;
            columnLayout.minWidth = RoundColumnMinWidth;
            columnLayout.flexibleWidth = 0f;

            Text roundName = UIFactory.CreateText(
                column.transform,
                "RoundName",
                round.name + "  (" + CompletedCount(round) + "/" + round.matches.Count + ")",
                16,
                FontStyle.Bold,
                TextAnchor.MiddleCenter
            );

            AddLayout(roundName.gameObject, RoundColumnWidth - 20f, 26f);

            foreach (Match match in round.matches)
            {
                RenderMatchCard(column.transform, manager, match, admin);
            }
        }

        private static Scrollbar CreateVerticalScrollbar(Transform parent, string name)
        {
            GameObject scrollbarObject = UIFactory.CreatePanel(parent, name, new Color(0.09f, 0.11f, 0.16f, 1f));

            LayoutElement layout = scrollbarObject.AddComponent<LayoutElement>();
            layout.minWidth = ScrollbarThickness;
            layout.preferredWidth = ScrollbarThickness;
            layout.flexibleWidth = 0f;
            layout.flexibleHeight = 1f;

            RectTransform scrollbarRect = scrollbarObject.GetComponent<RectTransform>();
            scrollbarRect.sizeDelta = new Vector2(ScrollbarThickness, 0f);

            Scrollbar scrollbar = scrollbarObject.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.BottomToTop;

            GameObject slidingArea = new GameObject("Sliding Area", typeof(RectTransform));
            slidingArea.transform.SetParent(scrollbarObject.transform, false);
            UIFactory.Stretch(slidingArea.GetComponent<RectTransform>(), 2, 2, 2, 2);

            GameObject handle = UIFactory.CreatePanel(slidingArea.transform, "Handle", new Color(0.25f, 0.43f, 0.72f, 1f));
            RectTransform handleRect = handle.GetComponent<RectTransform>();
            UIFactory.Stretch(handleRect, 0, 0, 0, 0);

            scrollbar.handleRect = handleRect;
            scrollbar.targetGraphic = handle.GetComponent<Image>();
            scrollbar.size = 0.25f;
            scrollbar.value = 1f;

            return scrollbar;
        }

        private static Scrollbar CreateHorizontalScrollbar(Transform parent, string name)
        {
            GameObject scrollbarObject = UIFactory.CreatePanel(parent, name, new Color(0.09f, 0.11f, 0.16f, 1f));

            LayoutElement layout = scrollbarObject.AddComponent<LayoutElement>();
            layout.minHeight = ScrollbarThickness;
            layout.preferredHeight = ScrollbarThickness;
            layout.flexibleHeight = 0f;
            layout.flexibleWidth = 1f;

            RectTransform scrollbarRect = scrollbarObject.GetComponent<RectTransform>();
            scrollbarRect.sizeDelta = new Vector2(0f, ScrollbarThickness);

            Scrollbar scrollbar = scrollbarObject.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.LeftToRight;

            GameObject slidingArea = new GameObject("Sliding Area", typeof(RectTransform));
            slidingArea.transform.SetParent(scrollbarObject.transform, false);
            UIFactory.Stretch(slidingArea.GetComponent<RectTransform>(), 2, 2, 2, 2);

            GameObject handle = UIFactory.CreatePanel(slidingArea.transform, "Handle", new Color(0.25f, 0.43f, 0.72f, 1f));
            RectTransform handleRect = handle.GetComponent<RectTransform>();
            UIFactory.Stretch(handleRect, 0, 0, 0, 0);

            scrollbar.handleRect = handleRect;
            scrollbar.targetGraphic = handle.GetComponent<Image>();
            scrollbar.size = 0.25f;
            scrollbar.value = 0f;

            return scrollbar;
        }

        private static void RenderMatchCard(Transform parent, TournamentManager manager, Match match, bool admin)
        {
            Tournament tournament = manager.CurrentTournament;
            TournamentThemePalette theme = TournamentThemeManager.Current;

            bool active = tournament.currentMatchId == match.id;
            bool completed = match.IsFinished();

            Color baseCardColor = theme.PanelSecondaryColor;
            Color activeAccentColor = theme.ActiveColor;
            Color cardColor = active ? theme.PanelSecondaryColor : baseCardColor;

            Color mainTextColor = Color.white;
            Color secondaryTextColor = active ? new Color(1f, 1f, 1f, 0.92f) : new Color(1f, 1f, 1f, 0.78f);

            GameObject card = UIFactory.CreatePanel(parent, "MatchCard", cardColor);
            if (active)
            {
                Outline outline = card.AddComponent<Outline>();
                outline.effectColor = activeAccentColor;
                outline.effectDistance = new Vector2(3f, -3f);
            }

            Button cardButton = card.AddComponent<Button>();
            cardButton.targetGraphic = card.GetComponent<Image>();
            cardButton.onClick.AddListener(() => manager.SetCurrentMatch(match.id));

            VerticalLayoutGroup vertical = card.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(10, 10, 10, 10);
            vertical.spacing = 8;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            LayoutElement cardLayout = card.AddComponent<LayoutElement>();
            cardLayout.preferredWidth = 330f;
            cardLayout.minWidth = 320f;
            cardLayout.minHeight = 104f;
            cardLayout.preferredHeight = 116f;

            string aName = TournamentLookup.ParticipantName(tournament, match.participantAId);
            string bName = TournamentLookup.ParticipantName(tournament, match.participantBId);

            Text status = UIFactory.CreateText(
                card.transform,
                "Status",
                TournamentUIText.Status(match.status),
                12,
                FontStyle.Bold,
                TextAnchor.MiddleCenter
            );
            status.color = TournamentUIText.StatusColor(match.status, active);
            AddLayout(status.gameObject, 310f, 18f);

            RenderResultLine(
                card.transform,
                aName,
                bName,
                match.scoreA,
                match.scoreB,
                match.participantAId == match.winnerId,
                match.participantBId == match.winnerId,
                mainTextColor,
                secondaryTextColor
            );

            if (admin)
            {
                Text hint = UIFactory.CreateText(card.transform, "Hint", active ? "Wybrany mecz" : "Kliknij, aby wybrac", 11, FontStyle.Bold, TextAnchor.MiddleCenter);
                hint.color = active ? activeAccentColor : new Color(1f, 1f, 1f, 0.55f);
                AddLayout(hint.gameObject, 310f, 16f);
            }
        }

        private static InputField[] RenderEditableResultLine(
            Transform parent,
            TournamentManager manager,
            Match match,
            string playerAName,
            string playerBName,
            int scoreA,
            int scoreB,
            string participantAId,
            string participantBId,
            bool playerAWinner,
            bool playerBWinner,
            Color mainTextColor,
            Color secondaryTextColor)
        {
            GameObject row = UIFactory.CreateRow(parent, "ResultLine", 6);
            row.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            AddLayout(row, 310f, 58f);

            CreatePlayerNameBox(row.transform, "PlayerA", SafePlayerName(playerAName), playerAWinner, secondaryTextColor, manager, match.id, MatchSlot.A, participantAId);

            InputField inputA = UIFactory.CreateInput(row.transform, "A", scoreA.ToString());
            SetLayout(inputA.gameObject, 46f, 58f);
            ConfigureScoreInput(inputA);

            Text separator = UIFactory.CreateText(row.transform, "Separator", ":", 28, FontStyle.Bold, TextAnchor.MiddleCenter);
            separator.color = mainTextColor;
            SetLayout(separator.gameObject, 16f, 58f);

            InputField inputB = UIFactory.CreateInput(row.transform, "B", scoreB.ToString());
            SetLayout(inputB.gameObject, 46f, 58f);
            ConfigureScoreInput(inputB);

            CreatePlayerNameBox(row.transform, "PlayerB", SafePlayerName(playerBName), playerBWinner, secondaryTextColor, manager, match.id, MatchSlot.B, participantBId);

            return new[] { inputA, inputB };
        }

        private static void RenderResultLine(
            Transform parent,
            string playerAName,
            string playerBName,
            int scoreA,
            int scoreB,
            bool playerAWinner,
            bool playerBWinner,
            Color mainTextColor,
            Color secondaryTextColor)
        {
            GameObject row = UIFactory.CreateRow(parent, "ResultLine", 8);
            row.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
            AddLayout(row, 310f, 58f);

            CreatePlayerNameBox(row.transform, "PlayerA", SafePlayerName(playerAName), playerAWinner, secondaryTextColor);

            GameObject scoreBox = UIFactory.CreatePanel(row.transform, "ScoreBox", new Color(0.05f, 0.07f, 0.11f, 1f));
            SetLayout(scoreBox, 110f, 58f);
            Text scoreText = UIFactory.CreateText(scoreBox.transform, "Score", scoreA + ":" + scoreB, 30, FontStyle.Bold, TextAnchor.MiddleCenter);
            scoreText.color = Color.white;
            UIFactory.Stretch(scoreText.rectTransform, 4, 2, 4, 2);

            CreatePlayerNameBox(row.transform, "PlayerB", SafePlayerName(playerBName), playerBWinner, secondaryTextColor);
        }

        private static void ConfigureScoreInput(InputField input)
        {
            if (input == null || input.textComponent == null)
            {
                return;
            }

            input.textComponent.fontSize = 28;
            input.textComponent.fontStyle = FontStyle.Bold;
            input.textComponent.alignment = TextAnchor.MiddleCenter;
            input.textComponent.color = Color.white;

            Image image = input.GetComponent<Image>();
            if (image != null)
            {
                image.color = new Color(0.05f, 0.07f, 0.11f, 1f);
            }
        }

        private static string SafePlayerName(string playerName)
        {
            return string.IsNullOrWhiteSpace(playerName) || playerName == "TBD" ? "Do ustalenia" : playerName;
        }

        private static void CreatePlayerNameBox(
            Transform parent,
            string objectName,
            string playerName,
            bool winner,
            Color textColor,
            TournamentManager manager = null,
            string matchId = "",
            MatchSlot slot = MatchSlot.A,
            string participantId = "",
            UnityEngine.Events.UnityAction onClick = null)
        {
            GameObject box = UIFactory.CreatePanel(parent, objectName + "Box", new Color(1f, 1f, 1f, 0.08f));
            SetLayout(box, 88f, 58f);

            if (manager != null)
            {
                BracketParticipantDropZone dropZone = box.AddComponent<BracketParticipantDropZone>();
                dropZone.ConfigureSlot(manager, matchId, slot);
            }

            if (onClick != null)
            {
                Button button = box.AddComponent<Button>();
                button.targetGraphic = box.GetComponent<Image>();
                button.onClick.AddListener(onClick);
            }

            if (!string.IsNullOrEmpty(participantId))
            {
                BracketParticipantDragItem drag = box.AddComponent<BracketParticipantDragItem>();
                drag.Configure(participantId, matchId, slot, true, playerName);
            }

            Text text = UIFactory.CreateText(box.transform, objectName, playerName, 16, FontStyle.Bold, TextAnchor.MiddleCenter);
            text.color = winner ? new Color(0.62f, 1f, 0.72f, 1f) : textColor;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            UIFactory.Stretch(text.rectTransform, 6, 4, 6, 4);
        }

        private static void SetButtonTextSize(Button button, int size)
        {
            Text label = button == null ? null : button.GetComponentInChildren<Text>();
            if (label == null)
            {
                return;
            }

            label.fontSize = size;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
        }

        private static string FormatPlayerName(Tournament tournament, string participantId, string fallbackName)
        {
            if (string.IsNullOrWhiteSpace(participantId))
            {
                return "Do ustalenia";
            }

            Participant participant = TournamentLookup.Participant(tournament, participantId);
            if (participant == null)
            {
                return string.IsNullOrWhiteSpace(fallbackName) || fallbackName == "TBD" ? "Do ustalenia" : fallbackName;
            }

            string seed = tournament.visualSettings.showSeeds ? "#" + participant.seed + " " : string.Empty;
            string rank = string.IsNullOrWhiteSpace(participant.rankName) ? string.Empty : " [" + participant.rankName + "]";
            return seed + participant.displayName + rank;
        }

        private static void AddLayout(GameObject target, float preferredWidth, float preferredHeight)
        {
            SetLayout(target, preferredWidth, preferredHeight);
        }

        private static void SetLayout(GameObject target, float preferredWidth, float preferredHeight)
        {
            LayoutElement layout = target.GetComponent<LayoutElement>();
            if (layout == null)
            {
                layout = target.AddComponent<LayoutElement>();
            }

            layout.minWidth = preferredWidth;
            layout.preferredWidth = preferredWidth;
            layout.minHeight = preferredHeight;
            layout.preferredHeight = preferredHeight;
        }

        private static int CompletedCount(Round round)
        {
            int count = 0;
            foreach (Match match in round.matches)
            {
                if (match.IsFinished())
                {
                    count++;
                }
            }

            return count;
        }
    }
}
