using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.UI
{
    public static class TournamentUIText
    {
        public static string FormatName(TournamentFormatType format)
        {
            switch (format)
            {
                case TournamentFormatType.SingleElimination:
                    return "Drabinka pojedynczej eliminacji";
                case TournamentFormatType.Swiss:
                    return "Swiss";
                case TournamentFormatType.SwissToBracket:
                    return "Swiss + drabinka";
                case TournamentFormatType.RoundRobin:
                    return "Kazdy z kazdym";
                case TournamentFormatType.GroupsToBracket:
                    return "Grupy + drabinka";
                case TournamentFormatType.DoubleElimination:
                    return "Podwojna eliminacja";
                default:
                    return format.ToString();
            }
        }

        public static string ParticipantName(Tournament tournament, string participantId)
        {
            string name = TournamentLookup.ParticipantName(tournament, participantId);
            return name == "TBD" ? "Do ustalenia" : name;
        }

        public static string Status(MatchStatus status)
        {
            switch (status)
            {
                case MatchStatus.Pending:
                    return "Oczekuje";
                case MatchStatus.Ready:
                    return "Gotowy";
                case MatchStatus.Live:
                    return "Aktualnie grany";
                case MatchStatus.Completed:
                    return "Zakonczony";
                case MatchStatus.Bye:
                    return "Wolny los";
                case MatchStatus.Walkover:
                    return "Walkower";
                case MatchStatus.Delayed:
                    return "Opozniony";
                case MatchStatus.Cancelled:
                    return "Anulowany";
                case MatchStatus.Disqualified:
                    return "Dyskwalifikacja";
                case MatchStatus.ResultDisputed:
                    return "Wymaga korekty";
                default:
                    return status.ToString();
            }
        }

        public static Color StatusColor(MatchStatus status, bool active)
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            if (active)
            {
                return theme.MatchActiveColor;
            }

            switch (status)
            {
                case MatchStatus.Pending:
                    return theme.MatchPendingColor;
                case MatchStatus.Ready:
                    return theme.MatchReadyColor;
                case MatchStatus.Live:
                    return theme.MatchActiveColor;
                case MatchStatus.Completed:
                    return theme.MatchCompletedColor;
                case MatchStatus.ResultDisputed:
                case MatchStatus.Cancelled:
                case MatchStatus.Disqualified:
                    return theme.MatchProblemColor;
                case MatchStatus.Walkover:
                case MatchStatus.Bye:
                    return theme.WalkoverColor;
                default:
                    return theme.ButtonSecondaryColor;
            }
        }

        public static string RoundMatchLabel(Tournament tournament, Match match)
        {
            if (match == null)
            {
                return "Mecz nie wybrany";
            }

            TournamentPhase phase = TournamentLookup.Phase(tournament, match.phaseId);
            Round round = TournamentLookup.Round(phase, match.roundIndex);
            int matchCount = round == null || round.matches == null ? 0 : round.matches.Count;
            string roundName = round == null ? "Runda " + (match.roundIndex + 1) : round.name;
            return roundName + " - Mecz " + (match.matchIndex + 1) + " z " + matchCount;
        }

        public static string ScoreLine(Tournament tournament, Match match)
        {
            if (match == null)
            {
                return "-";
            }

            return ParticipantName(tournament, match.participantAId) + " " + match.scoreA + " : " + match.scoreB + " " + ParticipantName(tournament, match.participantBId);
        }
    }
}
