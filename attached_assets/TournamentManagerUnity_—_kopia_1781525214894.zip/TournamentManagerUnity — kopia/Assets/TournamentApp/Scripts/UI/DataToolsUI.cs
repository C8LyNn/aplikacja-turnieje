using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class DataToolsUI
    {
        public static void Render(Transform parent, TournamentManager manager, System.Action refresh = null, System.Action<string, string, string, System.Action> confirm = null)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20, FontStyle.Bold);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Dane turnieju", 26, FontStyle.Bold);
            UIFactory.CreateText(parent, "SaveInfo", manager.LastSaveInfo, 16, FontStyle.Bold);

            RenderThemeSelector(parent, manager, refresh);

            GameObject mainRow = UIFactory.CreateRow(parent, "DataActions", 8);
            UIFactory.CreateButton(mainRow.transform, "Zapisz turniej", () => manager.SaveTournament(), new Color(0.18f, 0.48f, 0.28f, 1f));
            UIFactory.CreateButton(mainRow.transform, "Eksportuj wyniki", () => manager.ExportResultsCsv(), new Color(0.18f, 0.34f, 0.62f, 1f));
            UIFactory.CreateButton(mainRow.transform, "Eksportuj tabele", () => manager.ExportStandingsCsv(), new Color(0.18f, 0.34f, 0.62f, 1f));

            UIFactory.CreateText(parent, "RoundToolsTitle", "Operacje turniejowe", 19, FontStyle.Bold);
            GameObject roundRow = UIFactory.CreateRow(parent, "RoundActions", 8);
            UIFactory.CreateButton(roundRow.transform, "Wygeneruj nastepna runde", () =>
            {
                if (confirm != null)
                {
                    confirm(
                        "Czy na pewno wygenerowac nastepna runde?",
                        "Ta akcja utworzy snapshot i moze zablokowac zwykla edycje zakonczonej rundy.",
                        "Wygeneruj runde",
                        () => manager.GenerateNextRound()
                    );
                }
                else
                {
                    manager.GenerateNextRound();
                }
            }, new Color(0.12f, 0.16f, 0.24f, 1f));
            UIFactory.CreateButton(roundRow.transform, "Test: zasymuluj runde", () =>
            {
                if (confirm != null)
                {
                    confirm("Zasymulowac runde testowo?", "To jest funkcja testowa/dev i automatycznie wpisze wyniki niezakonczonych meczow.", "Zasymuluj runde", () => manager.RandomlyCompleteCurrentRound());
                }
                else
                {
                    manager.RandomlyCompleteCurrentRound();
                }
            }, new Color(0.32f, 0.24f, 0.12f, 1f));

            UIFactory.CreateText(parent, "DemoTitle", "Tryb testowy / demo", 19, FontStyle.Bold);
            GameObject demoRow = UIFactory.CreateRow(parent, "DemoActions", 8);
            CreateDemoButton(demoRow.transform, manager, confirm, "Demo: 8 graczy", TournamentFormatType.SingleElimination, 8);
            CreateDemoButton(demoRow.transform, manager, confirm, "Demo: 16 graczy", TournamentFormatType.SingleElimination, 16);
            CreateDemoButton(demoRow.transform, manager, confirm, "Demo: 32 graczy", TournamentFormatType.SingleElimination, 32);
            CreateDemoButton(demoRow.transform, manager, confirm, "Demo: Swiss 10", TournamentFormatType.Swiss, 10);

            UIFactory.CreateText(parent, "InfoTitle", "Podsumowanie", 19, FontStyle.Bold);
            UIFactory.CreateText(parent, "Info",
                "Format: " + TournamentUIText.FormatName(tournament.settings.formatType) +
                "\nUczestnicy: " + tournament.participants.Count +
                "\nStatus: " + TournamentStatusText(tournament.status) +
                "\nWyniki zapisane w historii: " + tournament.resultHistory.Count,
                15);
        }

        private static void CreateDemoButton(Transform parent, TournamentManager manager, System.Action<string, string, string, System.Action> confirm, string label, TournamentFormatType format, int count)
        {
            UIFactory.CreateButton(parent, label, () =>
            {
                System.Action action = () => manager.CreateDemoTournament(format, count);
                if (confirm != null)
                {
                    confirm("Utworzyc turniej demo?", "Obecny turniej zostanie zastapiony testowym turniejem. Uzywaj tego tylko do testow.", "Utworz demo", action);
                }
                else
                {
                    action();
                }
            }, new Color(0.18f, 0.34f, 0.62f, 1f));
        }

        private static void RenderThemeSelector(Transform parent, TournamentManager manager, System.Action refresh)
        {
            TournamentThemePalette current = TournamentThemeManager.Current;
            GameObject panel = UIFactory.CreatePanel(parent, "ThemePanel", current.PanelColor);
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minWidth = 980f;
            panelLayout.preferredWidth = 1280f;
            panelLayout.minHeight = 190f;
            panelLayout.preferredHeight = 220f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(14, 14, 10, 10);
            vertical.spacing = 8;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            UIFactory.CreateText(panel.transform, "Title", "Wyglad aplikacji", 20, FontStyle.Bold);
            Text info = UIFactory.CreateText(panel.transform, "Info", "Motyw zmienia tylko wyglad aplikacji. Nie wplywa na dane turnieju.", 13);
            info.color = current.TextSecondaryColor;

            GameObject row = UIFactory.CreateRow(panel.transform, "ThemeButtons", 8);
            foreach (TournamentThemePalette palette in TournamentThemeManager.AllPalettes)
            {
                bool selected = palette.Id == TournamentThemeManager.CurrentId;
                Button button = UIFactory.CreateButton(
                    row.transform,
                    selected ? palette.DisplayName + " (aktywny)" : palette.DisplayName,
                    () =>
                    {
                        TournamentThemeManager.Select(palette.Id);
                        if (manager != null)
                        {
                            manager.SetMessage("Zmieniono motyw: " + palette.DisplayName + ".");
                        }

                        if (refresh != null)
                        {
                            refresh();
                        }
                    },
                    selected ? current.ActiveColor : current.ButtonPrimaryColor
                );

                LayoutElement buttonLayout = button.GetComponent<LayoutElement>();
                if (buttonLayout != null)
                {
                    buttonLayout.minWidth = 180f;
                    buttonLayout.preferredWidth = 220f;
                }
            }

            GameObject previewRow = UIFactory.CreateRow(panel.transform, "ThemePreviews", 8);
            foreach (TournamentThemePalette palette in TournamentThemeManager.AllPalettes)
            {
                CreateThemePreview(previewRow.transform, palette);
            }
        }

        private static void CreateThemePreview(Transform parent, TournamentThemePalette palette)
        {
            GameObject card = UIFactory.CreatePanel(parent, "ThemePreview_" + palette.Id, palette.PanelColor);
            card.GetComponent<Image>().color = palette.PanelColor;
            LayoutElement layout = card.AddComponent<LayoutElement>();
            layout.minWidth = 220f;
            layout.preferredWidth = 250f;
            layout.minHeight = 76f;
            layout.preferredHeight = 82f;

            VerticalLayoutGroup vertical = card.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(8, 8, 6, 6);
            vertical.spacing = 5;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Text title = UIFactory.CreateText(card.transform, "Name", palette.DisplayName, 13, FontStyle.Bold);
            title.color = palette.TextPrimaryColor;

            GameObject sampleRow = UIFactory.CreateRow(card.transform, "Sample", 5);
            GameObject sampleButton = UIFactory.CreatePanel(sampleRow.transform, "SampleButton", palette.ButtonPrimaryColor);
            sampleButton.GetComponent<Image>().color = palette.ButtonPrimaryColor;
            LayoutElement buttonLayout = sampleButton.AddComponent<LayoutElement>();
            buttonLayout.minWidth = 84f;
            buttonLayout.preferredWidth = 90f;
            buttonLayout.minHeight = 28f;
            buttonLayout.preferredHeight = 30f;
            Text buttonText = UIFactory.CreateText(sampleButton.transform, "Label", "Przycisk", 11, FontStyle.Bold, TextAnchor.MiddleCenter);
            buttonText.color = TournamentThemeManager.TextForBackground(palette.ButtonPrimaryColor);
            UIFactory.Stretch(buttonText.rectTransform, 4, 2, 4, 2);

            GameObject status = UIFactory.CreatePanel(sampleRow.transform, "SampleStatus", palette.MatchActiveColor);
            status.GetComponent<Image>().color = palette.MatchActiveColor;
            LayoutElement statusLayout = status.AddComponent<LayoutElement>();
            statusLayout.minWidth = 84f;
            statusLayout.preferredWidth = 90f;
            statusLayout.minHeight = 28f;
            statusLayout.preferredHeight = 30f;
            Text statusText = UIFactory.CreateText(status.transform, "Label", "Status", 11, FontStyle.Bold, TextAnchor.MiddleCenter);
            statusText.color = TournamentThemeManager.TextForBackground(palette.MatchActiveColor);
            UIFactory.Stretch(statusText.rectTransform, 4, 2, 4, 2);
        }

        private static string TournamentStatusText(TournamentStatus status)
        {
            switch (status)
            {
                case TournamentStatus.Setup:
                    return "Konfiguracja";
                case TournamentStatus.Running:
                    return "W toku";
                case TournamentStatus.Completed:
                    return "Zakonczony";
                case TournamentStatus.Cancelled:
                    return "Anulowany";
                default:
                    return status.ToString();
            }
        }
    }
}
