using System.Collections;
using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public class TournamentAppUI : MonoBehaviour
    {
        [SerializeField] private TournamentManager manager;

        private Canvas canvas;
        private GameObject rootObject;
        private Transform root;
        private Transform content;
        private string activeView = "main";
        private int selectedFormatIndex;
        private int selectedBestOf = 1;
        private int selectedEarlyRoundBestOf = 1;
        private int selectedQuarterFinalBestOf = 1;
        private int selectedSemiFinalBestOf = 1;
        private int selectedFinalBestOf = 1;
        private bool showStartSummary;
        private bool showCsvExample;
        private bool confirmClearParticipants;
        private readonly TournamentAssistantService assistantService = new TournamentAssistantService();
        private string pendingConfirmTitle;
        private string pendingConfirmBody;
        private string pendingConfirmActionLabel;
        private System.Action pendingConfirmAction;

        private void Start()
        {
            TournamentThemeManager.Current.ToString();
            if (manager == null)
            {
                manager = FindFirstObjectByType<TournamentManager>();
            }

            if (manager == null)
            {
                manager = gameObject.AddComponent<TournamentManager>();
            }

            manager.TournamentChanged += Render;
            EnsureCanvas();
            Render();
        }

        private void OnDestroy()
        {
            if (manager != null)
            {
                manager.TournamentChanged -= Render;
            }
        }

        private void EnsureCanvas()
        {
            canvas = FindFirstObjectByType<Canvas>();

            if (canvas == null)
            {
                GameObject canvasObject = new GameObject(
                    "TournamentAppCanvas",
                    typeof(RectTransform),
                    typeof(Canvas),
                    typeof(CanvasScaler),
                    typeof(GraphicRaycaster)
                );

                canvas = canvasObject.GetComponent<Canvas>();
            }

            canvas.renderMode = RenderMode.ScreenSpaceOverlay;

            CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
            if (scaler == null)
            {
                scaler = canvas.gameObject.AddComponent<CanvasScaler>();
            }

            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;

            if (canvas.GetComponent<GraphicRaycaster>() == null)
            {
                canvas.gameObject.AddComponent<GraphicRaycaster>();
            }
        }

        private void Render()
        {
            if (canvas == null)
            {
                EnsureCanvas();
            }

            Dictionary<string, Vector2> scrollSnapshot = CaptureScrollPositions();
            ClearCanvas();

            Tournament tournament = manager == null ? null : manager.CurrentTournament;
            TournamentThemePalette theme = TournamentThemeManager.Current;
            Color background = theme.BackgroundColor;

            rootObject = UIFactory.CreatePanel(canvas.transform, "TournamentAppRoot", background);
            root = rootObject.transform;
            UIFactory.Stretch(rootObject.GetComponent<RectTransform>());

            VerticalLayoutGroup vertical = rootObject.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(8, 8, 6, 2);
            vertical.spacing = 4;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = true;
            vertical.childForceExpandHeight = false;

            if (activeView != "main" && tournament != null)
            {
                RenderTopBar();
            }

            RenderMessageBar();
            if (activeView != "main" && tournament != null)
            {
                RenderAssistantPanel(tournament);
            }

            RenderConfirmationPanel();

            if (activeView == "main" || activeView == "setup" || tournament == null)
            {
                if (activeView == "setup")
                {
                    content = CreatePlainContent("SetupContent", TextAnchor.UpperCenter);
                    RenderSetup();
                }
                else
                {
                    content = CreatePlainContent("MainMenuContent", TextAnchor.UpperCenter);
                    RenderMainMenu();
                }

                RestoreScrollPositions(scrollSnapshot);
                return;
            }

            if (tournament.status == TournamentStatus.Setup)
            {
                content = CreatePlainContent("ParticipantsContent", TextAnchor.UpperCenter);
                RenderParticipantList();
                RestoreScrollPositions(scrollSnapshot);
                return;
            }

            content = CreatePlainContent("DashboardContent", TextAnchor.UpperCenter);
            RenderDashboard();
            RestoreScrollPositions(scrollSnapshot);
        }

        private Dictionary<string, Vector2> CaptureScrollPositions()
        {
            Dictionary<string, Vector2> snapshot = new Dictionary<string, Vector2>();
            if (canvas == null)
            {
                return snapshot;
            }

            ScrollRect[] scrollRects = canvas.GetComponentsInChildren<ScrollRect>(true);
            for (int i = 0; i < scrollRects.Length; i++)
            {
                ScrollRect scrollRect = scrollRects[i];
                string key = ScrollKey(scrollRect, i);
                snapshot[key] = new Vector2(scrollRect.horizontalNormalizedPosition, scrollRect.verticalNormalizedPosition);
            }

            return snapshot;
        }

        private void RestoreScrollPositions(Dictionary<string, Vector2> snapshot)
        {
            ApplyThemeReadabilityPass();
            if (snapshot == null || snapshot.Count == 0 || canvas == null)
            {
                return;
            }

            ApplyScrollPositions(snapshot);
            StartCoroutine(RestoreScrollPositionsAfterLayout(snapshot));
        }

        private void ApplyThemeReadabilityPass()
        {
            if (rootObject == null)
            {
                return;
            }

            Text[] texts = rootObject.GetComponentsInChildren<Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                Text text = texts[i];
                if (text == null)
                {
                    continue;
                }

                Image background = FindNearestBackground(text.transform);
                if (background == null)
                {
                    continue;
                }

                Color textColor = text.color;
                Color backgroundColor = background.color;
                float textLum = Luminance(textColor);
                float backgroundLum = Luminance(backgroundColor);
                float contrastGap = Mathf.Abs(textLum - backgroundLum);

                if (contrastGap >= 0.32f)
                {
                    continue;
                }

                Color readable = backgroundLum > 0.55f
                    ? new Color(0.04f, 0.05f, 0.07f, textColor.a)
                    : new Color(1f, 1f, 1f, textColor.a);
                text.color = readable;
            }
        }

        private Image FindNearestBackground(Transform start)
        {
            Transform current = start == null ? null : start.parent;
            while (current != null)
            {
                Image image = current.GetComponent<Image>();
                if (image != null && image.color.a > 0.05f)
                {
                    return image;
                }

                current = current.parent;
            }

            return null;
        }

        private float Luminance(Color color)
        {
            return color.r * 0.299f + color.g * 0.587f + color.b * 0.114f;
        }

        private IEnumerator RestoreScrollPositionsAfterLayout(Dictionary<string, Vector2> snapshot)
        {
            yield return null;
            ApplyScrollPositions(snapshot);
        }

        private void ApplyScrollPositions(Dictionary<string, Vector2> snapshot)
        {
            Canvas.ForceUpdateCanvases();

            ScrollRect[] scrollRects = canvas.GetComponentsInChildren<ScrollRect>(true);
            for (int i = 0; i < scrollRects.Length; i++)
            {
                ScrollRect scrollRect = scrollRects[i];
                Vector2 position;
                if (!snapshot.TryGetValue(ScrollKey(scrollRect, i), out position))
                {
                    continue;
                }

                if (scrollRect.horizontal)
                {
                    scrollRect.horizontalNormalizedPosition = position.x;
                }

                if (scrollRect.vertical)
                {
                    scrollRect.verticalNormalizedPosition = position.y;
                }
            }

            Canvas.ForceUpdateCanvases();
        }

        private string ScrollKey(ScrollRect scrollRect, int index)
        {
            string contentName = scrollRect != null && scrollRect.content != null ? scrollRect.content.name : "no-content";
            string objectName = scrollRect == null ? "no-scroll" : scrollRect.gameObject.name;
            return activeView + "|" + objectName + "|" + contentName + "|" + index;
        }

        private void RenderMainMenu()
        {
            Text title = UIFactory.CreateText(content, "Title", "Tournament Manager", 42, FontStyle.Bold, TextAnchor.MiddleCenter);
            LayoutElement titleLayout = title.gameObject.AddComponent<LayoutElement>();
            titleLayout.preferredHeight = 72;
            titleLayout.minWidth = 620;

            Text subtitle = UIFactory.CreateText(content, "Subtitle", "Tournament control app", 18, FontStyle.Normal, TextAnchor.MiddleCenter);
            LayoutElement subtitleLayout = subtitle.gameObject.AddComponent<LayoutElement>();
            subtitleLayout.preferredHeight = 36;
            subtitleLayout.minWidth = 620;

            GameObject row = UIFactory.CreateRow(content, "MainMenuButtons", 10);
            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.preferredHeight = 52;

            UIFactory.CreateButton(row.transform, "Nowy turniej", () =>
            {
                activeView = "setup";
                Render();
            });

            UIFactory.CreateButton(row.transform, "Wczytaj ostatni", () =>
            {
                if (manager.LoadLastTournament())
                {
                    activeView = "current";
                }

                Render();
            });

            UIFactory.CreateButton(row.transform, "Wyjdz", QuitApplication, new Color(0.42f, 0.16f, 0.15f, 1f));
        }

        private Transform CreatePlainContent(string name, TextAnchor alignment)
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject panel = UIFactory.CreatePanel(root, name, theme.BackgroundColor);

            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minHeight = 560f;
            layout.preferredHeight = 980f;
            layout.flexibleHeight = 1f;
            layout.flexibleWidth = 1f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(10, 10, 18, 4);
            vertical.spacing = 6;
            vertical.childAlignment = alignment;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            return panel.transform;
        }

        private void RenderSetup()
        {
            TournamentFormatType selectedFormat = FormatFromDropdown(selectedFormatIndex);
            bool usesSwissRounds = selectedFormat == TournamentFormatType.Swiss || selectedFormat == TournamentFormatType.SwissToBracket;
            bool usesTopCut = selectedFormat == TournamentFormatType.SwissToBracket;

            Text heading = UIFactory.CreateText(content, "Heading", "Ustawienia turnieju", 28, FontStyle.Bold, TextAnchor.MiddleCenter);
            LayoutElement headingLayout = heading.gameObject.AddComponent<LayoutElement>();
            headingLayout.preferredHeight = 42;
            headingLayout.minWidth = 620;

            Text helper = UIFactory.CreateText(
                content,
                "SetupHelp",
                "Ustaw podstawowe zasady turnieju. Pola Swiss pojawią się tylko dla formatów, które ich używają.",
                14,
                FontStyle.Normal,
                TextAnchor.MiddleCenter
            );
            helper.color = new Color(1f, 1f, 1f, 0.72f);

            LayoutElement helperLayout = helper.gameObject.AddComponent<LayoutElement>();
            helperLayout.preferredHeight = 28;
            helperLayout.minWidth = 720;

            RenderStartupThemeSelector();

            InputField nameInput = UIFactory.CreateLabeledInput(
                content,
                "Nazwa turnieju",
                "np. Bear Pit Tournament",
                "Bear Pit Tournament",
                "Nazwa widoczna w panelu prowadzącego."
            );

            RenderFormatSelector();
            RenderFormatDescription(selectedFormat);

            InputField participantCount = UIFactory.CreateLabeledInput(
                content,
                "Liczba graczy / uczestników",
                "np. 8, 12, 16",
                "8",
                "To jest limit uczestników. Testowi gracze będą generowani dokładnie według tej liczby."
            );

            RenderBestOfSelector();

            InputField bestOf = UIFactory.CreateLabeledInput(
                content,
                "Format meczu / Best of",
                "1 = BO1, 3 = BO3, 5 = BO5",
                "1",
                "Wpisz 1, 3 albo 5. Przykład: 3 oznacza BO3."
            );

            bestOf.transform.parent.gameObject.SetActive(false);

            InputField swissRounds = null;
            InputField topX = null;

            if (usesSwissRounds)
            {
                swissRounds = UIFactory.CreateLabeledInput(
                    content,
                    "Liczba rund Swiss",
                    "np. 4",
                    "4",
                    "Ile rund ma zostać rozegranych w systemie szwajcarskim."
                );
            }
            else
            {
                CreateMutedInfo("Ten format nie używa liczby rund Swiss.");
            }

            if (usesTopCut)
            {
                topX = UIFactory.CreateLabeledInput(
                    content,
                    "TOP X do drabinki",
                    "np. 8",
                    "8",
                    "Ilu najlepszych uczestników po Swissie awansuje do drabinki."
                );
            }
            else if (selectedFormat == TournamentFormatType.Swiss)
            {
                CreateMutedInfo("Czysty Swiss nie używa pola TOP X do drabinki.");
            }
            else
            {
                CreateMutedInfo("Ten format nie używa pola TOP X do drabinki.");
            }

            Toggle allowDraws = UIFactory.CreateToggle(content, "Remisy dozwolone", false);

            UIFactory.CreateButton(
                content,
                "Dalej",
                () =>
                {
                    TournamentSettings settings = TournamentSettings.CreateDefault();
                    settings.tournamentName = string.IsNullOrWhiteSpace(nameInput.text) ? "New Tournament" : nameInput.text;
                    settings.formatType = FormatFromDropdown(selectedFormatIndex);

                    int parsed;
                    if (int.TryParse(participantCount.text, out parsed))
                    {
                        settings.participantCount = Mathf.Max(2, parsed);
                    }

                    settings.bestOf = selectedBestOf;
                    settings.earlyRoundBestOf = selectedEarlyRoundBestOf;
                    settings.quarterFinalBestOf = selectedQuarterFinalBestOf;
                    settings.semiFinalBestOf = selectedSemiFinalBestOf;
                    settings.finalBestOf = selectedFinalBestOf;

                    if (swissRounds != null && int.TryParse(swissRounds.text, out parsed))
                    {
                        settings.swissRoundCount = Mathf.Max(1, parsed);
                    }

                    if (topX != null && int.TryParse(topX.text, out parsed))
                    {
                        settings.advanceTopXToBracket = Mathf.Max(2, parsed);
                    }

                    settings.allowDraws = allowDraws.isOn;

                    manager.CreateNewTournament(settings);
                    activeView = "participants";
                    Render();
                },
                new Color(0.18f, 0.48f, 0.28f, 1f)
            );
        }

        private void RenderStartupThemeSelector()
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject panel = UIFactory.CreatePanel(content, "StartupThemePanel", theme.PanelColor);
            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minWidth = 720f;
            layout.preferredWidth = 720f;
            layout.minHeight = 94f;
            layout.preferredHeight = 104f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 8, 8);
            vertical.spacing = 7;
            vertical.childAlignment = TextAnchor.UpperCenter;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Text title = UIFactory.CreateText(panel.transform, "Title", "Kolory aplikacji", 15, FontStyle.Bold, TextAnchor.MiddleCenter);
            title.color = theme.TextPrimaryColor;

            GameObject row = UIFactory.CreateRow(panel.transform, "ThemeButtons", 6);
            row.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;

            foreach (TournamentThemePalette palette in TournamentThemeManager.AllPalettes)
            {
                CreateStartupThemeButton(row.transform, palette);
            }

            Text hint = UIFactory.CreateText(panel.transform, "Hint", "Motyw zmienia tylko wyglad. Dane turnieju zostaja bez zmian.", 12, FontStyle.Normal, TextAnchor.MiddleCenter);
            hint.color = theme.TextSecondaryColor;
        }

        private void CreateStartupThemeButton(Transform parent, TournamentThemePalette palette)
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            bool selected = palette.Id == TournamentThemeManager.CurrentId;
            string label = selected ? palette.DisplayName + " *" : palette.DisplayName;
            Color color = selected ? theme.ActiveColor : theme.ButtonPrimaryColor;

            Button button = UIFactory.CreateButton(parent, label, () =>
            {
                TournamentThemeManager.Select(palette.Id);
                if (manager != null)
                {
                    manager.SetMessage("Zmieniono motyw: " + palette.DisplayName + ".");
                }

                Render();
            }, color);

            LayoutElement buttonLayout = button.GetComponent<LayoutElement>();
            if (buttonLayout != null)
            {
                buttonLayout.minWidth = 148f;
                buttonLayout.preferredWidth = 164f;
                buttonLayout.minHeight = 34f;
                buttonLayout.preferredHeight = 36f;
            }
        }

        private void RenderBestOfSelector()
        {
            GameObject panel = UIFactory.CreatePanel(content, "BestOfPanel", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minWidth = 720;
            panelLayout.preferredWidth = 720;
            panelLayout.minHeight = 210;
            panelLayout.preferredHeight = 220;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 8, 8);
            vertical.spacing = 6;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Text title = UIFactory.CreateText(panel.transform, "Title", "Format meczu / Best of", 15, FontStyle.Bold);
            LayoutElement titleLayout = title.gameObject.AddComponent<LayoutElement>();
            titleLayout.preferredHeight = 22;

            RenderBestOfRow(panel.transform, "Domyslnie", selectedBestOf, value => selectedBestOf = value);
            RenderBestOfRow(panel.transform, "Wczesne rundy", selectedEarlyRoundBestOf, value => selectedEarlyRoundBestOf = value);
            RenderBestOfRow(panel.transform, "Cwiercfinal", selectedQuarterFinalBestOf, value => selectedQuarterFinalBestOf = value);
            RenderBestOfRow(panel.transform, "Polfinal", selectedSemiFinalBestOf, value => selectedSemiFinalBestOf = value);
            RenderBestOfRow(panel.transform, "Final", selectedFinalBestOf, value => selectedFinalBestOf = value);
        }

        private void RenderBestOfRow(Transform parent, string label, int selectedValue, System.Action<int> setValue)
        {
            GameObject row = UIFactory.CreateRow(parent, "BestOfRow_" + label, 5);
            LayoutElement rowLayout = row.AddComponent<LayoutElement>();
            rowLayout.preferredHeight = 30;
            rowLayout.minWidth = 680;

            Text rowLabel = UIFactory.CreateText(row.transform, "Label", label, 13, FontStyle.Bold);
            LayoutElement labelLayout = rowLabel.gameObject.AddComponent<LayoutElement>();
            labelLayout.minWidth = 135;
            labelLayout.preferredWidth = 135;
            labelLayout.preferredHeight = 30;

            int[] values = { 1, 3, 5, 7, 9 };
            for (int i = 0; i < values.Length; i++)
            {
                int value = values[i];
                Button button = UIFactory.CreateButton(
                    row.transform,
                    "BO" + value,
                    () =>
                    {
                        setValue(value);
                        Render();
                    },
                    selectedValue == value ? new Color(1f, 0.78f, 0.18f, 1f) : new Color(0.18f, 0.34f, 0.62f, 1f)
                );

                LayoutElement buttonLayout = button.GetComponent<LayoutElement>();
                buttonLayout.minWidth = 70;
                buttonLayout.preferredWidth = 78;
                buttonLayout.minHeight = 28;
                buttonLayout.preferredHeight = 30;

                Text text = button.GetComponentInChildren<Text>();
                if (text != null && selectedValue == value)
                {
                    text.color = new Color(0.05f, 0.06f, 0.08f, 1f);
                }
            }
        }

        private void RenderFormatSelector()
        {
            Text label = UIFactory.CreateText(content, "FormatLabel", "Format turnieju", 15, FontStyle.Bold, TextAnchor.MiddleCenter);
            LayoutElement labelLayout = label.gameObject.AddComponent<LayoutElement>();
            labelLayout.preferredHeight = 24;
            labelLayout.minWidth = 720;

            GameObject column = UIFactory.CreateColumn(content, "FormatSelector", 8);
            LayoutElement columnLayout = column.AddComponent<LayoutElement>();
            columnLayout.preferredWidth = 720;
            columnLayout.minWidth = 720;

            string[] options =
            {
                "Pojedyncza eliminacja",
                "Swiss",
                "Swiss + drabinka",
                "Kazdy z kazdym",
                "Grupy + drabinka",
                "Podwojna eliminacja"
            };

            Color selectedColor = new Color(0.18f, 0.48f, 0.28f, 1f);
            Color normalColor = new Color(0.18f, 0.34f, 0.62f, 1f);

            for (int rowIndex = 0; rowIndex < 2; rowIndex++)
            {
                GameObject row = UIFactory.CreateRow(column.transform, "FormatRow", 8);
                LayoutElement rowLayout = row.AddComponent<LayoutElement>();
                rowLayout.preferredHeight = 46;
                rowLayout.minWidth = 720;

                for (int columnIndex = 0; columnIndex < 3; columnIndex++)
                {
                    int optionIndex = rowIndex * 3 + columnIndex;
                    Button button = UIFactory.CreateButton(
                        row.transform,
                        options[optionIndex],
                        () =>
                        {
                            selectedFormatIndex = optionIndex;
                            Render();
                        },
                        optionIndex == selectedFormatIndex ? selectedColor : normalColor
                    );

                    LayoutElement buttonLayout = button.GetComponent<LayoutElement>();
                    buttonLayout.preferredWidth = 230;
                    buttonLayout.minWidth = 230;
                }
            }
        }

        private void RenderFormatDescription(TournamentFormatType format)
        {
            GameObject panel = UIFactory.CreatePanel(content, "FormatDescriptionPanel", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minWidth = 720;
            panelLayout.preferredWidth = 720;
            panelLayout.minHeight = 150;
            panelLayout.preferredHeight = 170;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(14, 14, 10, 10);
            vertical.spacing = 5;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            string title;
            string shortDescription;
            string rules;
            string bestFor;
            string warning;

            GetFormatDescription(format, out title, out shortDescription, out rules, out bestFor, out warning);

            UIFactory.CreateText(panel.transform, "FormatDescriptionTitle", title, 17, FontStyle.Bold, TextAnchor.MiddleLeft);

            Text description = UIFactory.CreateText(panel.transform, "FormatDescriptionShort", shortDescription, 13, FontStyle.Normal, TextAnchor.MiddleLeft);
            description.color = new Color(1f, 1f, 1f, 0.86f);

            Text rulesText = UIFactory.CreateText(panel.transform, "FormatDescriptionRules", "Zasady: " + rules, 12, FontStyle.Normal, TextAnchor.MiddleLeft);
            rulesText.color = new Color(1f, 1f, 1f, 0.76f);

            Text bestForText = UIFactory.CreateText(panel.transform, "FormatDescriptionBestFor", "Najlepsze do: " + bestFor, 12, FontStyle.Normal, TextAnchor.MiddleLeft);
            bestForText.color = new Color(1f, 1f, 1f, 0.76f);

            Text warningText = UIFactory.CreateText(panel.transform, "FormatDescriptionWarning", "Uwaga: " + warning, 12, FontStyle.Bold, TextAnchor.MiddleLeft);
            warningText.color = new Color(1f, 0.84f, 0.45f, 0.95f);
        }

        private void GetFormatDescription(TournamentFormatType format, out string title, out string shortDescription, out string rules, out string bestFor, out string warning)
        {
            switch (format)
            {
                case TournamentFormatType.Swiss:
                    title = "Swiss";
                    shortDescription = "System szwajcarski. Gracze nie odpadają, a kolejne rundy dobierają osoby z podobnym wynikiem.";
                    rules = "ustalona liczba rund, punkty za wyniki, unikanie powtórzonych par, BYE przy nieparzystej liczbie graczy.";
                    bestFor = "większej liczby uczestników i turniejów krótszych niż każdy z każdym.";
                    warning = "wymaga ustawienia liczby rund Swiss.";
                    break;
                case TournamentFormatType.SwissToBracket:
                    title = "Swiss + Bracket";
                    shortDescription = "Najpierw kilka rund Swiss, potem najlepsi gracze przechodzą do drabinki finałowej.";
                    rules = "Swiss tworzy ranking, TOP X awansuje, finałowa drabinka działa jak Single Elimination.";
                    bestFor = "głównego formatu turnieju: sprawiedliwa faza eliminacyjna plus emocjonujące finały.";
                    warning = "wymaga ustawienia liczby rund Swiss i TOP X do drabinki.";
                    break;
                case TournamentFormatType.RoundRobin:
                    title = "Round Robin";
                    shortDescription = "Każdy gra z każdym.";
                    rules = "każdy uczestnik gra przeciwko każdemu innemu, a tabela decyduje o zwycięzcy.";
                    bestFor = "małych grup, lig i faz grupowych.";
                    warning = "placeholder MVP; przy dużej liczbie graczy liczba meczów szybko rośnie.";
                    break;
                case TournamentFormatType.GroupsToBracket:
                    title = "Groups + Bracket";
                    shortDescription = "Gracze są dzieleni na grupy, a najlepsi z grup awansują do drabinki.";
                    rules = "faza grupowa, awanse z grup, finałowa drabinka.";
                    bestFor = "turniejów z wieloma uczestnikami, poziomami albo fazą grupową.";
                    warning = "placeholder MVP; wymaga później konfiguracji grup i awansów.";
                    break;
                case TournamentFormatType.DoubleElimination:
                    title = "Double Elimination";
                    shortDescription = "Gracz odpada dopiero po dwóch porażkach.";
                    rules = "winner bracket, loser bracket, finał i opcjonalny bracket reset.";
                    bestFor = "turniejów, gdzie chcesz dać graczom drugą szansę.";
                    warning = "placeholder MVP; format jest dłuższy i trudniejszy do pokazania.";
                    break;
                case TournamentFormatType.SingleElimination:
                default:
                    title = "Single Elimination";
                    shortDescription = "Klasyczna drabinka pucharowa. Przegrany odpada, zwycięzca przechodzi dalej.";
                    rules = "każdy mecz eliminuje przegranego, zwycięzca przechodzi dalej, BYE przy nietypowej liczbie graczy.";
                    bestFor = "szybkich turniejów, playoffów, TOP 8 i TOP 16.";
                    warning = "jeden słaby mecz eliminuje gracza.";
                    break;
            }
        }

        private void CreateMutedInfo(string message)
        {
            Text info = UIFactory.CreateText(content, "Info", message, 13, FontStyle.Normal, TextAnchor.MiddleCenter);
            info.color = new Color(1f, 1f, 1f, 0.55f);

            LayoutElement infoLayout = info.gameObject.AddComponent<LayoutElement>();
            infoLayout.minWidth = 620;
            infoLayout.preferredWidth = 620;
            infoLayout.preferredHeight = 24;
        }

        private void RenderParticipantList()
        {
            Tournament tournament = manager.CurrentTournament;

            int targetCount = GetTargetParticipantCount(tournament);
            int currentCount = tournament.participants.Count;
            bool hasExactCount = currentCount == targetCount;
            bool hasTooMany = currentCount > targetCount;
            bool canAddMore = currentCount < targetCount;

            UIFactory.CreateText(content, "Heading", tournament.tournamentName + " - Uczestnicy", 26, FontStyle.Bold, TextAnchor.MiddleCenter);

            UIFactory.CreateText(
                content,
                "Settings",
                "Format: " + TournamentUIText.FormatName(tournament.settings.formatType) + " | BO: wczesne " + tournament.settings.earlyRoundBestOf + ", cwiercfinal " + tournament.settings.quarterFinalBestOf + ", polfinal " + tournament.settings.semiFinalBestOf + ", final " + tournament.settings.finalBestOf + " | rundy Swiss: " + tournament.settings.swissRoundCount + " | TOP X: " + tournament.settings.advanceTopXToBracket,
                15,
                FontStyle.Normal,
                TextAnchor.MiddleCenter
            );

            Text counter = UIFactory.CreateText(content, "ParticipantCounter", "Uczestnicy: " + currentCount + " / " + targetCount, 18, hasExactCount ? FontStyle.Bold : FontStyle.Normal, TextAnchor.MiddleCenter);
            counter.color = hasExactCount ? new Color(0.62f, 1f, 0.72f, 1f) : hasTooMany ? new Color(1f, 0.55f, 0.45f, 1f) : new Color(1f, 1f, 1f, 0.82f);

            if (showStartSummary && hasExactCount)
            {
                RenderStartSummary(tournament);
                return;
            }

            RenderCsvImportPanel(tournament, targetCount);

            if (canAddMore)
            {
                RenderManualParticipantAddRow(tournament, targetCount);
            }
            else
            {
                Text limitInfo = UIFactory.CreateText(
                    content,
                    "LimitInfo",
                    hasTooMany ? "Masz więcej uczestników niż ustawiony limit. Usuń nadmiar albo wygeneruj listę według ustawień." : "Osiągnięto ustawiony limit uczestników.",
                    14,
                    FontStyle.Bold,
                    TextAnchor.MiddleCenter
                );

                limitInfo.color = hasTooMany ? new Color(1f, 0.55f, 0.45f, 1f) : new Color(0.62f, 1f, 0.72f, 1f);
            }

            GameObject tools = UIFactory.CreateRow(content, "ParticipantTools", 8);

            UIFactory.CreateButton(tools.transform, "Wygeneruj testowych: " + targetCount, () =>
            {
                showStartSummary = false;
                manager.GenerateTestParticipants(targetCount);
            });

            if (hasExactCount)
            {
                UIFactory.CreateButton(
                    tools.transform,
                    "Dalej do podsumowania",
                    () =>
                    {
                        showStartSummary = true;
                        Render();
                    },
                    new Color(0.18f, 0.48f, 0.28f, 1f)
                );
            }
            else
            {
                Button disabledStart = UIFactory.CreateButton(tools.transform, "Start zablokowany", () => { }, new Color(0.2f, 0.22f, 0.27f, 1f));
                disabledStart.interactable = false;
            }

            if (!hasExactCount)
            {
                Text startHint = UIFactory.CreateText(content, "StartHint", "Turniej można rozpocząć dopiero wtedy, gdy liczba uczestników jest równa ustawieniu: " + targetCount + ".", 14, FontStyle.Normal, TextAnchor.MiddleCenter);
                startHint.color = new Color(1f, 0.84f, 0.45f, 0.95f);
            }

            Transform rowsParent = UIFactory.CreateScrollContent(content, "ParticipantRowsScroll");
            ConfigureParticipantRowsScroll(rowsParent);

            foreach (Participant participant in tournament.participants)
            {
                GameObject row = UIFactory.CreateRow(rowsParent, "ParticipantRow", 8);
                row.AddComponent<Image>().color = new Color(0.1f, 0.13f, 0.19f, 1f);

                Text label = UIFactory.CreateText(row.transform, "Participant", "#" + participant.seed + " " + participant.displayName + " | " + participant.rankName + " | " + participant.teamId + " | " + participant.country, 15);
                LayoutElement labelLayout = label.gameObject.AddComponent<LayoutElement>();
                labelLayout.preferredWidth = 680;

                string participantId = participant.id;
                string participantName = participant.displayName;
                UIFactory.CreateButton(row.transform, "Usun", () =>
                {
                    AskConfirmation(
                        "Usunac zawodnika?",
                        "Zawodnik: " + participantName + ". Ta akcja zmieni liste uczestnikow turnieju.",
                        "Usun zawodnika",
                        () =>
                        {
                            showStartSummary = false;
                            manager.RemoveParticipant(participantId);
                        }
                    );
                }, new Color(0.62f, 0.22f, 0.18f, 1f));
            }
        }

        private void RenderCsvImportPanel(Tournament tournament, int targetCount)
        {
            GameObject panel = UIFactory.CreatePanel(content, "CsvImportPanel", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            int summaryLines = string.IsNullOrWhiteSpace(manager.LastCsvImportSummary) ? 0 : manager.LastCsvImportSummary.Split('\n').Length;
            float dynamicHeight = 205f + (showCsvExample ? 76f : 0f) + (confirmClearParticipants ? 42f : 0f) + Mathf.Min(220f, summaryLines * 18f);
            panelLayout.minWidth = 760;
            panelLayout.preferredWidth = 880;
            panelLayout.minHeight = dynamicHeight;
            panelLayout.preferredHeight = dynamicHeight + 12f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(14, 14, 10, 10);
            vertical.spacing = 7;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            UIFactory.CreateText(panel.transform, "Title", "Import zawodnikow z CSV", 18, FontStyle.Bold);

            Text help = UIFactory.CreateText(
                panel.transform,
                "Help",
                "1. Utworz plik players.csv.\n" +
                "2. Wklej dane w formacie: nick;ranga;seed;druzyna;kraj\n" +
                "3. Zapisz plik jako CSV UTF-8.\n" +
                "4. Wrzuc plik do: Assets/StreamingAssets/Players/players.csv\n" +
                "5. Kliknij \"Wczytaj zawodnikow z CSV\".",
                13
            );
            help.color = new Color(1f, 1f, 1f, 0.78f);

            Text fileInfo = UIFactory.CreateText(
                panel.transform,
                "FileInfo",
                "Wymagany plik: Assets/StreamingAssets/Players/players.csv   |   Separator: srednik ;   |   Kodowanie: UTF-8",
                13,
                FontStyle.Bold
            );
            fileInfo.color = new Color(1f, 0.84f, 0.45f, 0.95f);

            GameObject buttons = UIFactory.CreateRow(panel.transform, "CsvButtons", 8);
            UIFactory.CreateButton(buttons.transform, "Wczytaj zawodnikow z CSV", () =>
            {
                showStartSummary = false;
                confirmClearParticipants = false;
                if (tournament.participants.Count > 0)
                {
                    AskConfirmation(
                        "Wczytac zawodnikow z CSV?",
                        "Import doda zawodnikow z pliku CSV do obecnej listy. Przed importem zostanie utworzony snapshot.",
                        "Wczytaj CSV",
                        () => manager.ImportPlayersFromDefaultCsv(targetCount)
                    );
                }
                else
                {
                    manager.ImportPlayersFromDefaultCsv(targetCount);
                }
            }, new Color(0.18f, 0.48f, 0.28f, 1f));

            UIFactory.CreateButton(buttons.transform, "Otworz folder importu", () => manager.OpenCsvImportFolder(), new Color(0.18f, 0.34f, 0.62f, 1f));
            UIFactory.CreateButton(buttons.transform, showCsvExample ? "Ukryj przyklad CSV" : "Pokaz przyklad CSV", () =>
            {
                showCsvExample = !showCsvExample;
                Render();
            }, new Color(0.17f, 0.23f, 0.34f, 1f));

            if (tournament.participants.Count > 0)
            {
                UIFactory.CreateButton(buttons.transform, "Wyczysc liste uczestnikow", () =>
                {
                    confirmClearParticipants = true;
                    Render();
                }, new Color(0.42f, 0.16f, 0.15f, 1f));
            }

            if (confirmClearParticipants)
            {
                GameObject confirmRow = UIFactory.CreateRow(panel.transform, "ClearConfirm", 8);
                UIFactory.CreateText(confirmRow.transform, "Question", "Czy na pewno usunac wszystkich uczestnikow?", 14, FontStyle.Bold);
                UIFactory.CreateButton(confirmRow.transform, "Tak, wyczysc", () =>
                {
                    confirmClearParticipants = false;
                    manager.ClearParticipantsInSetup();
                }, new Color(0.62f, 0.22f, 0.18f, 1f));
                UIFactory.CreateButton(confirmRow.transform, "Anuluj", () =>
                {
                    confirmClearParticipants = false;
                    Render();
                }, new Color(0.18f, 0.34f, 0.62f, 1f));
            }

            if (showCsvExample)
            {
                Text example = UIFactory.CreateText(
                    panel.transform,
                    "Example",
                    "Przyklad:\n" +
                    "nick;ranga;seed;druzyna;kraj\n" +
                    "Player 1;Gold;1;Team A;PL\n" +
                    "Player 2;Silver;2;Team B;PL",
                    13,
                    FontStyle.Normal
                );
                example.color = new Color(0.72f, 0.86f, 1f, 1f);
            }

            if (!string.IsNullOrWhiteSpace(manager.LastCsvImportSummary))
            {
                Text summary = UIFactory.CreateText(panel.transform, "Summary", manager.LastCsvImportSummary, 13, FontStyle.Bold);
                summary.color = manager.LastCsvImportSummary.StartsWith("Import zakonczony")
                    ? new Color(0.62f, 1f, 0.72f, 1f)
                    : new Color(1f, 0.63f, 0.52f, 1f);
            }
        }

        private void RenderStartSummary(Tournament tournament)
        {
            GameObject panel = UIFactory.CreatePanel(content, "StartSummaryPanel", new Color(0.08f, 0.11f, 0.16f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minWidth = 720;
            panelLayout.preferredWidth = 760;
            panelLayout.minHeight = 410;
            panelLayout.preferredHeight = 455;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(16, 16, 12, 12);
            vertical.spacing = 8;
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            UIFactory.CreateText(panel.transform, "Title", "Podsumowanie turnieju", 22, FontStyle.Bold);
            UIFactory.CreateText(panel.transform, "Name", "Nazwa: " + tournament.tournamentName, 15);
            UIFactory.CreateText(panel.transform, "Format", "Format: " + TournamentUIText.FormatName(tournament.settings.formatType), 15);
            UIFactory.CreateText(panel.transform, "Players", "Liczba graczy: " + tournament.participants.Count, 15);
            UIFactory.CreateText(panel.transform, "BestOf", "Mecze: BO" + tournament.settings.bestOf + " | Wczesne BO" + tournament.settings.earlyRoundBestOf + " | QF BO" + tournament.settings.quarterFinalBestOf + " | SF BO" + tournament.settings.semiFinalBestOf + " | Final BO" + tournament.settings.finalBestOf, 15);
            UIFactory.CreateText(panel.transform, "Rounds", "Szacowana liczba rund: " + EstimateRoundCount(tournament), 15);
            UIFactory.CreateText(panel.transform, "Matches", "Szacowana liczba meczow: " + EstimateMatchCount(tournament), 15);
            UIFactory.CreateText(panel.transform, "Draws", "Remisy: " + (tournament.settings.allowDraws ? "dozwolone" : "niedozwolone"), 15);

            if (tournament.settings.formatType == TournamentFormatType.SwissToBracket)
            {
                UIFactory.CreateText(panel.transform, "TopCut", "TOP do drabinki: " + tournament.settings.advanceTopXToBracket, 15);
            }

            UIFactory.CreateText(panel.transform, "ChecklistTitle", "Checklista przed startem", 17, FontStyle.Bold);
            List<TournamentChecklistItem> checklist = assistantService.BuildStartChecklist(tournament);
            bool startBlocked = false;
            foreach (TournamentChecklistItem item in checklist)
            {
                if (item.isBlocking && !item.isOk)
                {
                    startBlocked = true;
                }

                Text itemText = UIFactory.CreateText(panel.transform, "ChecklistItem", (item.isOk ? "[OK] " : "[X] ") + item.label, 13, FontStyle.Bold);
                itemText.color = item.isOk ? new Color(0.62f, 1f, 0.72f, 1f) : new Color(1f, 0.63f, 0.52f, 1f);
            }

            GameObject row = UIFactory.CreateRow(panel.transform, "Actions", 8);
            Button startButton = UIFactory.CreateButton(row.transform, startBlocked ? "Start zablokowany" : "Start turnieju", () =>
            {
                AskConfirmation(
                    "Czy na pewno wystartowac turniej?",
                    "Przed startem zostanie utworzony snapshot. Po starcie lista uczestnikow i pierwsza runda zostana zablokowane zwyklym trybem prowadzenia.",
                    "Start turnieju",
                    () =>
                    {
                        showStartSummary = false;
                        if (manager.StartTournament())
                        {
                            activeView = "current";
                            TrySelectFirstCurrentMatch(false);
                        }
                    }
                );
            }, new Color(0.18f, 0.48f, 0.28f, 1f));
            if (startBlocked)
            {
                startButton.interactable = false;
            }

            UIFactory.CreateButton(row.transform, "Wroc do edycji", () =>
            {
                showStartSummary = false;
                Render();
            }, new Color(0.18f, 0.34f, 0.62f, 1f));
        }

        private int EstimateRoundCount(Tournament tournament)
        {
            if (tournament == null || tournament.settings == null)
            {
                return 0;
            }

            if (tournament.settings.formatType == TournamentFormatType.Swiss)
            {
                return tournament.settings.swissRoundCount;
            }

            if (tournament.settings.formatType == TournamentFormatType.SwissToBracket)
            {
                return tournament.settings.swissRoundCount + Mathf.CeilToInt(Mathf.Log(Mathf.Max(2, tournament.settings.advanceTopXToBracket), 2f));
            }

            return Mathf.CeilToInt(Mathf.Log(Mathf.Max(2, tournament.participants.Count), 2f));
        }

        private int EstimateMatchCount(Tournament tournament)
        {
            if (tournament == null || tournament.settings == null)
            {
                return 0;
            }

            int count = Mathf.Max(0, tournament.participants.Count);
            if (tournament.settings.formatType == TournamentFormatType.Swiss)
            {
                return Mathf.CeilToInt(count / 2f) * tournament.settings.swissRoundCount;
            }

            if (tournament.settings.formatType == TournamentFormatType.SwissToBracket)
            {
                return Mathf.CeilToInt(count / 2f) * tournament.settings.swissRoundCount + Mathf.Max(0, tournament.settings.advanceTopXToBracket - 1);
            }

            return Mathf.Max(0, count - 1);
        }

        private void ConfigureParticipantRowsScroll(Transform rowsParent)
        {
            if (rowsParent == null || rowsParent.parent == null || rowsParent.parent.parent == null)
            {
                return;
            }

            Transform scrollObject = rowsParent.parent.parent;
            LayoutElement scrollLayout = scrollObject.GetComponent<LayoutElement>();
            if (scrollLayout != null)
            {
                scrollLayout.minHeight = 260f;
                scrollLayout.preferredHeight = 600f;
                scrollLayout.flexibleHeight = 1f;
                scrollLayout.minWidth = 780f;
                scrollLayout.preferredWidth = 860f;
                scrollLayout.flexibleWidth = 0f;
            }

            VerticalLayoutGroup rowsLayout = rowsParent.GetComponent<VerticalLayoutGroup>();
            if (rowsLayout != null)
            {
                rowsLayout.spacing = 3f;
                rowsLayout.padding = new RectOffset(4, 4, 4, 4);
            }
        }

        private void RenderManualParticipantAddRow(Tournament tournament, int targetCount)
        {
            GameObject addRow = UIFactory.CreateRow(content, "AddParticipant", 8);

            InputField nick = UIFactory.CreateInput(addRow.transform, "Nick", "");
            InputField rank = UIFactory.CreateInput(addRow.transform, "Ranga", "");
            InputField seed = UIFactory.CreateInput(addRow.transform, "Seed", (tournament.participants.Count + 1).ToString());
            InputField team = UIFactory.CreateInput(addRow.transform, "Drużyna", "");
            InputField country = UIFactory.CreateInput(addRow.transform, "Kraj", "PL");

            UIFactory.CreateButton(addRow.transform, "Dodaj", () =>
            {
                showStartSummary = false;
                if (tournament.participants.Count >= targetCount)
                {
                    Debug.LogWarning("Participant limit reached: " + targetCount);
                    Render();
                    return;
                }

                string nickname = string.IsNullOrWhiteSpace(nick.text) ? "Player " + (tournament.participants.Count + 1) : nick.text;

                int parsedSeed;
                if (!int.TryParse(seed.text, out parsedSeed))
                {
                    parsedSeed = tournament.participants.Count + 1;
                }

                if (parsedSeed <= 0 || parsedSeed > targetCount)
                {
                    parsedSeed = tournament.participants.Count + 1;
                }

                manager.AddParticipant(nickname, rank.text, parsedSeed, team.text, country.text);
            });
        }

        private int GetTargetParticipantCount(Tournament tournament)
        {
            if (tournament == null || tournament.settings == null)
            {
                return 8;
            }

            return Mathf.Max(2, tournament.settings.participantCount);
        }

        private void RenderDashboard()
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(content, "NoTournament", "Brak wczytanego turnieju.", 22, FontStyle.Bold);
                return;
            }

            if (string.IsNullOrEmpty(tournament.currentMatchId))
            {
                TrySelectFirstCurrentMatch(false);
            }

            string view = NormalizeDashboardView(activeView);
            if (view == "viewer")
            {
                GameObject returnRow = UIFactory.CreateRow(content, "ViewerReturnRow", 8);
                returnRow.GetComponent<HorizontalLayoutGroup>().childAlignment = TextAnchor.MiddleCenter;
                UIFactory.CreateButton(returnRow.transform, "Wroc do prowadzenia", () => SwitchView("current"));
            }
            else
            {
                HostControlPanelUI.Render(content, manager, view, SwitchView);
            }

            Transform viewContent = view == "bracket" || view == "bracketMap" || view == "viewer" || view == "current"
                ? CreateDashboardPlainViewContent()
                : CreateDashboardViewContent();

            if (view == "viewer")
            {
                manager.UpdateBroadcast(AppViewMode.CurrentMatch);
                AudienceViewUI.Render(viewContent, manager);
            }
            else if (view == "bracket")
            {
                manager.UpdateBroadcast(AppViewMode.Bracket);
                BracketViewUI.Render(viewContent, manager, true);
            }
            else if (view == "bracketMap")
            {
                manager.UpdateBroadcast(AppViewMode.Bracket);
                BracketMapViewUI.Render(viewContent, manager);
            }
            else if (view == "standings")
            {
                manager.UpdateBroadcast(AppViewMode.Standings);
                StandingsUI.Render(viewContent, manager);
            }
            else if (view == "results")
            {
                manager.UpdateBroadcast(AppViewMode.ResultsHistory);
                MatchScheduleUI.Render(viewContent, manager, true);
                ResultsHistoryUI.Render(viewContent, manager, true);
            }
            else if (view == "correction")
            {
                manager.UpdateBroadcast(AppViewMode.ResultsHistory);
                CorrectionViewUI.Render(viewContent, manager);
            }
            else if (view == "data")
            {
                DataToolsUI.Render(viewContent, manager, Render, AskConfirmation);
            }
            else if (view == "schedule")
            {
                manager.UpdateBroadcast(AppViewMode.Schedule);
                MatchScheduleUI.Render(viewContent, manager, true);
            }
            else if (view == "history")
            {
                manager.UpdateBroadcast(AppViewMode.ResultsHistory);
                ResultsHistoryUI.Render(viewContent, manager, true);
            }
            else
            {
                manager.UpdateBroadcast(AppViewMode.CurrentMatch);
                CurrentMatchViewUI.Render(viewContent, manager, false);
            }

            if (view != "bracket" && view != "bracketMap" && view != "viewer" && view != "current")
            {
                EnsureDashboardScrollContentHasSize(viewContent);
            }
        }

        private string NormalizeDashboardView(string view)
        {
            switch (view)
            {
                case "bracket":
                case "bracketMap":
                case "standings":
                case "results":
                case "correction":
                case "viewer":
                case "data":
                case "schedule":
                case "history":
                case "current":
                    return view;
                default:
                    return "current";
            }
        }

        private Transform CreateDashboardViewContent()
        {
            Transform viewContent = UIFactory.CreateScrollContent(content, "DashboardViewScroll");
            Transform scrollObject = viewContent.parent == null ? null : viewContent.parent.parent;

            if (scrollObject != null)
            {
                LayoutElement layout = scrollObject.GetComponent<LayoutElement>();
                if (layout != null)
                {
                    layout.minHeight = 520f;
                    layout.preferredHeight = 820f;
                    layout.flexibleHeight = 1f;
                    layout.minWidth = 1120f;
                    layout.preferredWidth = 1680f;
                    layout.flexibleWidth = 1f;
                }
            }

            return viewContent;
        }

        private Transform CreateDashboardPlainViewContent()
        {
            GameObject panel = UIFactory.CreatePanel(content, "DashboardViewContent", Color.clear);

            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minHeight = 520f;
            layout.preferredHeight = 820f;
            layout.flexibleHeight = 1f;
            layout.minWidth = 1120f;
            layout.preferredWidth = 1680f;
            layout.flexibleWidth = 1f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.spacing = 4;
            vertical.padding = new RectOffset(4, 4, 4, 0);
            vertical.childAlignment = TextAnchor.UpperLeft;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = true;
            vertical.childForceExpandHeight = false;

            return panel.transform;
        }

        private void EnsureDashboardScrollContentHasSize(Transform viewContent)
        {
            RectTransform contentRect = viewContent as RectTransform;
            if (contentRect == null)
            {
                return;
            }

            float height = 24f;
            for (int i = 0; i < viewContent.childCount; i++)
            {
                RectTransform childRect = viewContent.GetChild(i) as RectTransform;
                if (childRect == null)
                {
                    continue;
                }

                float childHeight = LayoutUtility.GetPreferredHeight(childRect);
                if (childHeight <= 0f)
                {
                    LayoutElement element = childRect.GetComponent<LayoutElement>();
                    childHeight = element == null || element.preferredHeight <= 0f ? 42f : element.preferredHeight;
                }

                height += childHeight + 6f;
            }

            contentRect.anchoredPosition = Vector2.zero;
            contentRect.sizeDelta = new Vector2(contentRect.sizeDelta.x, Mathf.Max(760f, height));
        }

        private void TrySelectFirstCurrentMatch(bool useManagerEvent)
        {
            Tournament tournament = manager == null ? null : manager.CurrentTournament;
            if (tournament == null || tournament.phases == null || !string.IsNullOrEmpty(tournament.currentMatchId))
            {
                return;
            }

            Match firstSelectable = null;
            foreach (TournamentPhase phase in tournament.phases)
            {
                if (phase.rounds == null)
                {
                    continue;
                }

                foreach (Round round in phase.rounds)
                {
                    if (round.matches == null)
                    {
                        continue;
                    }

                    foreach (Match match in round.matches)
                    {
                        if (IsMatchSelectable(match))
                        {
                            firstSelectable = match;
                            break;
                        }
                    }

                    if (firstSelectable != null)
                    {
                        break;
                    }
                }

                if (firstSelectable != null)
                {
                    break;
                }
            }

            if (firstSelectable == null)
            {
                return;
            }

            if (useManagerEvent)
            {
                manager.SetCurrentMatch(firstSelectable.id);
            }
            else
            {
                tournament.currentMatchId = firstSelectable.id;
            }
        }

        private bool IsMatchSelectable(Match match)
        {
            if (match == null)
            {
                return false;
            }

            return match.status == MatchStatus.Pending ||
                   match.status == MatchStatus.Ready ||
                   match.status == MatchStatus.Live ||
                   match.status == MatchStatus.Delayed ||
                   match.status == MatchStatus.ResultDisputed;
        }

        private void RenderTopBar()
        {
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject bar = UIFactory.CreatePanel(root, "TopBar", theme.HeaderColor);

            HorizontalLayoutGroup horizontal = bar.AddComponent<HorizontalLayoutGroup>();
            horizontal.padding = new RectOffset(8, 8, 6, 6);
            horizontal.spacing = 6;
            horizontal.childControlWidth = true;
            horizontal.childControlHeight = true;
            horizontal.childForceExpandWidth = false;
            horizontal.childForceExpandHeight = false;

            LayoutElement layout = bar.AddComponent<LayoutElement>();
            layout.preferredHeight = 54;

            string title = manager.CurrentTournament == null ? "Tournament Manager" : manager.CurrentTournament.tournamentName;
            Text titleText = UIFactory.CreateText(bar.transform, "Title", title, 22, FontStyle.Bold);
            LayoutElement titleLayout = titleText.gameObject.AddComponent<LayoutElement>();
            titleLayout.flexibleWidth = 1f;

            if (manager.CurrentTournament != null && manager.CurrentTournament.status == TournamentStatus.Setup)
            {
                UIFactory.CreateButton(bar.transform, "Ustawienia", () => SwitchView("participants"));
            }

            UIFactory.CreateButton(bar.transform, "Menu", () =>
            {
                activeView = "main";
                Render();
            });

            UIFactory.CreateButton(bar.transform, "Wyjdz", QuitApplication, theme.ButtonDangerColor);
        }

        private void RenderMessageBar()
        {
            string message = manager == null ? string.Empty : manager.LastMessage;

            if (manager != null && manager.LastValidationMessages != null && manager.LastValidationMessages.Count > 0)
            {
                message += "  " + manager.LastValidationMessages[0].message;
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                message = "Gotowy.";
            }

            if (manager != null && !string.IsNullOrWhiteSpace(manager.LastSaveInfo))
            {
                message += "   " + manager.LastSaveInfo;
            }

            Text text = UIFactory.CreateText(root, "Message", message, 14);
            LayoutElement layout = text.gameObject.AddComponent<LayoutElement>();
            layout.preferredHeight = 24;
        }

        private void RenderAssistantPanel(Tournament tournament)
        {
            if (tournament == null || activeView == "viewer")
            {
                return;
            }

            TournamentAssistantSnapshot snapshot = assistantService.BuildSnapshot(tournament);
            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject panel = UIFactory.CreatePanel(root, "AssistantPanel", theme.PanelSecondaryColor);
            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minHeight = 68f;
            bool showAssistantActions = tournament.status == TournamentStatus.Running && activeView != "current";
            layout.preferredHeight = (snapshot.warnings.Count > 0 ? 104f : 74f) + (showAssistantActions ? 44f : 0f);

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(12, 12, 8, 8);
            vertical.spacing = 4;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Text step = UIFactory.CreateText(panel.transform, "Step", snapshot.stepTitle, 16, FontStyle.Bold);
            step.color = theme.ActiveColor;
            Text next = UIFactory.CreateText(panel.transform, "Next", snapshot.nextAction, 14, FontStyle.Bold);
            next.color = theme.TextSecondaryColor;

            if (snapshot.warnings.Count > 0)
            {
                Text warning = UIFactory.CreateText(panel.transform, "Warnings", "Problemy do naprawienia: " + string.Join("  |  ", snapshot.warnings.GetRange(0, Mathf.Min(3, snapshot.warnings.Count))), 13, FontStyle.Bold);
                warning.color = theme.WarningColor;
            }

            if (showAssistantActions)
            {
                GameObject row = UIFactory.CreateRow(panel.transform, "AssistantActions", 8);
                UIFactory.CreateButton(row.transform, "Przejdz do aktualnego meczu", () => SwitchView("current"), theme.ButtonPrimaryColor);
                UIFactory.CreateButton(row.transform, "Ustaw nastepny mecz", () => manager.SelectNextPlayableMatch(), theme.ButtonSecondaryColor);
            }
        }

        private void AskConfirmation(string title, string body, string actionLabel, System.Action action)
        {
            pendingConfirmTitle = title;
            pendingConfirmBody = body;
            pendingConfirmActionLabel = actionLabel;
            pendingConfirmAction = action;
            Render();
        }

        private void ClearConfirmation()
        {
            pendingConfirmTitle = null;
            pendingConfirmBody = null;
            pendingConfirmActionLabel = null;
            pendingConfirmAction = null;
        }

        private void RenderConfirmationPanel()
        {
            if (pendingConfirmAction == null)
            {
                return;
            }

            TournamentThemePalette theme = TournamentThemeManager.Current;
            GameObject panel = UIFactory.CreatePanel(root, "ConfirmPanel", theme.PanelColor);
            LayoutElement layout = panel.AddComponent<LayoutElement>();
            layout.minHeight = 126f;
            layout.preferredHeight = 138f;

            VerticalLayoutGroup vertical = panel.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(14, 14, 10, 10);
            vertical.spacing = 6;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = false;
            vertical.childForceExpandHeight = false;

            Text title = UIFactory.CreateText(panel.transform, "Title", pendingConfirmTitle, 18, FontStyle.Bold);
            title.color = theme.WarningColor;
            Text body = UIFactory.CreateText(panel.transform, "Body", pendingConfirmBody, 14, FontStyle.Bold);
            body.color = theme.TextSecondaryColor;

            GameObject row = UIFactory.CreateRow(panel.transform, "Actions", 8);
            UIFactory.CreateButton(row.transform, pendingConfirmActionLabel, () =>
            {
                System.Action action = pendingConfirmAction;
                ClearConfirmation();
                action?.Invoke();
                Render();
            }, theme.ButtonDangerColor);
            UIFactory.CreateButton(row.transform, "Anuluj", () =>
            {
                ClearConfirmation();
                Render();
            }, theme.ButtonSecondaryColor);
        }

        private void SwitchView(string view)
        {
            if (view == "broadcast")
            {
                view = "current";
            }

            activeView = view;
            Render();
        }

        private void QuitApplication()
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        private TournamentFormatType FormatFromDropdown(int value)
        {
            switch (value)
            {
                case 0:
                    return TournamentFormatType.SingleElimination;
                case 1:
                    return TournamentFormatType.Swiss;
                case 2:
                    return TournamentFormatType.SwissToBracket;
                case 3:
                    return TournamentFormatType.RoundRobin;
                case 4:
                    return TournamentFormatType.GroupsToBracket;
                case 5:
                    return TournamentFormatType.DoubleElimination;
                default:
                    return TournamentFormatType.SingleElimination;
            }
        }

        private void ClearCanvas()
        {
            if (canvas == null)
            {
                return;
            }

            for (int i = canvas.transform.childCount - 1; i >= 0; i--)
            {
                Transform child = canvas.transform.GetChild(i);

                if (Application.isPlaying)
                {
                    Destroy(child.gameObject);
                }
                else
                {
                    DestroyImmediate(child.gameObject);
                }
            }
        }
    }
}
