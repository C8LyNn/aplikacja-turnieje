using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class BracketMapViewUI
    {
        private const float CardWidth = 224f;
        private const float CardHeight = 84f;
        private const float RoundGap = 60f;
        private const float BaseStride = 112f;
        private const float HeaderTop = 12f;
        private const float CardsTop = 58f;
        private const float Padding = 14f;
        private const float ViewHeight = 800f;
        private const float LineThickness = 3f;

        public static void Render(Transform parent, TournamentManager manager)
        {
            Tournament tournament = manager == null ? null : manager.CurrentTournament;
            if (tournament == null || tournament.phases == null || tournament.phases.Count == 0)
            {
                UIFactory.CreateText(parent, "Empty", "Brak danych drabinki.", 20, FontStyle.Bold);
                return;
            }

            BracketManualToolsUI.Render(parent, manager);

            foreach (TournamentPhase phase in tournament.phases)
            {
                if (phase == null || phase.rounds == null || phase.rounds.Count == 0)
                {
                    continue;
                }

                RenderPhaseMap(parent, manager, tournament, phase);
            }
        }

        private static void RenderPhaseMap(Transform parent, TournamentManager manager, Tournament tournament, TournamentPhase phase)
        {
            UIFactory.CreateText(
                parent,
                "BracketMapTitle",
                phase.name + " - schemat",
                24,
                FontStyle.Bold,
                TextAnchor.MiddleLeft
            );

            GameObject panel = UIFactory.CreatePanel(parent, "BracketMapPanel", new Color(0.035f, 0.045f, 0.07f, 1f));
            LayoutElement panelLayout = panel.AddComponent<LayoutElement>();
            panelLayout.minHeight = 560f;
            panelLayout.preferredHeight = ViewHeight;
            panelLayout.flexibleHeight = 1f;
            panelLayout.flexibleWidth = 1f;

            ScrollRect scrollRect = panel.AddComponent<ScrollRect>();
            scrollRect.horizontal = true;
            scrollRect.vertical = true;
            scrollRect.movementType = ScrollRect.MovementType.Clamped;
            scrollRect.inertia = true;
            scrollRect.scrollSensitivity = 45f;

            GameObject viewport = UIFactory.CreatePanel(panel.transform, "Viewport", new Color(0.07f, 0.055f, 0.17f, 1f));
            viewport.AddComponent<RectMask2D>();
            UIFactory.Stretch(viewport.GetComponent<RectTransform>(), 6f, 6f, 22f, 20f);

            GameObject content = new GameObject("BracketMapContent", typeof(RectTransform));
            content.transform.SetParent(viewport.transform, false);
            RectTransform contentRect = content.GetComponent<RectTransform>();
            contentRect.anchorMin = new Vector2(0f, 1f);
            contentRect.anchorMax = new Vector2(0f, 1f);
            contentRect.pivot = new Vector2(0f, 1f);

            Vector2 contentSize = CalculateContentSize(phase);
            contentRect.anchoredPosition = Vector2.zero;
            contentRect.sizeDelta = contentSize;

            scrollRect.viewport = viewport.GetComponent<RectTransform>();
            scrollRect.content = contentRect;

            Scrollbar vertical = CreateVerticalScrollbar(panel.transform);
            Scrollbar horizontal = CreateHorizontalScrollbar(panel.transform);
            scrollRect.verticalScrollbar = vertical;
            scrollRect.horizontalScrollbar = horizontal;
            scrollRect.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport;
            scrollRect.horizontalScrollbarVisibility = ScrollRect.ScrollbarVisibility.AutoHideAndExpandViewport;
            scrollRect.verticalNormalizedPosition = 1f;
            scrollRect.horizontalNormalizedPosition = 0f;

            Dictionary<string, Vector2> centers = BuildMatchCenters(phase);
            RenderRoundHeaders(content.transform, phase);
            RenderConnections(content.transform, phase, centers);
            RenderCards(content.transform, manager, tournament, phase, centers);
        }

        private static Vector2 CalculateContentSize(TournamentPhase phase)
        {
            int roundCount = Mathf.Max(1, phase.rounds.Count);
            int firstRoundMatches = phase.rounds.Count == 0 || phase.rounds[0].matches == null
                ? 1
                : Mathf.Max(1, phase.rounds[0].matches.Count);

            int maxMatches = firstRoundMatches;
            foreach (Round round in phase.rounds)
            {
                if (round != null && round.matches != null)
                {
                    maxMatches = Mathf.Max(maxMatches, round.matches.Count);
                }
            }

            float width = Padding * 2f + roundCount * CardWidth + Mathf.Max(0, roundCount - 1) * RoundGap;
            float height = CardsTop + Mathf.Max(maxMatches, firstRoundMatches) * BaseStride + CardHeight + Padding;
            return new Vector2(Mathf.Max(width, 1180f), Mathf.Max(height, 560f));
        }

        private static Dictionary<string, Vector2> BuildMatchCenters(TournamentPhase phase)
        {
            Dictionary<string, Vector2> centers = new Dictionary<string, Vector2>();
            bool linkedBracket = HasBracketLinks(phase);

            for (int roundIndex = 0; roundIndex < phase.rounds.Count; roundIndex++)
            {
                Round round = phase.rounds[roundIndex];
                if (round == null || round.matches == null)
                {
                    continue;
                }

                for (int matchIndex = 0; matchIndex < round.matches.Count; matchIndex++)
                {
                    Match match = round.matches[matchIndex];
                    if (match == null || string.IsNullOrEmpty(match.id))
                    {
                        continue;
                    }

                    float x = Padding + roundIndex * (CardWidth + RoundGap) + CardWidth * 0.5f;
                    float y = linkedBracket
                        ? CardsTop + (((matchIndex + 0.5f) * Mathf.Pow(2f, roundIndex)) - 0.5f) * BaseStride + CardHeight * 0.5f
                        : CardsTop + matchIndex * BaseStride + CardHeight * 0.5f;

                    centers[match.id] = new Vector2(x, y);
                }
            }

            return centers;
        }

        private static bool HasBracketLinks(TournamentPhase phase)
        {
            foreach (Round round in phase.rounds)
            {
                if (round == null || round.matches == null)
                {
                    continue;
                }

                foreach (Match match in round.matches)
                {
                    if (match != null && !string.IsNullOrEmpty(match.bracketNextMatchId))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static void RenderRoundHeaders(Transform parent, TournamentPhase phase)
        {
            for (int i = 0; i < phase.rounds.Count; i++)
            {
                Round round = phase.rounds[i];
                string title = round == null ? "Runda" : round.name;
                GameObject header = UIFactory.CreatePanel(parent, "RoundHeader", new Color(0.02f, 0.32f, 0.27f, 1f));
                SetRect(header, Padding + i * (CardWidth + RoundGap), HeaderTop, CardWidth, 28f);

                Text text = UIFactory.CreateText(header.transform, "Label", title, 12, FontStyle.Bold, TextAnchor.MiddleCenter);
                text.color = new Color(0.68f, 1f, 0.87f, 1f);
                UIFactory.Stretch(text.rectTransform, 4f, 2f, 4f, 2f);
            }
        }

        private static void RenderConnections(Transform parent, TournamentPhase phase, Dictionary<string, Vector2> centers)
        {
            Color lineColor = new Color(0.32f, 0.38f, 0.52f, 0.95f);
            Dictionary<string, List<Match>> incomingByNextMatch = new Dictionary<string, List<Match>>();

            foreach (Round round in phase.rounds)
            {
                if (round == null || round.matches == null)
                {
                    continue;
                }

                foreach (Match match in round.matches)
                {
                    if (match == null || string.IsNullOrEmpty(match.bracketNextMatchId))
                    {
                        continue;
                    }

                    List<Match> incoming;
                    if (!incomingByNextMatch.TryGetValue(match.bracketNextMatchId, out incoming))
                    {
                        incoming = new List<Match>();
                        incomingByNextMatch[match.bracketNextMatchId] = incoming;
                    }

                    incoming.Add(match);
                }
            }

            foreach (KeyValuePair<string, List<Match>> group in incomingByNextMatch)
            {
                Vector2 targetCenter;
                if (!centers.TryGetValue(group.Key, out targetCenter))
                {
                    continue;
                }

                List<Vector2> sourceCenters = new List<Vector2>();
                foreach (Match sourceMatch in group.Value)
                {
                    Vector2 sourceCenter;
                    if (sourceMatch != null && centers.TryGetValue(sourceMatch.id, out sourceCenter))
                    {
                        sourceCenters.Add(sourceCenter);
                    }
                }

                if (sourceCenters.Count == 0)
                {
                    continue;
                }

                DrawConnectionGroup(parent, sourceCenters, targetCenter, lineColor);
            }
        }

        private static void DrawConnectionGroup(Transform parent, List<Vector2> sourceCenters, Vector2 targetCenter, Color lineColor)
        {
            float sourceRightX = sourceCenters[0].x + CardWidth * 0.5f;
            float targetLeftX = targetCenter.x - CardWidth * 0.5f;

            foreach (Vector2 sourceCenter in sourceCenters)
            {
                sourceRightX = Mathf.Max(sourceRightX, sourceCenter.x + CardWidth * 0.5f);
            }

            if (targetLeftX <= sourceRightX)
            {
                return;
            }

            float midX = sourceRightX + (targetLeftX - sourceRightX) * 0.5f;
            float minY = sourceCenters[0].y;
            float maxY = sourceCenters[0].y;

            foreach (Vector2 sourceCenter in sourceCenters)
            {
                minY = Mathf.Min(minY, sourceCenter.y);
                maxY = Mathf.Max(maxY, sourceCenter.y);
                float startX = sourceCenter.x + CardWidth * 0.5f;
                DrawLine(parent, startX, sourceCenter.y, midX - startX, LineThickness, lineColor);
            }

            if (sourceCenters.Count == 1)
            {
                minY = Mathf.Min(minY, targetCenter.y);
                maxY = Mathf.Max(maxY, targetCenter.y);
            }
            else
            {
                minY = Mathf.Min(minY, targetCenter.y);
                maxY = Mathf.Max(maxY, targetCenter.y);
            }

            DrawLine(parent, midX - LineThickness * 0.5f, (minY + maxY) * 0.5f, LineThickness, maxY - minY, lineColor);
            DrawLine(parent, midX, targetCenter.y, targetLeftX - midX, LineThickness, lineColor);
        }

        private static void DrawLine(Transform parent, float x, float centerY, float width, float height, Color color)
        {
            if (width <= 0f || height <= 0f)
            {
                return;
            }

            GameObject line = UIFactory.CreatePanel(parent, "BracketLine", color);
            SetRect(line, x, centerY - height * 0.5f, width, height);
        }

        private static void RenderCards(
            Transform parent,
            TournamentManager manager,
            Tournament tournament,
            TournamentPhase phase,
            Dictionary<string, Vector2> centers)
        {
            foreach (Round round in phase.rounds)
            {
                if (round == null || round.matches == null)
                {
                    continue;
                }

                foreach (Match match in round.matches)
                {
                    Vector2 center;
                    if (match == null || !centers.TryGetValue(match.id, out center))
                    {
                        continue;
                    }

                    RenderMatchCard(parent, manager, tournament, match, center);
                }
            }
        }

        private static void RenderMatchCard(Transform parent, TournamentManager manager, Tournament tournament, Match match, Vector2 center)
        {
            bool active = tournament.currentMatchId == match.id;
            bool completed = match.IsFinished();

            TournamentThemePalette theme = TournamentThemeManager.Current;
            Color activeAccent = theme.ActiveColor;
            Color background = active
                ? theme.PanelSecondaryColor
                : completed
                    ? TournamentThemeManager.WithAlpha(theme.MatchCompletedColor, 0.32f)
                    : theme.PanelSecondaryColor;

            GameObject card = UIFactory.CreatePanel(parent, "BracketMapCard", background);
            SetRect(card, center.x - CardWidth * 0.5f, center.y - CardHeight * 0.5f, CardWidth, CardHeight);
            if (active)
            {
                Outline outline = card.AddComponent<Outline>();
                outline.effectColor = activeAccent;
                outline.effectDistance = new Vector2(2f, -2f);
            }

            Button cardButton = card.AddComponent<Button>();
            cardButton.targetGraphic = card.GetComponent<Image>();
            cardButton.onClick.AddListener(() => manager.SetCurrentMatch(match.id));

            VerticalLayoutGroup vertical = card.AddComponent<VerticalLayoutGroup>();
            vertical.padding = new RectOffset(6, 6, 5, 5);
            vertical.spacing = 3;
            vertical.childControlWidth = true;
            vertical.childControlHeight = true;
            vertical.childForceExpandWidth = true;
            vertical.childForceExpandHeight = false;

            Color headerColor = active
                ? theme.HeaderColor
                : completed
                    ? theme.SuccessColor
                    : theme.HeaderColor;

            GameObject header = UIFactory.CreatePanel(card.transform, "Header", headerColor);
            AddLayout(header, CardWidth - 12f, 18f);
            Text headerText = UIFactory.CreateText(header.transform, "Label", MatchLabel(match), 9, FontStyle.Bold, TextAnchor.MiddleLeft);
            headerText.color = active ? activeAccent : new Color(0.78f, 0.94f, 1f, 1f);
            UIFactory.Stretch(headerText.rectTransform, 5f, 1f, 5f, 1f);

            RenderPlayerRow(card.transform, manager, tournament, match, MatchSlot.A, match.participantAId, match.scoreA, match.winnerId == match.participantAId, active);
            RenderPlayerRow(card.transform, manager, tournament, match, MatchSlot.B, match.participantBId, match.scoreB, match.winnerId == match.participantBId, active);
        }

        private static void RenderPlayerRow(Transform parent, TournamentManager manager, Tournament tournament, Match match, MatchSlot slot, string participantId, int score, bool winner, bool active)
        {
            GameObject row = UIFactory.CreateRow(parent, "PlayerRow", 4f);
            AddLayout(row, CardWidth - 12f, 26f);

            HorizontalLayoutGroup horizontal = row.GetComponent<HorizontalLayoutGroup>();
            horizontal.childAlignment = TextAnchor.MiddleCenter;
            horizontal.childForceExpandWidth = false;

            Color nameColor = active
                ? Color.white
                : winner
                    ? new Color(0.48f, 1f, 0.66f, 1f)
                    : Color.white;

            GameObject nameBox = UIFactory.CreatePanel(row.transform, "NameBox", active ? new Color(1f, 1f, 1f, 0.10f) : new Color(1f, 1f, 1f, 0.06f));
            AddLayout(nameBox, 160f, 26f);
            BracketParticipantDropZone dropZone = nameBox.AddComponent<BracketParticipantDropZone>();
            dropZone.ConfigureSlot(manager, match.id, slot);

            Button nameButton = nameBox.AddComponent<Button>();
            nameButton.targetGraphic = nameBox.GetComponent<Image>();
            nameButton.onClick.AddListener(() => manager.SetCurrentMatch(match.id));

            if (!string.IsNullOrEmpty(participantId))
            {
                BracketParticipantDragItem drag = nameBox.AddComponent<BracketParticipantDragItem>();
                drag.Configure(participantId, match.id, slot, true, TournamentLookup.ParticipantName(tournament, participantId));
            }

            Text nameText = UIFactory.CreateText(nameBox.transform, "Name", ShortName(TournamentLookup.ParticipantName(tournament, participantId)), 13, FontStyle.Bold, TextAnchor.MiddleLeft);
            nameText.color = nameColor;
            nameText.horizontalOverflow = HorizontalWrapMode.Wrap;
            UIFactory.Stretch(nameText.rectTransform, 6f, 1f, 6f, 1f);

            GameObject scoreBox = UIFactory.CreatePanel(row.transform, "ScoreBox", new Color(0.035f, 0.045f, 0.07f, 1f));
            AddLayout(scoreBox, 44f, 26f);
            Text scoreText = UIFactory.CreateText(scoreBox.transform, "Score", score.ToString(), 18, FontStyle.Bold, TextAnchor.MiddleCenter);
            scoreText.color = Color.white;
            UIFactory.Stretch(scoreText.rectTransform, 2f, 0f, 2f, 0f);
        }

        private static string MatchLabel(Match match)
        {
            string status = match.status.ToString();
            return "Mecz " + (match.matchIndex + 1) + " | " + status;
        }

        private static string ShortName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return "TBD";
            }

            return value.Length <= 18 ? value : value.Substring(0, 17) + ".";
        }

        private static Scrollbar CreateVerticalScrollbar(Transform parent)
        {
            GameObject scrollbarObject = UIFactory.CreatePanel(parent, "MapVerticalScrollbar", new Color(0.09f, 0.11f, 0.16f, 1f));
            RectTransform rect = scrollbarObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(1f, 0f);
            rect.anchorMax = new Vector2(1f, 1f);
            rect.pivot = new Vector2(1f, 0.5f);
            rect.anchoredPosition = new Vector2(-8f, 10f);
            rect.sizeDelta = new Vector2(16f, -38f);

            Scrollbar scrollbar = scrollbarObject.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.BottomToTop;
            ConfigureScrollbarHandle(scrollbarObject.transform, scrollbar);
            return scrollbar;
        }

        private static Scrollbar CreateHorizontalScrollbar(Transform parent)
        {
            GameObject scrollbarObject = UIFactory.CreatePanel(parent, "MapHorizontalScrollbar", new Color(0.09f, 0.11f, 0.16f, 1f));
            RectTransform rect = scrollbarObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0f, 0f);
            rect.anchorMax = new Vector2(1f, 0f);
            rect.pivot = new Vector2(0.5f, 0f);
            rect.anchoredPosition = new Vector2(-8f, 8f);
            rect.sizeDelta = new Vector2(-44f, 16f);

            Scrollbar scrollbar = scrollbarObject.AddComponent<Scrollbar>();
            scrollbar.direction = Scrollbar.Direction.LeftToRight;
            ConfigureScrollbarHandle(scrollbarObject.transform, scrollbar);
            return scrollbar;
        }

        private static void ConfigureScrollbarHandle(Transform parent, Scrollbar scrollbar)
        {
            GameObject slidingArea = new GameObject("Sliding Area", typeof(RectTransform));
            slidingArea.transform.SetParent(parent, false);
            UIFactory.Stretch(slidingArea.GetComponent<RectTransform>(), 2f, 2f, 2f, 2f);

            GameObject handle = UIFactory.CreatePanel(slidingArea.transform, "Handle", new Color(0.25f, 0.43f, 0.72f, 1f));
            RectTransform handleRect = handle.GetComponent<RectTransform>();
            UIFactory.Stretch(handleRect);

            scrollbar.handleRect = handleRect;
            scrollbar.targetGraphic = handle.GetComponent<Image>();
            scrollbar.value = 1f;
        }

        private static void AddLayout(GameObject target, float width, float height)
        {
            LayoutElement layout = target.GetComponent<LayoutElement>();
            if (layout == null)
            {
                layout = target.AddComponent<LayoutElement>();
            }

            layout.minWidth = width;
            layout.preferredWidth = width;
            layout.minHeight = height;
            layout.preferredHeight = height;
            layout.flexibleWidth = 0f;
            layout.flexibleHeight = 0f;
        }

        private static void SetRect(GameObject target, float x, float y, float width, float height)
        {
            RectTransform rect = target.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0f, 1f);
            rect.anchorMax = new Vector2(0f, 1f);
            rect.pivot = new Vector2(0f, 1f);
            rect.anchoredPosition = new Vector2(x, -y);
            rect.sizeDelta = new Vector2(width, height);
        }
    }
}
