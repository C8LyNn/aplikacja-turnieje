using TournamentApp.Core;
using TournamentApp.Services;
using UnityEngine;
using UnityEngine.UI;

namespace TournamentApp.UI
{
    public static class ResultsHistoryUI
    {
        public static void Render(Transform parent, TournamentManager manager, bool admin)
        {
            Tournament tournament = manager.CurrentTournament;
            if (tournament == null)
            {
                UIFactory.CreateText(parent, "Empty", "Brak turnieju.", 20);
                return;
            }

            UIFactory.CreateText(parent, "Heading", "Historia wynikow", 24, FontStyle.Bold);
            if (tournament.resultHistory == null || tournament.resultHistory.Count == 0)
            {
                UIFactory.CreateText(parent, "NoResults", "Brak zapisanych wynikow.", 14);
                return;
            }

            for (int i = tournament.resultHistory.Count - 1; i >= 0; i--)
            {
                ResultRecord record = tournament.resultHistory[i];
                GameObject row = UIFactory.CreatePanel(parent, "ResultRow", new Color(0.1f, 0.13f, 0.19f, 1f));
                LayoutElement rowLayout = row.AddComponent<LayoutElement>();
                rowLayout.minWidth = 860;
                rowLayout.preferredWidth = 980;
                rowLayout.minHeight = admin ? 74 : 56;
                rowLayout.preferredHeight = admin ? 80 : 60;

                VerticalLayoutGroup vertical = row.AddComponent<VerticalLayoutGroup>();
                vertical.padding = new RectOffset(10, 10, 8, 8);
                vertical.spacing = 4;

                Match match = TournamentLookup.Match(tournament, record.matchId);
                string result =
                    record.updatedAt + " - Wpisano wynik\n" +
                    (match == null ? "Runda " + (record.roundIndex + 1) : TournamentUIText.RoundMatchLabel(tournament, match)) + " | " +
                    TournamentUIText.ParticipantName(tournament, record.participantAId) + " " + record.scoreA +
                    " : " + record.scoreB + " " +
                    TournamentUIText.ParticipantName(tournament, record.participantBId) +
                    " | Zwyciezca: " + TournamentUIText.ParticipantName(tournament, record.winnerId);

                if (record.wasEdited)
                {
                    result += " | edytowano x" + record.editCount;
                }

                UIFactory.CreateText(row.transform, "Result", result, 14, FontStyle.Bold);
            }
        }
    }
}
