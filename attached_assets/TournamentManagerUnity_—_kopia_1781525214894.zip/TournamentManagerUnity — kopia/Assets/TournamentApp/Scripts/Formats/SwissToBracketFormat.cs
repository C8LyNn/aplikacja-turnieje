using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;
using TournamentApp.Services;

namespace TournamentApp.Formats
{
    public class SwissToBracketFormat : ITournamentFormat
    {
        private readonly SwissFormat swissFormat = new SwissFormat();
        private readonly SingleEliminationFormat singleEliminationFormat = new SingleEliminationFormat();
        private readonly StandingsService standingsService = new StandingsService();

        public TournamentPhase GenerateInitialPhase(Tournament tournament)
        {
            TournamentPhase swiss = swissFormat.GenerateInitialPhase(tournament);
            swiss.name = "Swiss Stage";
            return swiss;
        }

        public TournamentPhase GenerateNextRound(Tournament tournament)
        {
            TournamentPhase current = TournamentLookup.CurrentPhase(tournament);
            if (current == null) return null;

            if (current.formatType == TournamentFormatType.Swiss && swissFormat.CanGenerateNextRound(tournament))
            {
                return swissFormat.GenerateNextRound(tournament);
            }

            if (current.formatType == TournamentFormatType.Swiss && IsSwissStageFinished(tournament, current) && !BracketAlreadyExists(tournament))
            {
                standingsService.RecalculateTournament(tournament);
                current.status = PhaseStatus.Completed;
                current.standingsSnapshot = standingsService.GetStandings(tournament);

                int topX = tournament.settings.advanceTopXToBracket <= 0
                    ? 8
                    : tournament.settings.advanceTopXToBracket;

                List<Participant> finalists = current.standingsSnapshot
                    .Take(topX)
                    .Select(standing => TournamentLookup.Participant(tournament, standing.participantId))
                    .Where(participant => participant != null)
                    .ToList();

                TournamentPhase bracket = singleEliminationFormat.GenerateBracketPhase(
                    tournament,
                    finalists,
                    tournament.phases.Count,
                    "TOP " + finalists.Count + " Bracket");

                tournament.currentPhaseId = bracket.id;
                tournament.currentRoundIndex = 0;
                return bracket;
            }

            return current;
        }

        public bool CanGenerateNextRound(Tournament tournament)
        {
            TournamentPhase current = TournamentLookup.CurrentPhase(tournament);
            if (current == null) return false;
            if (current.formatType == TournamentFormatType.Swiss)
            {
                return swissFormat.CanGenerateNextRound(tournament) ||
                       (IsSwissStageFinished(tournament, current) && !BracketAlreadyExists(tournament));
            }

            return false;
        }

        public void ApplyMatchResult(Tournament tournament, Match match, int scoreA, int scoreB)
        {
            TournamentPhase phase = TournamentLookup.Phase(tournament, match.phaseId);
            if (phase != null && phase.formatType == TournamentFormatType.SingleElimination)
            {
                singleEliminationFormat.ApplyMatchResult(tournament, match, scoreA, scoreB);
                return;
            }

            swissFormat.ApplyMatchResult(tournament, match, scoreA, scoreB);
        }

        public List<Standing> GetStandings(Tournament tournament)
        {
            return standingsService.GetStandings(tournament);
        }

        private bool IsSwissStageFinished(Tournament tournament, TournamentPhase phase)
        {
            return phase.rounds.Count >= tournament.settings.swissRoundCount &&
                   phase.rounds.Count > 0 &&
                   phase.rounds.All(round => round.matches.All(match => match.IsFinished()));
        }

        private bool BracketAlreadyExists(Tournament tournament)
        {
            return tournament.phases.Any(phase => phase.formatType == TournamentFormatType.SingleElimination);
        }
    }
}
