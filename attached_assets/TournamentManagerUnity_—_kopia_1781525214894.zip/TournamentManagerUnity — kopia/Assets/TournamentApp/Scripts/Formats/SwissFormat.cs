using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;
using TournamentApp.Services;

namespace TournamentApp.Formats
{
    public class SwissFormat : ITournamentFormat
    {
        private readonly StandingsService standingsService = new StandingsService();
        private readonly PairingService pairingService = new PairingService();

        public TournamentPhase GenerateInitialPhase(Tournament tournament)
        {
            TournamentPhase phase = new TournamentPhase
            {
                id = TournamentIds.NewId("phase"),
                name = "Swiss",
                formatType = TournamentFormatType.Swiss,
                phaseIndex = tournament.phases.Count,
                status = PhaseStatus.Running
            };

            Round firstRound = pairingService.CreateSwissRound(tournament, phase, 0, standingsService.GetStandings(tournament));
            phase.rounds.Add(firstRound);
            tournament.phases.Add(phase);
            tournament.currentPhaseId = phase.id;
            tournament.currentRoundIndex = 0;
            tournament.status = TournamentStatus.Running;
            return phase;
        }

        public TournamentPhase GenerateNextRound(Tournament tournament)
        {
            TournamentPhase phase = TournamentLookup.CurrentPhase(tournament);
            if (!CanGenerateNextRound(tournament)) return phase;

            List<Standing> standings = standingsService.RecalculateTournament(tournament);
            int nextRoundIndex = phase.rounds.Count;
            Round nextRound = pairingService.CreateSwissRound(tournament, phase, nextRoundIndex, standings);
            phase.rounds.Add(nextRound);
            tournament.currentPhaseId = phase.id;
            tournament.currentRoundIndex = nextRoundIndex;
            return phase;
        }

        public bool CanGenerateNextRound(Tournament tournament)
        {
            TournamentPhase phase = TournamentLookup.CurrentPhase(tournament);
            if (phase == null || phase.formatType != TournamentFormatType.Swiss) return false;
            if (phase.rounds.Count >= tournament.settings.swissRoundCount) return false;
            if (phase.rounds.Count == 0) return true;

            Round lastRound = phase.rounds[phase.rounds.Count - 1];
            return lastRound.matches.Count > 0 && lastRound.matches.All(match => match.IsFinished());
        }

        public void ApplyMatchResult(Tournament tournament, Match match, int scoreA, int scoreB)
        {
            if (match == null) return;

            match.scoreA = scoreA;
            match.scoreB = scoreB;
            match.status = MatchStatus.Completed;
            match.currentGameNumber = Math.Max(1, scoreA + scoreB);

            if (scoreA == scoreB && tournament.settings.allowDraws)
            {
                match.winnerId = string.Empty;
                match.loserId = string.Empty;
            }
            else if (scoreA > scoreB)
            {
                match.winnerId = match.participantAId;
                match.loserId = match.participantBId;
            }
            else
            {
                match.winnerId = match.participantBId;
                match.loserId = match.participantAId;
            }

            match.games.Clear();
            match.games.Add(new MatchGame
            {
                gameIndex = 1,
                scoreA = scoreA,
                scoreB = scoreB,
                winnerId = match.winnerId,
                status = match.status
            });

            TournamentPhase phase = TournamentLookup.Phase(tournament, match.phaseId);
            if (phase != null && phase.rounds.Count >= tournament.settings.swissRoundCount &&
                phase.rounds.All(round => round.matches.All(roundMatch => roundMatch.IsFinished())))
            {
                phase.status = PhaseStatus.Completed;
                if (tournament.settings.formatType == TournamentFormatType.Swiss)
                {
                    tournament.status = TournamentStatus.Completed;
                }
            }
        }

        public List<Standing> GetStandings(Tournament tournament)
        {
            return standingsService.GetStandings(tournament);
        }
    }
}
