using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;
using TournamentApp.Services;

namespace TournamentApp.Formats
{
    public class SingleEliminationFormat : ITournamentFormat
    {
        private readonly StandingsService standingsService = new StandingsService();

        public TournamentPhase GenerateInitialPhase(Tournament tournament)
        {
            List<Participant> participants = OrderedParticipants(tournament, tournament.participants);
            TournamentPhase phase = GenerateBracketPhase(tournament, participants, tournament.phases.Count, "Single Elimination");
            tournament.currentPhaseId = phase.id;
            tournament.currentRoundIndex = 0;
            tournament.status = TournamentStatus.Running;
            return phase;
        }

        public TournamentPhase GenerateBracketPhase(Tournament tournament, List<Participant> participants, int phaseIndex, string phaseName)
        {
            int bracketSize = NextPowerOfTwo(Math.Max(2, participants.Count));
            int roundCount = Log2(bracketSize);
            TournamentPhase phase = new TournamentPhase
            {
                id = TournamentIds.NewId("phase"),
                name = phaseName,
                formatType = TournamentFormatType.SingleElimination,
                phaseIndex = phaseIndex,
                status = PhaseStatus.Running
            };

            for (int roundIndex = 0; roundIndex < roundCount; roundIndex++)
            {
                int matchCount = bracketSize / (int)Math.Pow(2, roundIndex + 1);
                Round round = new Round
                {
                    roundIndex = roundIndex,
                    name = RoundName(roundIndex, roundCount),
                    startedAt = roundIndex == 0 ? TournamentTime.Now() : string.Empty
                };

                for (int matchIndex = 0; matchIndex < matchCount; matchIndex++)
                {
                    round.matches.Add(new Match
                    {
                        id = TournamentIds.NewId("match"),
                        phaseId = phase.id,
                        roundIndex = roundIndex,
                        matchIndex = matchIndex,
                        displayName = round.name + " - Match " + (matchIndex + 1),
                        bestOf = BestOfForRound(tournament.settings, roundIndex, roundCount),
                        currentGameNumber = 1,
                        status = MatchStatus.Pending,
                        scheduledOrder = matchIndex
                    });
                }

                phase.rounds.Add(round);
            }

            AssignNextMatchLinks(phase);
            AssignFirstRoundParticipants(phase, participants, bracketSize);
            ResolveFirstRoundByes(phase);
            RefreshReadyStates(phase);
            tournament.phases.Add(phase);
            return phase;
        }

        public TournamentPhase GenerateNextRound(Tournament tournament)
        {
            return TournamentLookup.CurrentPhase(tournament);
        }

        public bool CanGenerateNextRound(Tournament tournament)
        {
            return false;
        }

        public void ApplyMatchResult(Tournament tournament, Match match, int scoreA, int scoreB)
        {
            if (match == null) return;

            match.scoreA = scoreA;
            match.scoreB = scoreB;
            match.status = MatchStatus.Completed;
            match.currentGameNumber = Math.Max(1, scoreA + scoreB);

            if (scoreA == scoreB && tournament.settings.allowDraws)
            {
                match.winnerId = string.Empty;
                match.loserId = string.Empty;
            }
            else if (scoreA > scoreB)
            {
                match.winnerId = match.participantAId;
                match.loserId = match.participantBId;
            }
            else
            {
                match.winnerId = match.participantBId;
                match.loserId = match.participantAId;
            }

            EnsureSingleGame(match);
            AdvanceWinner(tournament, match);
            TournamentPhase phase = TournamentLookup.Phase(tournament, match.phaseId);
            RefreshReadyStates(phase);
            CompleteBracketIfFinal(tournament, phase, match);
        }

        public List<Standing> GetStandings(Tournament tournament)
        {
            return standingsService.GetStandings(tournament);
        }

        private List<Participant> OrderedParticipants(Tournament tournament, List<Participant> source)
        {
            List<Participant> participants = source.Where(participant => !participant.isDropped && !participant.isDisqualified).ToList();
            if (tournament.settings.useRandomSeeding)
            {
                System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
                return participants.OrderBy(_ => rng.Next()).ToList();
            }

            return participants
                .OrderBy(participant => participant.seed <= 0 ? int.MaxValue : participant.seed)
                .ThenBy(participant => participant.displayName)
                .ToList();
        }

        private void AssignNextMatchLinks(TournamentPhase phase)
        {
            for (int roundIndex = 0; roundIndex < phase.rounds.Count - 1; roundIndex++)
            {
                Round round = phase.rounds[roundIndex];
                Round nextRound = phase.rounds[roundIndex + 1];
                for (int matchIndex = 0; matchIndex < round.matches.Count; matchIndex++)
                {
                    Match match = round.matches[matchIndex];
                    match.bracketNextMatchId = nextRound.matches[matchIndex / 2].id;
                    match.bracketNextSlot = matchIndex % 2 == 0 ? MatchSlot.A : MatchSlot.B;
                }
            }
        }

        private void AssignFirstRoundParticipants(TournamentPhase phase, List<Participant> participants, int bracketSize)
        {
            Dictionary<int, Participant> participantBySeedRank = new Dictionary<int, Participant>();
            for (int i = 0; i < participants.Count; i++)
            {
                participantBySeedRank[i + 1] = participants[i];
            }

            List<int> seedOrder = BuildSeedOrder(bracketSize);
            Round firstRound = phase.rounds[0];
            for (int matchIndex = 0; matchIndex < firstRound.matches.Count; matchIndex++)
            {
                int seedA = seedOrder[matchIndex * 2];
                int seedB = seedOrder[matchIndex * 2 + 1];
                Match match = firstRound.matches[matchIndex];
                Participant a;
                Participant b;
                participantBySeedRank.TryGetValue(seedA, out a);
                participantBySeedRank.TryGetValue(seedB, out b);
                match.participantAId = a == null ? string.Empty : a.id;
                match.participantBId = b == null ? string.Empty : b.id;
                match.status = match.HasBothParticipants() ? MatchStatus.Ready : MatchStatus.Pending;
            }
        }

        private void ResolveFirstRoundByes(TournamentPhase phase)
        {
            if (phase.rounds.Count == 0) return;
            foreach (Match match in phase.rounds[0].matches)
            {
                bool hasA = !string.IsNullOrEmpty(match.participantAId);
                bool hasB = !string.IsNullOrEmpty(match.participantBId);
                if (hasA == hasB) continue;

                match.status = MatchStatus.Bye;
                match.isBye = true;
                match.scoreA = hasA ? 1 : 0;
                match.scoreB = hasB ? 1 : 0;
                match.winnerId = hasA ? match.participantAId : match.participantBId;
                match.loserId = string.Empty;
                AdvanceWinner(null, match, phase);
            }
        }

        private void AdvanceWinner(Tournament tournament, Match completedMatch, TournamentPhase knownPhase = null)
        {
            if (completedMatch == null || string.IsNullOrEmpty(completedMatch.winnerId) || string.IsNullOrEmpty(completedMatch.bracketNextMatchId))
            {
                return;
            }

            TournamentPhase phase = knownPhase ?? TournamentLookup.Phase(tournament, completedMatch.phaseId);
            Match next = TournamentLookup.Match(phase, completedMatch.bracketNextMatchId);
            if (next == null) return;

            if (completedMatch.bracketNextSlot == MatchSlot.A)
            {
                next.participantAId = completedMatch.winnerId;
            }
            else
            {
                next.participantBId = completedMatch.winnerId;
            }

            if (next.HasBothParticipants() && next.status == MatchStatus.Pending)
            {
                next.status = MatchStatus.Ready;
            }
        }

        private void RefreshReadyStates(TournamentPhase phase)
        {
            if (phase == null) return;
            foreach (Round round in phase.rounds)
            {
                foreach (Match match in round.matches)
                {
                    if (!match.IsFinished() && match.HasBothParticipants())
                    {
                        match.status = match.status == MatchStatus.Live ? MatchStatus.Live : MatchStatus.Ready;
                    }
                }
            }
        }

        private void CompleteBracketIfFinal(Tournament tournament, TournamentPhase phase, Match match)
        {
            if (tournament == null || phase == null || match == null) return;
            if (!string.IsNullOrEmpty(match.bracketNextMatchId)) return;
            if (!match.IsFinished()) return;

            phase.status = PhaseStatus.Completed;
            if (tournament.settings.formatType == TournamentFormatType.SingleElimination ||
                tournament.settings.formatType == TournamentFormatType.SwissToBracket)
            {
                tournament.status = TournamentStatus.Completed;
            }
        }

        private void EnsureSingleGame(Match match)
        {
            match.games.Clear();
            match.games.Add(new MatchGame
            {
                gameIndex = 1,
                scoreA = match.scoreA,
                scoreB = match.scoreB,
                winnerId = match.winnerId,
                status = match.status
            });
        }

        private int NextPowerOfTwo(int value)
        {
            int power = 1;
            while (power < value) power *= 2;
            return power;
        }

        private int Log2(int value)
        {
            int result = 0;
            while (value > 1)
            {
                value /= 2;
                result++;
            }
            return result;
        }

        private List<int> BuildSeedOrder(int bracketSize)
        {
            List<int> seeds = new List<int> { 1, 2 };
            for (int size = 4; size <= bracketSize; size *= 2)
            {
                List<int> next = new List<int>();
                foreach (int seed in seeds)
                {
                    next.Add(seed);
                    next.Add(size + 1 - seed);
                }
                seeds = next;
            }

            return seeds;
        }

        private string RoundName(int roundIndex, int roundCount)
        {
            int roundsLeft = roundCount - roundIndex;
            if (roundsLeft == 1) return "Grand Final";
            if (roundsLeft == 2) return "Semifinals";
            if (roundsLeft == 3) return "Quarterfinals";
            return "Round " + (roundIndex + 1);
        }

        private int BestOfForRound(TournamentSettings settings, int roundIndex, int roundCount)
        {
            int roundsLeft = roundCount - roundIndex;
            if (roundsLeft == 1) return NormalizeBestOf(settings.finalBestOf, settings.bestOf);
            if (roundsLeft == 2) return NormalizeBestOf(settings.semiFinalBestOf, settings.bestOf);
            if (roundsLeft == 3) return NormalizeBestOf(settings.quarterFinalBestOf, settings.bestOf);
            return NormalizeBestOf(settings.earlyRoundBestOf, settings.bestOf);
        }

        private int NormalizeBestOf(int value, int fallback)
        {
            int selected = value <= 0 ? fallback : value;
            if (selected <= 0) selected = 1;
            if (selected % 2 == 0) selected += 1;
            return Math.Min(9, selected);
        }
    }
}
