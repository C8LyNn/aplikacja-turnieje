using TournamentApp.Core;

namespace TournamentApp.Formats
{
    public static class TournamentFormatFactory
    {
        public static ITournamentFormat Create(TournamentFormatType formatType)
        {
            switch (formatType)
            {
                case TournamentFormatType.SingleElimination:
                    return new SingleEliminationFormat();
                case TournamentFormatType.Swiss:
                    return new SwissFormat();
                case TournamentFormatType.SwissToBracket:
                    return new SwissToBracketFormat();
                case TournamentFormatType.RoundRobin:
                    return new RoundRobinFormat();
                case TournamentFormatType.GroupsToBracket:
                    return new GroupsToBracketFormat();
                case TournamentFormatType.DoubleElimination:
                    return new DoubleEliminationFormat();
                default:
                    return new SingleEliminationFormat();
            }
        }
    }
}
