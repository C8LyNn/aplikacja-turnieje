using System.Collections.Generic;
using TournamentApp.Core;

namespace TournamentApp.Formats
{
    public interface ITournamentFormat
    {
        TournamentPhase GenerateInitialPhase(Tournament tournament);
        TournamentPhase GenerateNextRound(Tournament tournament);
        bool CanGenerateNextRound(Tournament tournament);
        void ApplyMatchResult(Tournament tournament, Match match, int scoreA, int scoreB);
        List<Standing> GetStandings(Tournament tournament);
    }
}
