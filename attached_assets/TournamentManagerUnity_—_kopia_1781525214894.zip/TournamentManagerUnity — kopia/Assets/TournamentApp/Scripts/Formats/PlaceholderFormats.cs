using System.Collections.Generic;
using TournamentApp.Core;
using TournamentApp.Services;

namespace TournamentApp.Formats
{
    public abstract class PlaceholderFormatBase : ITournamentFormat
    {
        private readonly StandingsService standingsService = new StandingsService();

        public abstract TournamentFormatType FormatType { get; }

        public TournamentPhase GenerateInitialPhase(Tournament tournament)
        {
            TournamentPhase phase = new TournamentPhase
            {
                id = TournamentIds.NewId("phase"),
                name = FormatType + " Placeholder",
                formatType = FormatType,
                phaseIndex = tournament.phases.Count,
                status = PhaseStatus.Pending
            };
            tournament.phases.Add(phase);
            tournament.currentPhaseId = phase.id;
            return phase;
        }

        public TournamentPhase GenerateNextRound(Tournament tournament)
        {
            return TournamentLookup.CurrentPhase(tournament);
        }

        public bool CanGenerateNextRound(Tournament tournament)
        {
            return false;
        }

        public void ApplyMatchResult(Tournament tournament, Match match, int scoreA, int scoreB)
        {
        }

        public List<Standing> GetStandings(Tournament tournament)
        {
            return standingsService.GetStandings(tournament);
        }
    }

    public class RoundRobinFormat : PlaceholderFormatBase
    {
        public override TournamentFormatType FormatType => TournamentFormatType.RoundRobin;
    }

    public class GroupsToBracketFormat : PlaceholderFormatBase
    {
        public override TournamentFormatType FormatType => TournamentFormatType.GroupsToBracket;
    }

    public class DoubleEliminationFormat : PlaceholderFormatBase
    {
        public override TournamentFormatType FormatType => TournamentFormatType.DoubleElimination;
    }
}
