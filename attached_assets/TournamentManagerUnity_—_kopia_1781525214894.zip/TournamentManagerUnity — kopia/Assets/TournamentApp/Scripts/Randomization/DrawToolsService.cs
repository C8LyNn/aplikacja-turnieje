using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Randomization
{
    public class DrawToolsService
    {
        public string DrawPrizeWinner(Tournament tournament, List<string> excludedParticipantIds)
        {
            if (tournament == null) return string.Empty;
            HashSet<string> excluded = excludedParticipantIds == null
                ? new HashSet<string>()
                : new HashSet<string>(excludedParticipantIds);

            List<Participant> candidates = tournament.participants
                .Where(participant => !excluded.Contains(participant.id) && !participant.isDropped && !participant.isDisqualified)
                .ToList();

            if (candidates.Count == 0) return string.Empty;
            System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
            return candidates[rng.Next(candidates.Count)].id;
        }

        public List<Match> CreateRandomShowMatches(Tournament tournament, bool avoidRepeatPairs, bool avoidSameTeam)
        {
            List<Match> matches = new List<Match>();
            if (tournament == null) return matches;

            System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
            List<Participant> pool = tournament.participants.OrderBy(_ => rng.Next()).ToList();
            while (pool.Count >= 2)
            {
                Participant a = pool[0];
                pool.RemoveAt(0);
                Participant b = pool.FirstOrDefault(candidate =>
                    (!avoidRepeatPairs || !a.opponentsPlayed.Contains(candidate.id)) &&
                    (!avoidSameTeam || string.IsNullOrEmpty(a.teamId) || a.teamId != candidate.teamId));
                if (b == null) b = pool[0];
                pool.Remove(b);

                matches.Add(new Match
                {
                    id = TournamentIds.NewId("custom_match"),
                    displayName = "Show Match " + (matches.Count + 1),
                    participantAId = a.id,
                    participantBId = b.id,
                    bestOf = tournament.settings.bestOf,
                    status = MatchStatus.Ready,
                    matchIndex = matches.Count,
                    scheduledOrder = matches.Count
                });
            }

            return matches;
        }
    }
}
