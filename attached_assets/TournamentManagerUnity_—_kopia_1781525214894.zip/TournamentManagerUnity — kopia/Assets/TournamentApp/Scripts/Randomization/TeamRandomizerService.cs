using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Randomization
{
    public class TeamRandomizerService
    {
        public List<Team> CreateRandomTeams(Tournament tournament, int teamCount, bool balanceRanks)
        {
            List<Team> teams = new List<Team>();
            if (tournament == null || teamCount <= 0) return teams;

            System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
            List<Participant> participants = balanceRanks
                ? tournament.participants.OrderByDescending(participant => participant.rankValue).ToList()
                : tournament.participants.OrderBy(_ => rng.Next()).ToList();

            for (int i = 0; i < teamCount; i++)
            {
                teams.Add(new Team
                {
                    id = TournamentIds.NewId("team"),
                    name = "Team " + (i + 1),
                    shortName = "T" + (i + 1),
                    seed = i + 1
                });
            }

            for (int i = 0; i < participants.Count; i++)
            {
                int index = balanceRanks && (i / teamCount) % 2 == 1 ? teamCount - 1 - (i % teamCount) : i % teamCount;
                Team team = teams[index];
                team.memberParticipantIds.Add(participants[i].id);
                participants[i].teamId = team.name;
            }

            tournament.teams = teams;
            return teams;
        }
    }
}
