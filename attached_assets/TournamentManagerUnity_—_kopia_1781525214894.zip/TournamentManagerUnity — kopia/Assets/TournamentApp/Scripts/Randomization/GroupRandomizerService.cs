using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Randomization
{
    [Serializable]
    public class RandomizedGroup
    {
        public string id;
        public string name;
        public List<string> participantIds = new List<string>();
    }

    public class GroupRandomizerService
    {
        public List<RandomizedGroup> CreateGroups(Tournament tournament, int groupCount, bool usePots)
        {
            List<RandomizedGroup> groups = new List<RandomizedGroup>();
            if (tournament == null || groupCount <= 0) return groups;

            for (int i = 0; i < groupCount; i++)
            {
                groups.Add(new RandomizedGroup
                {
                    id = TournamentIds.NewId("group"),
                    name = "Group " + (char)('A' + i)
                });
            }

            System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
            List<Participant> participants = usePots
                ? tournament.participants.OrderBy(participant => participant.seed <= 0 ? int.MaxValue : participant.seed).ToList()
                : tournament.participants.OrderBy(_ => rng.Next()).ToList();

            for (int i = 0; i < participants.Count; i++)
            {
                int index = usePots && (i / groupCount) % 2 == 1 ? groupCount - 1 - (i % groupCount) : i % groupCount;
                groups[index].participantIds.Add(participants[i].id);
            }

            return groups;
        }
    }
}
