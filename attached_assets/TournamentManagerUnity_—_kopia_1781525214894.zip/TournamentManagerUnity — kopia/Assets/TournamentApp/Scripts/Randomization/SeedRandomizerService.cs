using System;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Randomization
{
    public class SeedRandomizerService
    {
        public void RandomizeSeeds(Tournament tournament, bool keepManualSeeds)
        {
            if (tournament == null) return;
            System.Random rng = tournament.useFixedRandomSeed ? new System.Random(tournament.randomSeed) : new System.Random(Environment.TickCount);
            var participants = tournament.participants
                .Where(participant => !keepManualSeeds || participant.seed <= 0)
                .OrderBy(_ => rng.Next())
                .ToList();

            int nextSeed = keepManualSeeds
                ? tournament.participants.Where(participant => participant.seed > 0).Select(participant => participant.seed).DefaultIfEmpty(0).Max() + 1
                : 1;

            foreach (Participant participant in participants)
            {
                participant.seed = nextSeed++;
            }
        }
    }
}
