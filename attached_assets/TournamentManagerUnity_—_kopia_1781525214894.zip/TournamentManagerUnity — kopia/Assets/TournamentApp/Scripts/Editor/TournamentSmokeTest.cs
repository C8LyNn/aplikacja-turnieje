using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;
using TournamentApp.Services;
using UnityEditor;
using UnityEngine;

namespace TournamentApp.Editor
{
    public static class TournamentSmokeTest
    {
        [MenuItem("Tools/Tournament App/Run Logic Smoke Test")]
        public static void RunLogicSmokeTest()
        {
            RunSingleElimination(8);
            RunSingleElimination(12);
            RunSwiss(10);
            RunSwiss(11);
            RunSwissToBracket();
            Debug.Log("Tournament App logic smoke test passed.");
        }

        private static void RunSingleElimination(int participantCount)
        {
            TournamentManager manager = CreateManager("Smoke_Single_" + participantCount);
            try
            {
                TournamentSettings settings = TournamentSettings.CreateDefault();
                settings.tournamentName = "Smoke Single " + participantCount;
                settings.formatType = TournamentFormatType.SingleElimination;
                settings.bestOf = 1;
                settings.enableAutosave = false;
                manager.CreateNewTournament(settings);
                manager.GenerateTestParticipants(participantCount);
                Assert(manager.StartTournament(), "Single Elimination should start for " + participantCount);
                Assert(manager.CurrentTournament.phases.Count == 1, "Single should create one phase.");
                if (participantCount == 12)
                {
                    Assert(TournamentLookup.AllMatches(manager.CurrentTournament).Any(match => match.isBye), "Single 12 should contain BYE matches.");
                }

                SimulateUntilComplete(manager, 20);
                Assert(manager.CurrentTournament.status == TournamentStatus.Completed, "Single " + participantCount + " should complete.");
                Assert(manager.CurrentTournament.resultHistory.Count > 0, "Single should save result history.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(manager.gameObject);
            }
        }

        private static void RunSwiss(int participantCount)
        {
            TournamentManager manager = CreateManager("Smoke_Swiss_" + participantCount);
            try
            {
                TournamentSettings settings = TournamentSettings.CreateDefault();
                settings.tournamentName = "Smoke Swiss " + participantCount;
                settings.formatType = TournamentFormatType.Swiss;
                settings.bestOf = 1;
                settings.swissRoundCount = 4;
                settings.enableAutosave = false;
                manager.CreateNewTournament(settings);
                manager.GenerateTestParticipants(participantCount);
                Assert(manager.StartTournament(), "Swiss should start for " + participantCount);
                SimulateUntilComplete(manager, 20);

                TournamentPhase phase = manager.CurrentTournament.phases[0];
                Assert(phase.rounds.Count == 4, "Swiss should create 4 rounds.");
                Assert(manager.CurrentTournament.status == TournamentStatus.Completed, "Swiss should complete.");
                if (participantCount == 11)
                {
                    Assert(TournamentLookup.AllMatches(manager.CurrentTournament).Any(match => match.isBye), "Swiss 11 should contain BYE matches.");
                }

                AssertNoRepeatedPair(manager.CurrentTournament);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(manager.gameObject);
            }
        }

        private static void RunSwissToBracket()
        {
            TournamentManager manager = CreateManager("Smoke_SwissToBracket");
            try
            {
                TournamentSettings settings = TournamentSettings.CreateDefault();
                settings.tournamentName = "Smoke Swiss To Bracket";
                settings.formatType = TournamentFormatType.SwissToBracket;
                settings.bestOf = 1;
                settings.swissRoundCount = 4;
                settings.advanceTopXToBracket = 4;
                settings.enableAutosave = false;
                manager.CreateNewTournament(settings);
                manager.GenerateTestParticipants(12);
                Assert(manager.StartTournament(), "SwissToBracket should start.");
                SimulateUntilComplete(manager, 30);

                Assert(manager.CurrentTournament.phases.Any(phase => phase.formatType == TournamentFormatType.SingleElimination), "SwissToBracket should create a playoff bracket.");
                Assert(manager.CurrentTournament.status == TournamentStatus.Completed, "SwissToBracket should complete.");
                Assert(manager.CurrentTournament.resultHistory.Count > 0, "SwissToBracket should save results.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(manager.gameObject);
            }
        }

        private static TournamentManager CreateManager(string name)
        {
            GameObject gameObject = new GameObject(name);
            return gameObject.AddComponent<TournamentManager>();
        }

        private static void SimulateUntilComplete(TournamentManager manager, int guard)
        {
            while (manager.CurrentTournament.status != TournamentStatus.Completed && guard-- > 0)
            {
                manager.RandomlyCompleteCurrentRound();
                if (manager.CanGenerateNextRound())
                {
                    manager.GenerateNextRound();
                }
            }
        }

        private static void AssertNoRepeatedPair(Tournament tournament)
        {
            HashSet<string> seen = new HashSet<string>();
            foreach (Match match in TournamentLookup.AllMatches(tournament))
            {
                if (match.isBye || string.IsNullOrEmpty(match.participantAId) || string.IsNullOrEmpty(match.participantBId))
                {
                    continue;
                }

                string a = string.CompareOrdinal(match.participantAId, match.participantBId) < 0 ? match.participantAId : match.participantBId;
                string b = a == match.participantAId ? match.participantBId : match.participantAId;
                string key = a + "|" + b;
                Assert(!seen.Contains(key), "Swiss repeated a pair: " + key);
                seen.Add(key);
            }
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
            {
                throw new Exception(message);
            }
        }
    }
}
