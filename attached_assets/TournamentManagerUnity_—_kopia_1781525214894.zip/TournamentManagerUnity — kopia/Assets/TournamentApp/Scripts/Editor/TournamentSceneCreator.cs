using TournamentApp.Services;
using TournamentApp.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TournamentApp.Editor
{
    public static class TournamentSceneCreator
    {
        private const string ScenePath = "Assets/TournamentApp/Scenes/TournamentApp.unity";

        [MenuItem("Tools/Tournament App/Create Basic Tournament Scene")]
        public static void CreateBasicTournamentScene()
        {
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "TournamentApp";

            GameObject cameraObject = new GameObject("Main Camera", typeof(Camera));
            Camera camera = cameraObject.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.06f, 0.08f, 0.12f, 1f);
            camera.orthographic = true;
            cameraObject.tag = "MainCamera";

            GameObject canvasObject = new GameObject("TournamentAppCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            Canvas canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            scaler.matchWidthOrHeight = 0.5f;

            GameObject eventSystem = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            eventSystem.GetComponent<EventSystem>().firstSelectedGameObject = null;

            GameObject appObject = new GameObject("TournamentApp", typeof(TournamentManager), typeof(TournamentAppUI));
            Selection.activeGameObject = appObject;

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(ScenePath, true)
            };

            AssetDatabase.Refresh();
            Debug.Log("Tournament App scene created at " + ScenePath);
        }
    }
}
