using System.Collections.Generic;

namespace TournamentApp.Core
{
    public static class TournamentLookup
    {
        public static Participant Participant(Tournament tournament, string participantId)
        {
            if (tournament == null || string.IsNullOrEmpty(participantId)) return null;
            return tournament.participants.Find(participant => participant.id == participantId);
        }

        public static TournamentPhase CurrentPhase(Tournament tournament)
        {
            if (tournament == null || tournament.phases == null) return null;
            if (!string.IsNullOrEmpty(tournament.currentPhaseId))
            {
                TournamentPhase selected = tournament.phases.Find(phase => phase.id == tournament.currentPhaseId);
                if (selected != null) return selected;
            }

            if (tournament.phases.Count == 0) return null;
            return tournament.phases[tournament.phases.Count - 1];
        }

        public static TournamentPhase Phase(Tournament tournament, string phaseId)
        {
            if (tournament == null || tournament.phases == null) return null;
            return tournament.phases.Find(phase => phase.id == phaseId);
        }

        public static Round Round(TournamentPhase phase, int roundIndex)
        {
            if (phase == null || phase.rounds == null) return null;
            return phase.rounds.Find(round => round.roundIndex == roundIndex);
        }

        public static Match Match(Tournament tournament, string matchId)
        {
            if (tournament == null || string.IsNullOrEmpty(matchId)) return null;
            foreach (TournamentPhase phase in tournament.phases)
            {
                Match found = Match(phase, matchId);
                if (found != null) return found;
            }
            return null;
        }

        public static Match Match(TournamentPhase phase, string matchId)
        {
            if (phase == null || string.IsNullOrEmpty(matchId)) return null;
            foreach (Round round in phase.rounds)
            {
                Match found = round.matches.Find(match => match.id == matchId);
                if (found != null) return found;
            }
            return null;
        }

        public static List<Match> AllMatches(Tournament tournament)
        {
            List<Match> matches = new List<Match>();
            if (tournament == null || tournament.phases == null) return matches;
            foreach (TournamentPhase phase in tournament.phases)
            {
                foreach (Round round in phase.rounds)
                {
                    matches.AddRange(round.matches);
                }
            }
            return matches;
        }

        public static string ParticipantName(Tournament tournament, string participantId)
        {
            Participant participant = Participant(tournament, participantId);
            return participant == null ? "TBD" : participant.displayName;
        }
    }
}
