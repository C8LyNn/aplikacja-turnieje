using System;

namespace TournamentApp.Core
{
    public static class TournamentIds
    {
        public static string NewId(string prefix)
        {
            return prefix + "_" + Guid.NewGuid().ToString("N");
        }
    }

    public static class TournamentTime
    {
        public static string Now()
        {
            return DateTime.UtcNow.ToString("o");
        }
    }
}
