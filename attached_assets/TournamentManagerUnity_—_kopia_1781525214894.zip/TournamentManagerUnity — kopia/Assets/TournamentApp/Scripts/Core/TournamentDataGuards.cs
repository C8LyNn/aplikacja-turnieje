using System.Collections.Generic;

namespace TournamentApp.Core
{
    public static class TournamentDataGuards
    {
        public static void EnsureCollections(Tournament tournament)
        {
            if (tournament == null)
            {
                return;
            }

            if (tournament.settings == null) tournament.settings = TournamentSettings.CreateDefault();
            if (tournament.visualSettings == null) tournament.visualSettings = TournamentVisualSettings.CreateDefault();
            if (tournament.participants == null) tournament.participants = new List<Participant>();
            if (tournament.teams == null) tournament.teams = new List<Team>();
            if (tournament.phases == null) tournament.phases = new List<TournamentPhase>();
            if (tournament.auditLog == null) tournament.auditLog = new List<AuditLogEntry>();
            if (tournament.resultHistory == null) tournament.resultHistory = new List<ResultRecord>();
            if (tournament.broadcastState == null) tournament.broadcastState = new BroadcastState();
            if (tournament.broadcastState.nextMatchIds == null) tournament.broadcastState.nextMatchIds = new List<string>();
            if (tournament.broadcastState.previousMatchIds == null) tournament.broadcastState.previousMatchIds = new List<string>();
            if (tournament.broadcastState.standingsSnapshot == null) tournament.broadcastState.standingsSnapshot = new List<Standing>();
            if (tournament.broadcastState.bracketSnapshot == null) tournament.broadcastState.bracketSnapshot = new List<BracketSnapshotMatch>();

            foreach (Participant participant in tournament.participants)
            {
                if (participant.customFields == null) participant.customFields = new List<CustomFieldEntry>();
                if (participant.opponentsPlayed == null) participant.opponentsPlayed = new List<string>();
            }

            foreach (Team team in tournament.teams)
            {
                if (team.memberParticipantIds == null) team.memberParticipantIds = new List<string>();
                if (team.customFields == null) team.customFields = new List<CustomFieldEntry>();
            }

            foreach (TournamentPhase phase in tournament.phases)
            {
                if (phase.rounds == null) phase.rounds = new List<Round>();
                if (phase.standingsSnapshot == null) phase.standingsSnapshot = new List<Standing>();
                foreach (Round round in phase.rounds)
                {
                    if (round.matches == null) round.matches = new List<Match>();
                    foreach (Match match in round.matches)
                    {
                        if (match.games == null) match.games = new List<MatchGame>();
                    }
                }
            }

            foreach (ResultRecord record in tournament.resultHistory)
            {
                if (record.games == null) record.games = new List<MatchGame>();
            }
        }
    }
}
