using System;
using System.Collections.Generic;

namespace TournamentApp.Core
{
    [Serializable]
    public class Tournament
    {
        public string id;
        public string tournamentName;
        public string createdAt;
        public string updatedAt;
        public TournamentSettings settings = TournamentSettings.CreateDefault();
        public TournamentVisualSettings visualSettings = TournamentVisualSettings.CreateDefault();
        public List<Participant> participants = new List<Participant>();
        public List<Team> teams = new List<Team>();
        public List<TournamentPhase> phases = new List<TournamentPhase>();
        public string currentPhaseId;
        public int currentRoundIndex;
        public string currentMatchId;
        public string featuredMatchId;
        public TournamentStatus status;
        public List<AuditLogEntry> auditLog = new List<AuditLogEntry>();
        public List<ResultRecord> resultHistory = new List<ResultRecord>();
        public BroadcastState broadcastState = new BroadcastState();
        public int randomSeed;
        public bool useFixedRandomSeed;

        public static Tournament CreateNew(TournamentSettings settings, TournamentVisualSettings visualSettings = null)
        {
            string now = TournamentTime.Now();
            Tournament tournament = new Tournament();
            tournament.id = TournamentIds.NewId("tournament");
            tournament.tournamentName = settings.tournamentName;
            tournament.createdAt = now;
            tournament.updatedAt = now;
            tournament.settings = settings;
            tournament.visualSettings = visualSettings ?? TournamentVisualSettings.CreateDefault();
            tournament.visualSettings.tournamentTitle = settings.tournamentName;
            tournament.status = TournamentStatus.Setup;
            tournament.randomSeed = Environment.TickCount;
            tournament.useFixedRandomSeed = false;
            tournament.broadcastState = new BroadcastState();
            return tournament;
        }
    }

    [Serializable]
    public class TournamentSettings
    {
        public string tournamentName;
        public TournamentFormatType formatType;
        public PlayerMode playerMode;
        public int participantCount;
        public int teamCount;
        public int membersPerTeam;
        public int bestOf;
        public int earlyRoundBestOf;
        public int quarterFinalBestOf;
        public int semiFinalBestOf;
        public int finalBestOf;
        public bool allowDraws;
        public int pointsForWin;
        public int pointsForDraw;
        public int pointsForLoss;
        public int swissRoundCount;
        public int advanceTopXToBracket;
        public bool useRandomSeeding;
        public bool allowManualPairingCorrection;
        public bool allowByes;
        public bool allowWalkovers;
        public bool allowResultEditing;
        public bool enableAutosave;
        public int autosaveIntervalSeconds;

        public static TournamentSettings CreateDefault()
        {
            return new TournamentSettings
            {
                tournamentName = "New Tournament",
                formatType = TournamentFormatType.SingleElimination,
                playerMode = PlayerMode.Solo,
                participantCount = 8,
                teamCount = 0,
                membersPerTeam = 1,
                bestOf = 1,
                earlyRoundBestOf = 1,
                quarterFinalBestOf = 1,
                semiFinalBestOf = 1,
                finalBestOf = 1,
                allowDraws = false,
                pointsForWin = 3,
                pointsForDraw = 1,
                pointsForLoss = 0,
                swissRoundCount = 4,
                advanceTopXToBracket = 8,
                useRandomSeeding = false,
                allowManualPairingCorrection = true,
                allowByes = true,
                allowWalkovers = true,
                allowResultEditing = true,
                enableAutosave = true,
                autosaveIntervalSeconds = 30
            };
        }
    }

    [Serializable]
    public class Participant
    {
        public string id;
        public string displayName;
        public string nickname;
        public string realName;
        public int seed;
        public string teamId;
        public string rankName;
        public int rankValue;
        public string skillTier;
        public string country;
        public string avatarPath;
        public string mainCharacter;
        public string role;
        public string notes;
        public List<CustomFieldEntry> customFields = new List<CustomFieldEntry>();
        public int wins;
        public int draws;
        public int losses;
        public int points;
        public int smallPointsFor;
        public int smallPointsAgainst;
        public List<string> opponentsPlayed = new List<string>();
        public bool hasReceivedBye;
        public bool isDropped;
        public bool isDisqualified;

        public static Participant Create(string nickname, int seed)
        {
            return new Participant
            {
                id = TournamentIds.NewId("participant"),
                displayName = nickname,
                nickname = nickname,
                seed = seed,
                rankName = string.Empty,
                country = string.Empty,
                teamId = string.Empty
            };
        }
    }

    [Serializable]
    public class CustomFieldEntry
    {
        public string key;
        public string value;
    }

    [Serializable]
    public class Team
    {
        public string id;
        public string name;
        public string shortName;
        public string logoPath;
        public List<string> memberParticipantIds = new List<string>();
        public int seed;
        public string rankName;
        public int rankValue;
        public string notes;
        public List<CustomFieldEntry> customFields = new List<CustomFieldEntry>();
        public int wins;
        public int draws;
        public int losses;
        public int points;
    }

    [Serializable]
    public class TournamentPhase
    {
        public string id;
        public string name;
        public TournamentFormatType formatType;
        public int phaseIndex;
        public List<Round> rounds = new List<Round>();
        public List<Standing> standingsSnapshot = new List<Standing>();
        public PhaseStatus status;
    }

    [Serializable]
    public class Round
    {
        public int roundIndex;
        public string name;
        public List<Match> matches = new List<Match>();
        public bool isCompleted;
        public string startedAt;
        public string completedAt;
    }

    [Serializable]
    public class Match
    {
        public string id;
        public string phaseId;
        public int roundIndex;
        public int matchIndex;
        public string displayName;
        public string participantAId;
        public string participantBId;
        public int scoreA;
        public int scoreB;
        public string winnerId;
        public string loserId;
        public MatchStatus status;
        public int bestOf;
        public int currentGameNumber;
        public List<MatchGame> games = new List<MatchGame>();
        public string bracketNextMatchId;
        public MatchSlot bracketNextSlot;
        public bool isBye;
        public bool isFeatured;
        public bool isStreamed;
        public int scheduledOrder;
        public string note;

        public bool HasBothParticipants()
        {
            return !string.IsNullOrEmpty(participantAId) && !string.IsNullOrEmpty(participantBId);
        }

        public bool IsFinished()
        {
            return status == MatchStatus.Completed ||
                   status == MatchStatus.Bye ||
                   status == MatchStatus.Walkover ||
                   status == MatchStatus.Disqualified;
        }
    }

    [Serializable]
    public class MatchGame
    {
        public int gameIndex;
        public int scoreA;
        public int scoreB;
        public string winnerId;
        public string mapName;
        public MatchStatus status;
    }

    [Serializable]
    public class Standing
    {
        public string participantId;
        public int rank;
        public int points;
        public int wins;
        public int draws;
        public int losses;
        public int buchholz;
        public int smallPointsFor;
        public int smallPointsAgainst;
        public int smallPointDiff;
        public List<string> opponentsPlayed = new List<string>();
    }

    [Serializable]
    public class TournamentVisualSettings
    {
        public string tournamentTitle;
        public string logoPath;
        public string primaryColor;
        public string secondaryColor;
        public string backgroundColor;
        public string panelColor;
        public string matchCardColor;
        public string winnerColor;
        public string loserColor;
        public string activeMatchColor;
        public int fontSizeSmall;
        public int fontSizeNormal;
        public int fontSizeLarge;
        public bool showAvatars;
        public bool showRanks;
        public bool showSeeds;
        public bool showTeams;
        public bool showCustomFields;
        public List<string> selectedCustomFieldKeys = new List<string>();
        public string themeName;
        public LayoutMode layoutMode;

        public static TournamentVisualSettings CreateDefault()
        {
            return new TournamentVisualSettings
            {
                tournamentTitle = "Tournament",
                logoPath = string.Empty,
                primaryColor = "#2F80ED",
                secondaryColor = "#27AE60",
                backgroundColor = "#10141F",
                panelColor = "#182033",
                matchCardColor = "#222C44",
                winnerColor = "#38D979",
                loserColor = "#8892A6",
                activeMatchColor = "#F2C94C",
                fontSizeSmall = 14,
                fontSizeNormal = 18,
                fontSizeLarge = 32,
                showAvatars = false,
                showRanks = true,
                showSeeds = true,
                showTeams = true,
                showCustomFields = false,
                themeName = "Dark",
                layoutMode = LayoutMode.Normal
            };
        }
    }

    [Serializable]
    public class ResultRecord
    {
        public string id;
        public string tournamentId;
        public string phaseId;
        public int roundIndex;
        public string matchId;
        public string participantAId;
        public string participantBId;
        public int scoreA;
        public int scoreB;
        public string winnerId;
        public string loserId;
        public MatchStatus matchStatus;
        public int bestOf;
        public List<MatchGame> games = new List<MatchGame>();
        public string createdAt;
        public string updatedAt;
        public bool wasEdited;
        public int editCount;
        public string note;
    }

    [Serializable]
    public class AuditLogEntry
    {
        public string id;
        public string timestamp;
        public AuditActionType actionType;
        public string description;
        public string relatedMatchId;
        public string relatedParticipantId;
        public string oldValue;
        public string newValue;
    }

    [Serializable]
    public class BroadcastState
    {
        public AppViewMode currentView;
        public string currentMatchId;
        public string featuredMatchId;
        public List<string> nextMatchIds = new List<string>();
        public List<string> previousMatchIds = new List<string>();
        public List<Standing> standingsSnapshot = new List<Standing>();
        public List<BracketSnapshotMatch> bracketSnapshot = new List<BracketSnapshotMatch>();
    }

    [Serializable]
    public class BracketSnapshotMatch
    {
        public string matchId;
        public string phaseName;
        public int roundIndex;
        public int matchIndex;
        public string participantAId;
        public string participantBId;
        public int scoreA;
        public int scoreB;
        public string winnerId;
        public MatchStatus status;
    }

    [Serializable]
    public class TournamentTemplate
    {
        public string id;
        public string name;
        public TournamentSettings settings = TournamentSettings.CreateDefault();
        public TournamentVisualSettings visualSettings = TournamentVisualSettings.CreateDefault();
    }

    [Serializable]
    public class PlayerPot
    {
        public string id;
        public string name;
        public List<string> participants = new List<string>();
        public int priority;
        public string color;
    }

    [Serializable]
    public class ValidationMessage
    {
        public string code;
        public string message;
        public bool isBlocking;
    }
}
