namespace TournamentApp.Core
{
    public enum TournamentFormatType
    {
        SingleElimination,
        Swiss,
        SwissToBracket,
        RoundRobin,
        GroupsToBracket,
        DoubleElimination
    }

    public enum PlayerMode
    {
        Solo,
        Team
    }

    public enum TournamentStatus
    {
        Setup,
        Running,
        Completed,
        Cancelled
    }

    public enum PhaseStatus
    {
        Pending,
        Running,
        Completed
    }

    public enum MatchStatus
    {
        Pending,
        Ready,
        Live,
        Completed,
        Bye,
        Walkover,
        Delayed,
        Cancelled,
        Disqualified,
        ResultDisputed
    }

    public enum MatchSlot
    {
        A,
        B
    }

    public enum LayoutMode
    {
        Compact,
        Normal,
        Broadcast
    }

    public enum AuditActionType
    {
        ParticipantAdded,
        ParticipantRemoved,
        ParticipantEdited,
        SeedChanged,
        RoundGenerated,
        MatchResultEntered,
        MatchResultEdited,
        MatchResultReverted,
        WalkoverAssigned,
        ByeAssigned,
        CurrentMatchChanged,
        MatchOrderChanged,
        TournamentSaved,
        TournamentLoaded,
        BackupCreated,
        ExportCreated
    }

    public enum AppViewMode
    {
        Admin,
        Broadcast,
        Bracket,
        Standings,
        CurrentMatch,
        Schedule,
        ResultsHistory,
        Randomizer,
        Customization
    }
}
