using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class PairingService
    {
        public List<string> LastWarnings { get; private set; } = new List<string>();

        public Round CreateSwissRound(Tournament tournament, TournamentPhase phase, int roundIndex, List<Standing> standings)
        {
            LastWarnings.Clear();
            List<Participant> activeParticipants = tournament.participants
                .Where(participant => !participant.isDropped && !participant.isDisqualified)
                .ToList();

            List<Participant> ordered = OrderForSwissPairing(tournament, activeParticipants, roundIndex, standings);
            Round round = new Round
            {
                roundIndex = roundIndex,
                name = "Swiss Round " + (roundIndex + 1),
                startedAt = TournamentTime.Now()
            };

            Participant byeParticipant = null;
            if (ordered.Count % 2 == 1)
            {
                byeParticipant = PickByeParticipant(ordered, standings);
                ordered.Remove(byeParticipant);
                Match byeMatch = CreateMatch(phase, roundIndex, round.matches.Count, byeParticipant.id, string.Empty, tournament.settings.bestOf);
                byeMatch.displayName = round.name + " - BYE";
                byeMatch.status = MatchStatus.Bye;
                byeMatch.isBye = true;
                byeMatch.scoreA = 1;
                byeMatch.scoreB = 0;
                byeMatch.winnerId = byeParticipant.id;
                round.matches.Add(byeMatch);
            }

            int scheduledOrder = round.matches.Count;
            List<ParticipantPair> pairings = BuildPairings(ordered);
            foreach (ParticipantPair pairing in pairings)
            {
                Participant a = pairing.a;
                Participant b = pairing.b;
                if (a.opponentsPlayed.Contains(b.id))
                {
                    LastWarnings.Add("Swiss could not avoid repeated pairing: " + a.displayName + " vs " + b.displayName);
                }

                Match match = CreateMatch(phase, roundIndex, round.matches.Count, a.id, b.id, tournament.settings.bestOf);
                match.scheduledOrder = scheduledOrder++;
                round.matches.Add(match);
            }

            return round;
        }

        public void ShuffleSeeds(Tournament tournament, bool keepExistingSeeds)
        {
            System.Random rng = CreateRng(tournament);
            List<Participant> participants = tournament.participants.ToList();
            if (keepExistingSeeds)
            {
                participants = participants.Where(participant => participant.seed <= 0).ToList();
            }

            participants = participants.OrderBy(_ => rng.Next()).ToList();
            int nextSeed = keepExistingSeeds
                ? tournament.participants.Where(participant => participant.seed > 0).Select(participant => participant.seed).DefaultIfEmpty(0).Max() + 1
                : 1;

            foreach (Participant participant in participants)
            {
                participant.seed = nextSeed++;
            }
        }

        public System.Random CreateRng(Tournament tournament)
        {
            if (tournament != null && tournament.useFixedRandomSeed)
            {
                return new System.Random(tournament.randomSeed);
            }

            return new System.Random(Environment.TickCount);
        }

        private List<Participant> OrderForSwissPairing(Tournament tournament, List<Participant> participants, int roundIndex, List<Standing> standings)
        {
            if (roundIndex == 0)
            {
                if (tournament.settings.useRandomSeeding)
                {
                    System.Random rng = CreateRng(tournament);
                    return participants.OrderBy(_ => rng.Next()).ToList();
                }

                return participants.OrderBy(participant => participant.seed <= 0 ? int.MaxValue : participant.seed)
                    .ThenBy(participant => participant.displayName)
                    .ToList();
            }

            Dictionary<string, int> standingRank = standings.ToDictionary(standing => standing.participantId, standing => standing.rank);
            return participants
                .OrderBy(participant => standingRank.ContainsKey(participant.id) ? standingRank[participant.id] : int.MaxValue)
                .ThenBy(participant => participant.seed <= 0 ? int.MaxValue : participant.seed)
                .ToList();
        }

        private Participant PickByeParticipant(List<Participant> ordered, List<Standing> standings)
        {
            Dictionary<string, Standing> byParticipant = standings == null
                ? new Dictionary<string, Standing>()
                : standings.ToDictionary(standing => standing.participantId, standing => standing);

            Participant candidate = ordered
                .Where(participant => !participant.hasReceivedBye)
                .OrderBy(participant => byParticipant.ContainsKey(participant.id) ? byParticipant[participant.id].points : 0)
                .ThenByDescending(participant => participant.seed <= 0 ? int.MaxValue : participant.seed)
                .FirstOrDefault();

            return candidate ?? ordered.Last();
        }

        private List<ParticipantPair> BuildPairings(List<Participant> ordered)
        {
            List<ParticipantPair> pairings = new List<ParticipantPair>();
            if (TryBuildPairings(ordered, true, pairings))
            {
                return pairings;
            }

            pairings.Clear();
            TryBuildPairings(ordered, false, pairings);
            return pairings;
        }

        private bool TryBuildPairings(List<Participant> remaining, bool avoidRepeats, List<ParticipantPair> pairings)
        {
            if (remaining.Count == 0) return true;
            if (remaining.Count == 1) return false;

            Participant a = remaining[0];
            List<Participant> rest = remaining.Skip(1).ToList();
            List<Participant> candidates = rest
                .OrderBy(candidate => a.opponentsPlayed.Contains(candidate.id) ? 1 : 0)
                .ThenBy(candidate => Math.Abs(a.points - candidate.points))
                .ThenBy(candidate => candidate.seed <= 0 ? int.MaxValue : candidate.seed)
                .ToList();

            foreach (Participant b in candidates)
            {
                if (avoidRepeats && a.opponentsPlayed.Contains(b.id))
                {
                    continue;
                }

                List<Participant> nextRemaining = rest.Where(candidate => candidate.id != b.id).ToList();
                pairings.Add(new ParticipantPair { a = a, b = b });
                if (TryBuildPairings(nextRemaining, avoidRepeats, pairings))
                {
                    return true;
                }

                pairings.RemoveAt(pairings.Count - 1);
            }

            return false;
        }

        private Match CreateMatch(TournamentPhase phase, int roundIndex, int matchIndex, string participantAId, string participantBId, int bestOf)
        {
            return new Match
            {
                id = TournamentIds.NewId("match"),
                phaseId = phase.id,
                roundIndex = roundIndex,
                matchIndex = matchIndex,
                displayName = "Match " + (matchIndex + 1),
                participantAId = participantAId,
                participantBId = participantBId,
                bestOf = bestOf,
                currentGameNumber = 1,
                status = string.IsNullOrEmpty(participantAId) || string.IsNullOrEmpty(participantBId)
                    ? MatchStatus.Pending
                    : MatchStatus.Ready,
                scheduledOrder = matchIndex
            };
        }

        private struct ParticipantPair
        {
            public Participant a;
            public Participant b;
        }
    }
}
