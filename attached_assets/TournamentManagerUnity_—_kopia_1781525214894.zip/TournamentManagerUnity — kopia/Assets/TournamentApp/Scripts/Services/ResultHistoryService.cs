using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class ResultHistoryService
    {
        public ResultRecord SaveResultRecord(Tournament tournament, Match match)
        {
            if (tournament == null || match == null) return null;

            string now = TournamentTime.Now();
            ResultRecord existing = tournament.resultHistory.Find(record => record.matchId == match.id);
            if (existing == null)
            {
                existing = new ResultRecord
                {
                    id = TournamentIds.NewId("result"),
                    tournamentId = tournament.id,
                    createdAt = now
                };
                tournament.resultHistory.Add(existing);
            }
            else
            {
                existing.wasEdited = true;
                existing.editCount += 1;
            }

            existing.phaseId = match.phaseId;
            existing.roundIndex = match.roundIndex;
            existing.matchId = match.id;
            existing.participantAId = match.participantAId;
            existing.participantBId = match.participantBId;
            existing.scoreA = match.scoreA;
            existing.scoreB = match.scoreB;
            existing.winnerId = match.winnerId;
            existing.loserId = match.loserId;
            existing.matchStatus = match.status;
            existing.bestOf = match.bestOf;
            existing.games = CloneGames(match.games);
            existing.updatedAt = now;
            existing.note = match.note;
            return existing;
        }

        public List<ResultRecord> GetResultsForTournament(Tournament tournament)
        {
            return tournament == null ? new List<ResultRecord>() : tournament.resultHistory.OrderByDescending(record => record.updatedAt).ToList();
        }

        public List<ResultRecord> GetResultsForRound(Tournament tournament, int roundIndex)
        {
            return GetResultsForTournament(tournament).Where(record => record.roundIndex == roundIndex).ToList();
        }

        public List<ResultRecord> GetResultsForParticipant(Tournament tournament, string participantId)
        {
            return GetResultsForTournament(tournament)
                .Where(record => record.participantAId == participantId || record.participantBId == participantId)
                .ToList();
        }

        public List<Match> GetCompletedMatches(Tournament tournament)
        {
            return TournamentLookup.AllMatches(tournament)
                .Where(match => match.IsFinished())
                .OrderByDescending(match => match.roundIndex)
                .ThenByDescending(match => match.matchIndex)
                .ToList();
        }

        public List<ResultRecord> GetPreviousMatches(Tournament tournament, int count)
        {
            return GetResultsForTournament(tournament).Take(count).ToList();
        }

        public List<ResultRecord> GetLatestResults(Tournament tournament, int count)
        {
            return GetPreviousMatches(tournament, count);
        }

        private List<MatchGame> CloneGames(List<MatchGame> games)
        {
            List<MatchGame> clone = new List<MatchGame>();
            if (games == null) return clone;

            foreach (MatchGame game in games)
            {
                clone.Add(new MatchGame
                {
                    gameIndex = game.gameIndex,
                    scoreA = game.scoreA,
                    scoreB = game.scoreB,
                    winnerId = game.winnerId,
                    mapName = game.mapName,
                    status = game.status
                });
            }

            return clone;
        }
    }
}
