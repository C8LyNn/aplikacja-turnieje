using System.Collections.Generic;
using System.IO;
using System.Text;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class ExportService
    {
        private readonly StandingsService standingsService = new StandingsService();

        public string ExportDirectory => Path.Combine(Application.persistentDataPath, "TournamentApp", "Exports");

        public string ExportResultsToJson(Tournament tournament)
        {
            Directory.CreateDirectory(ExportDirectory);
            string path = Path.Combine(ExportDirectory, SafeName(tournament.tournamentName) + "_Results.json");
            File.WriteAllText(path, JsonUtility.ToJson(tournament, true));
            return path;
        }

        public string ExportResultsToCsv(Tournament tournament)
        {
            Directory.CreateDirectory(ExportDirectory);
            string path = Path.Combine(ExportDirectory, SafeName(tournament.tournamentName) + "_Results.csv");
            StringBuilder csv = new StringBuilder();
            csv.AppendLine("faza,runda,numer meczu,gracz A,gracz B,wynik A,wynik B,zwyciezca,status,data wpisania,notatka");

            foreach (ResultRecord record in tournament.resultHistory)
            {
                TournamentPhase phase = TournamentLookup.Phase(tournament, record.phaseId);
                Match match = TournamentLookup.Match(tournament, record.matchId);
                csv.Append(Escape(phase == null ? string.Empty : phase.name)).Append(',');
                csv.Append(record.roundIndex + 1).Append(',');
                csv.Append(match == null ? 0 : match.matchIndex + 1).Append(',');
                csv.Append(Escape(TournamentLookup.ParticipantName(tournament, record.participantAId))).Append(',');
                csv.Append(Escape(TournamentLookup.ParticipantName(tournament, record.participantBId))).Append(',');
                csv.Append(record.scoreA).Append(',');
                csv.Append(record.scoreB).Append(',');
                csv.Append(Escape(TournamentLookup.ParticipantName(tournament, record.winnerId))).Append(',');
                csv.Append(record.matchStatus).Append(',');
                csv.Append(Escape(record.updatedAt)).Append(',');
                csv.Append(Escape(record.note)).AppendLine();
            }

            File.WriteAllText(path, csv.ToString(), Encoding.UTF8);
            return path;
        }

        public string ExportStandingsToCsv(Tournament tournament)
        {
            Directory.CreateDirectory(ExportDirectory);
            string path = Path.Combine(ExportDirectory, SafeName(tournament.tournamentName) + "_Standings.csv");
            List<Standing> standings = standingsService.GetStandings(tournament);
            StringBuilder csv = new StringBuilder();
            csv.AppendLine("rank,nick,points,wins,draws,losses,buchholz,small point diff,seed,rankName,team");
            foreach (Standing standing in standings)
            {
                Participant participant = TournamentLookup.Participant(tournament, standing.participantId);
                csv.Append(standing.rank).Append(',');
                csv.Append(Escape(participant == null ? string.Empty : participant.displayName)).Append(',');
                csv.Append(standing.points).Append(',');
                csv.Append(standing.wins).Append(',');
                csv.Append(standing.draws).Append(',');
                csv.Append(standing.losses).Append(',');
                csv.Append(standing.buchholz).Append(',');
                csv.Append(standing.smallPointDiff).Append(',');
                csv.Append(participant == null ? 0 : participant.seed).Append(',');
                csv.Append(Escape(participant == null ? string.Empty : participant.rankName)).Append(',');
                csv.Append(Escape(participant == null ? string.Empty : participant.teamId)).AppendLine();
            }

            File.WriteAllText(path, csv.ToString(), Encoding.UTF8);
            return path;
        }

        public string ExportScheduleToCsv(Tournament tournament)
        {
            Directory.CreateDirectory(ExportDirectory);
            string path = Path.Combine(ExportDirectory, SafeName(tournament.tournamentName) + "_Schedule.csv");
            StringBuilder csv = new StringBuilder();
            csv.AppendLine("faza,runda,numer meczu,gracz A,gracz B,status,stream,kolejnosc");
            foreach (TournamentPhase phase in tournament.phases)
            {
                foreach (Round round in phase.rounds)
                {
                    foreach (Match match in round.matches)
                    {
                        csv.Append(Escape(phase.name)).Append(',');
                        csv.Append(round.roundIndex + 1).Append(',');
                        csv.Append(match.matchIndex + 1).Append(',');
                        csv.Append(Escape(TournamentLookup.ParticipantName(tournament, match.participantAId))).Append(',');
                        csv.Append(Escape(TournamentLookup.ParticipantName(tournament, match.participantBId))).Append(',');
                        csv.Append(match.status).Append(',');
                        csv.Append(match.isStreamed ? "yes" : "no").Append(',');
                        csv.Append(match.scheduledOrder).AppendLine();
                    }
                }
            }

            File.WriteAllText(path, csv.ToString(), Encoding.UTF8);
            return path;
        }

        public string ExportTournamentToJson(Tournament tournament)
        {
            return ExportResultsToJson(tournament);
        }

        private string SafeName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Tournament";
            foreach (char invalid in Path.GetInvalidFileNameChars())
            {
                value = value.Replace(invalid, '_');
            }
            return value;
        }

        private string Escape(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            value = value.Replace("\"", "\"\"");
            if (value.Contains(",") || value.Contains("\"") || value.Contains("\n"))
            {
                return "\"" + value + "\"";
            }
            return value;
        }
    }
}
