using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class TournamentChecklistItem
    {
        public string label;
        public bool isOk;
        public bool isBlocking;

        public TournamentChecklistItem(string label, bool isOk, bool isBlocking)
        {
            this.label = label;
            this.isOk = isOk;
            this.isBlocking = isBlocking;
        }
    }

    public class TournamentAssistantSnapshot
    {
        public string stepTitle;
        public string nextAction;
        public List<string> warnings = new List<string>();
    }

    public class TournamentAssistantService
    {
        public TournamentAssistantSnapshot BuildSnapshot(Tournament tournament)
        {
            TournamentAssistantSnapshot snapshot = new TournamentAssistantSnapshot();
            if (tournament == null)
            {
                snapshot.stepTitle = "Krok 1/5: Utworz turniej";
                snapshot.nextAction = "Ustaw format i liczbe zawodnikow.";
                return snapshot;
            }

            if (tournament.status == TournamentStatus.Setup)
            {
                int target = TargetCount(tournament);
                int count = tournament.participants == null ? 0 : tournament.participants.Count;
                snapshot.stepTitle = count < target ? "Krok 1/5: Wczytaj zawodnikow" : "Krok 2/5: Sprawdz rozstawienie";
                snapshot.nextAction = count < target
                    ? "Dodaj zawodnikow recznie albo wczytaj CSV. Brakuje: " + (target - count) + "."
                    : "Otworz podsumowanie i sprawdz checklist przed startem.";
            }
            else if (HasUnfinishedMatches(tournament))
            {
                Match next = NextPlayableMatch(tournament);
                snapshot.stepTitle = "Krok 4/5: Wpisuj wyniki meczow";
                snapshot.nextAction = next == null
                    ? "Sprawdz drabinke i statusy meczow."
                    : "Nastepny mecz: " + TournamentUITextName(tournament, next.participantAId) + " vs " + TournamentUITextName(tournament, next.participantBId) + ".";
            }
            else
            {
                snapshot.stepTitle = "Krok 5/5: Wygeneruj nastepna runde";
                snapshot.nextAction = "Aktualna runda wyglada na zakonczona. Wygeneruj kolejna runde albo zakoncz turniej.";
            }

            snapshot.warnings = BuildWarnings(tournament);
            return snapshot;
        }

        public List<TournamentChecklistItem> BuildStartChecklist(Tournament tournament)
        {
            List<TournamentChecklistItem> items = new List<TournamentChecklistItem>();
            if (tournament == null)
            {
                items.Add(new TournamentChecklistItem("Turniej istnieje", false, true));
                return items;
            }

            int target = TargetCount(tournament);
            int count = tournament.participants == null ? 0 : tournament.participants.Count;
            items.Add(new TournamentChecklistItem("Nazwa turnieju ustawiona", !string.IsNullOrWhiteSpace(tournament.tournamentName), true));
            items.Add(new TournamentChecklistItem("Liczba zawodnikow: " + count + " / " + target, count == target, true));
            items.Add(new TournamentChecklistItem("Format: " + FormatName(tournament.settings.formatType), true, false));
            items.Add(new TournamentChecklistItem("Mecze: BO" + tournament.settings.bestOf, IsBestOfValid(tournament.settings.bestOf), true));
            items.Add(new TournamentChecklistItem("Brak pustych nickow", !HasEmptyNick(tournament), true));
            items.Add(new TournamentChecklistItem("Brak duplikatow nickow", !HasDuplicateNick(tournament), true));
            items.Add(new TournamentChecklistItem("Rozstawienie bez duplikatow", !HasDuplicateSeed(tournament), true));
            items.Add(new TournamentChecklistItem("Remisy: " + (tournament.settings.allowDraws ? "dozwolone" : "niedozwolone"), true, false));
            return items;
        }

        public bool HasBlockingChecklistErrors(Tournament tournament)
        {
            return BuildStartChecklist(tournament).Any(item => item.isBlocking && !item.isOk);
        }

        public List<string> BuildWarnings(Tournament tournament)
        {
            List<string> warnings = new List<string>();
            if (tournament == null) return warnings;

            int target = TargetCount(tournament);
            int count = tournament.participants == null ? 0 : tournament.participants.Count;
            if (tournament.status == TournamentStatus.Setup && count != target)
            {
                warnings.Add("Liczba zawodnikow nie zgadza sie z ustawieniem: " + count + " / " + target + ".");
            }

            if (HasEmptyNick(tournament)) warnings.Add("Sa zawodnicy bez nicku.");
            if (HasDuplicateNick(tournament)) warnings.Add("Nick zawodnika wystepuje wiecej niz raz.");
            if (HasDuplicateSeed(tournament)) warnings.Add("Seed wystepuje wiecej niz raz.");

            if (tournament.status == TournamentStatus.Running)
            {
                Round round = CurrentRound(tournament);
                if (round != null)
                {
                    int unfinished = round.matches.Count(match => !match.IsFinished() && match.status != MatchStatus.Bye && match.status != MatchStatus.Cancelled);
                    if (unfinished > 0)
                    {
                        warnings.Add("Aktualna runda ma niezakonczone mecze: " + unfinished + ".");
                    }
                }

                Match current = CurrentMatch(tournament);
                if (current != null && current.HasBothParticipants() && current.scoreA == current.scoreB && !tournament.settings.allowDraws && current.IsFinished())
                {
                    warnings.Add("Aktualny mecz ma remis, a remisy sa wylaczone.");
                }
            }

            return warnings;
        }

        private static int TargetCount(Tournament tournament)
        {
            return tournament == null || tournament.settings == null ? 0 : tournament.settings.participantCount;
        }

        private static bool IsBestOfValid(int value)
        {
            return value == 1 || value == 3 || value == 5 || value == 7 || value == 9;
        }

        private static bool HasEmptyNick(Tournament tournament)
        {
            return tournament.participants.Any(participant => string.IsNullOrWhiteSpace(participant.displayName));
        }

        private static bool HasDuplicateNick(Tournament tournament)
        {
            return tournament.participants
                .Where(participant => !string.IsNullOrWhiteSpace(participant.displayName))
                .GroupBy(participant => participant.displayName.Trim().ToLowerInvariant())
                .Any(group => group.Count() > 1);
        }

        private static bool HasDuplicateSeed(Tournament tournament)
        {
            return tournament.participants
                .Where(participant => participant.seed > 0)
                .GroupBy(participant => participant.seed)
                .Any(group => group.Count() > 1);
        }

        private static bool HasUnfinishedMatches(Tournament tournament)
        {
            return TournamentLookup.AllMatches(tournament).Any(match => !match.IsFinished() && match.status != MatchStatus.Bye && match.status != MatchStatus.Cancelled);
        }

        private static Match NextPlayableMatch(Tournament tournament)
        {
            return TournamentLookup.AllMatches(tournament)
                .Where(match => match.HasBothParticipants() && !match.IsFinished())
                .OrderBy(match => match.roundIndex)
                .ThenBy(match => match.scheduledOrder)
                .ThenBy(match => match.matchIndex)
                .FirstOrDefault();
        }

        private static Round CurrentRound(Tournament tournament)
        {
            TournamentPhase phase = TournamentLookup.CurrentPhase(tournament);
            return phase == null ? null : TournamentLookup.Round(phase, tournament.currentRoundIndex);
        }

        private static Match CurrentMatch(Tournament tournament)
        {
            return TournamentLookup.Match(tournament, tournament.currentMatchId);
        }

        private static string TournamentUITextName(Tournament tournament, string participantId)
        {
            string name = TournamentLookup.ParticipantName(tournament, participantId);
            return name == "TBD" ? "Do ustalenia" : name;
        }

        private static string FormatName(TournamentFormatType format)
        {
            switch (format)
            {
                case TournamentFormatType.SingleElimination:
                    return "Single Elimination";
                case TournamentFormatType.Swiss:
                    return "Swiss";
                case TournamentFormatType.SwissToBracket:
                    return "Swiss + Bracket";
                case TournamentFormatType.RoundRobin:
                    return "Round Robin";
                case TournamentFormatType.GroupsToBracket:
                    return "Groups + Bracket";
                case TournamentFormatType.DoubleElimination:
                    return "Double Elimination";
                default:
                    return format.ToString();
            }
        }
    }
}
