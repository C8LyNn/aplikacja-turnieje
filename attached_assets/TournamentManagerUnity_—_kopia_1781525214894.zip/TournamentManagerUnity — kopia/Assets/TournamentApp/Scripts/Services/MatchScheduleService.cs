using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class MatchScheduleService
    {
        public List<Match> GetLiveMatches(Tournament tournament)
        {
            return TournamentLookup.AllMatches(tournament)
                .Where(match => match.status == MatchStatus.Live)
                .OrderBy(match => match.scheduledOrder)
                .ToList();
        }

        public List<Match> GetNextMatches(Tournament tournament, int count)
        {
            return TournamentLookup.AllMatches(tournament)
                .Where(match => match.status == MatchStatus.Ready)
                .OrderBy(match => match.roundIndex)
                .ThenBy(match => match.scheduledOrder)
                .Take(count)
                .ToList();
        }

        public List<Match> GetPreviousMatches(Tournament tournament, int count)
        {
            return TournamentLookup.AllMatches(tournament)
                .Where(match => match.IsFinished())
                .OrderByDescending(match => match.roundIndex)
                .ThenByDescending(match => match.scheduledOrder)
                .Take(count)
                .ToList();
        }

        public void SetLiveMatch(Tournament tournament, string matchId)
        {
            Match selected = TournamentLookup.Match(tournament, matchId);
            if (selected == null) return;

            foreach (Match match in TournamentLookup.AllMatches(tournament))
            {
                if (match.status == MatchStatus.Live)
                {
                    match.status = MatchStatus.Ready;
                }
            }

            selected.status = MatchStatus.Live;
            tournament.currentMatchId = selected.id;
        }

        public void SetFeaturedMatch(Tournament tournament, string matchId)
        {
            foreach (Match match in TournamentLookup.AllMatches(tournament))
            {
                match.isFeatured = match.id == matchId;
            }

            tournament.featuredMatchId = matchId;
        }

        public void MoveMatch(Tournament tournament, string matchId, int delta)
        {
            Match selected = TournamentLookup.Match(tournament, matchId);
            if (selected == null) return;

            TournamentPhase phase = TournamentLookup.Phase(tournament, selected.phaseId);
            Round round = TournamentLookup.Round(phase, selected.roundIndex);
            if (round == null) return;

            List<Match> ordered = round.matches.OrderBy(match => match.scheduledOrder).ToList();
            int index = ordered.IndexOf(selected);
            int newIndex = index + delta;
            if (newIndex < 0 || newIndex >= ordered.Count) return;

            ordered.RemoveAt(index);
            ordered.Insert(newIndex, selected);
            for (int i = 0; i < ordered.Count; i++)
            {
                ordered[i].scheduledOrder = i;
            }
        }
    }
}
