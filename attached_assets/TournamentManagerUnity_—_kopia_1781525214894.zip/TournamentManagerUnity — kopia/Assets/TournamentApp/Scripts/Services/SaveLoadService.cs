using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class SaveLoadService
    {
        public string SaveDirectory => Path.Combine(Application.persistentDataPath, "TournamentApp", "Saves");
        public string LastTournamentPath => Path.Combine(SaveDirectory, "LastTournament.json");

        public string SaveTournament(Tournament tournament, string path = null)
        {
            if (tournament == null) return string.Empty;
            Directory.CreateDirectory(SaveDirectory);
            tournament.updatedAt = TournamentTime.Now();

            string finalPath = string.IsNullOrEmpty(path)
                ? Path.Combine(SaveDirectory, SanitizeFileName(tournament.tournamentName) + "_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + ".json")
                : path;

            File.WriteAllText(finalPath, JsonUtility.ToJson(tournament, true));
            return finalPath;
        }

        public string SaveLastTournament(Tournament tournament)
        {
            return SaveTournament(tournament, LastTournamentPath);
        }

        public Tournament LoadTournament(string path)
        {
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
            Tournament tournament = JsonUtility.FromJson<Tournament>(File.ReadAllText(path));
            TournamentDataGuards.EnsureCollections(tournament);
            return tournament;
        }

        public Tournament LoadLastTournament()
        {
            return LoadTournament(LastTournamentPath);
        }

        public List<string> GetSaveFiles()
        {
            Directory.CreateDirectory(SaveDirectory);
            return Directory.GetFiles(SaveDirectory, "*.json")
                .OrderByDescending(File.GetLastWriteTimeUtc)
                .ToList();
        }

        private string SanitizeFileName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Tournament";
            foreach (char invalid in Path.GetInvalidFileNameChars())
            {
                value = value.Replace(invalid, '_');
            }

            return value;
        }
    }
}
