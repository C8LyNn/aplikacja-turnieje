using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class StandingsService
    {
        public List<Standing> RecalculateTournament(Tournament tournament)
        {
            if (tournament == null) return new List<Standing>();
            ResetParticipantStats(tournament);

            foreach (Match match in TournamentLookup.AllMatches(tournament))
            {
                ApplyScoringMatch(tournament, match);
            }

            List<Standing> standings = BuildStandings(tournament);
            foreach (TournamentPhase phase in tournament.phases)
            {
                phase.standingsSnapshot = CloneStandings(standings);
                foreach (Round round in phase.rounds)
                {
                    bool completed = round.matches.Count > 0 && round.matches.All(match => match.IsFinished());
                    if (completed && !round.isCompleted)
                    {
                        round.completedAt = TournamentTime.Now();
                    }
                    round.isCompleted = completed;
                }
            }

            tournament.broadcastState.standingsSnapshot = CloneStandings(standings);
            return standings;
        }

        public List<Standing> GetStandings(Tournament tournament)
        {
            if (tournament == null) return new List<Standing>();
            return BuildStandings(tournament);
        }

        public List<Standing> CloneStandings(List<Standing> standings)
        {
            List<Standing> clone = new List<Standing>();
            if (standings == null) return clone;

            foreach (Standing standing in standings)
            {
                clone.Add(new Standing
                {
                    participantId = standing.participantId,
                    rank = standing.rank,
                    points = standing.points,
                    wins = standing.wins,
                    draws = standing.draws,
                    losses = standing.losses,
                    buchholz = standing.buchholz,
                    smallPointsFor = standing.smallPointsFor,
                    smallPointsAgainst = standing.smallPointsAgainst,
                    smallPointDiff = standing.smallPointDiff,
                    opponentsPlayed = new List<string>(standing.opponentsPlayed)
                });
            }

            return clone;
        }

        private void ResetParticipantStats(Tournament tournament)
        {
            foreach (Participant participant in tournament.participants)
            {
                participant.wins = 0;
                participant.draws = 0;
                participant.losses = 0;
                participant.points = 0;
                participant.smallPointsFor = 0;
                participant.smallPointsAgainst = 0;
                participant.hasReceivedBye = false;
                participant.opponentsPlayed.Clear();
            }
        }

        private void ApplyScoringMatch(Tournament tournament, Match match)
        {
            if (match == null || !match.IsFinished()) return;

            Participant a = TournamentLookup.Participant(tournament, match.participantAId);
            Participant b = TournamentLookup.Participant(tournament, match.participantBId);
            Participant winner = TournamentLookup.Participant(tournament, match.winnerId);
            Participant loser = TournamentLookup.Participant(tournament, match.loserId);

            if (match.status == MatchStatus.Bye || match.isBye)
            {
                if (winner != null)
                {
                    winner.hasReceivedBye = true;
                    winner.wins += 1;
                    winner.points += tournament.settings.pointsForWin;
                    winner.smallPointsFor += 1;
                }
                return;
            }

            if (a == null || b == null) return;

            a.smallPointsFor += match.scoreA;
            a.smallPointsAgainst += match.scoreB;
            b.smallPointsFor += match.scoreB;
            b.smallPointsAgainst += match.scoreA;
            AddOpponent(a, b.id);
            AddOpponent(b, a.id);

            if (!string.IsNullOrEmpty(match.winnerId) && winner != null)
            {
                winner.wins += 1;
                winner.points += tournament.settings.pointsForWin;
                if (loser != null)
                {
                    loser.losses += 1;
                    loser.points += tournament.settings.pointsForLoss;
                }
                return;
            }

            if (match.scoreA == match.scoreB && tournament.settings.allowDraws)
            {
                a.draws += 1;
                b.draws += 1;
                a.points += tournament.settings.pointsForDraw;
                b.points += tournament.settings.pointsForDraw;
            }
        }

        private void AddOpponent(Participant participant, string opponentId)
        {
            if (participant == null || string.IsNullOrEmpty(opponentId)) return;
            if (!participant.opponentsPlayed.Contains(opponentId))
            {
                participant.opponentsPlayed.Add(opponentId);
            }
        }

        private List<Standing> BuildStandings(Tournament tournament)
        {
            Dictionary<string, Participant> byId = tournament.participants.ToDictionary(participant => participant.id, participant => participant);
            List<Standing> standings = new List<Standing>();

            foreach (Participant participant in tournament.participants)
            {
                int buchholz = 0;
                foreach (string opponentId in participant.opponentsPlayed)
                {
                    Participant opponent;
                    if (byId.TryGetValue(opponentId, out opponent))
                    {
                        buchholz += opponent.points;
                    }
                }

                standings.Add(new Standing
                {
                    participantId = participant.id,
                    points = participant.points,
                    wins = participant.wins,
                    draws = participant.draws,
                    losses = participant.losses,
                    buchholz = buchholz,
                    smallPointsFor = participant.smallPointsFor,
                    smallPointsAgainst = participant.smallPointsAgainst,
                    smallPointDiff = participant.smallPointsFor - participant.smallPointsAgainst,
                    opponentsPlayed = new List<string>(participant.opponentsPlayed)
                });
            }

            standings = standings
                .OrderByDescending(standing => standing.points)
                .ThenByDescending(standing => standing.wins)
                .ThenByDescending(standing => standing.buchholz)
                .ThenByDescending(standing => standing.smallPointDiff)
                .ThenBy(standing =>
                {
                    Participant participant = byId[standing.participantId];
                    return participant.seed <= 0 ? int.MaxValue : participant.seed;
                })
                .ToList();

            for (int i = 0; i < standings.Count; i++)
            {
                standings[i].rank = i + 1;
            }

            return standings;
        }
    }
}
