using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class BackupService
    {
        public string BackupDirectory => Path.Combine(Application.persistentDataPath, "TournamentApp", "Backups");

        public string CreateBackup(Tournament tournament, string reason)
        {
            if (tournament == null) return string.Empty;
            Directory.CreateDirectory(BackupDirectory);

            string safeReason = string.IsNullOrWhiteSpace(reason) ? "backup" : reason.Replace(' ', '_');
            string path = Path.Combine(BackupDirectory, DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + "_" + safeReason + ".json");
            File.WriteAllText(path, JsonUtility.ToJson(tournament, true));
            return path;
        }

        public List<string> GetBackups()
        {
            Directory.CreateDirectory(BackupDirectory);
            return Directory.GetFiles(BackupDirectory, "*.json")
                .OrderByDescending(File.GetLastWriteTimeUtc)
                .ToList();
        }
    }
}
