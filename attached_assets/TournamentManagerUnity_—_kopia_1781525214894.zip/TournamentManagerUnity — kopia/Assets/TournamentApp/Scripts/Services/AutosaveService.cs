using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class AutosaveService
    {
        private float lastAutosaveTime;
        private readonly SaveLoadService saveLoadService;

        public AutosaveService(SaveLoadService saveLoadService)
        {
            this.saveLoadService = saveLoadService;
        }

        public void MarkSavedNow()
        {
            lastAutosaveTime = Time.unscaledTime;
        }

        public void AutosaveNow(Tournament tournament)
        {
            if (tournament == null || !tournament.settings.enableAutosave) return;
            saveLoadService.SaveLastTournament(tournament);
            MarkSavedNow();
        }

        public void Tick(Tournament tournament)
        {
            if (tournament == null || !tournament.settings.enableAutosave) return;
            int interval = tournament.settings.autosaveIntervalSeconds <= 0 ? 30 : tournament.settings.autosaveIntervalSeconds;
            if (Time.unscaledTime - lastAutosaveTime >= interval)
            {
                AutosaveNow(tournament);
            }
        }
    }
}
