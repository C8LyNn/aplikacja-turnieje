using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class ValidationService
    {
        public List<ValidationMessage> ValidateBeforeStart(Tournament tournament)
        {
            List<ValidationMessage> messages = new List<ValidationMessage>();
            if (tournament == null)
            {
                messages.Add(Block("missing_tournament", "Nie wczytano turnieju."));
                return messages;
            }

            if (tournament.participants.Count < 2)
            {
                messages.Add(Block("not_enough_players", "Dodaj co najmniej 2 uczestnikow."));
            }

            if (tournament.settings != null && tournament.participants.Count != tournament.settings.participantCount)
            {
                messages.Add(Block("participant_count_mismatch", "Liczba uczestnikow musi byc rowna ustawieniu: " + tournament.settings.participantCount + "."));
            }

            if (tournament.participants.Any(participant => string.IsNullOrWhiteSpace(participant.displayName)))
            {
                messages.Add(Block("empty_participant_name", "Sa zawodnicy bez nicku."));
            }

            if (tournament.participants
                .Where(participant => !string.IsNullOrWhiteSpace(participant.displayName))
                .GroupBy(participant => participant.displayName.Trim().ToLowerInvariant())
                .Any(group => group.Count() > 1))
            {
                messages.Add(Block("duplicate_participant_name", "Nick zawodnika wystepuje wiecej niz raz."));
            }

            if (tournament.participants
                .Where(participant => participant.seed > 0)
                .GroupBy(participant => participant.seed)
                .Any(group => group.Count() > 1))
            {
                messages.Add(Block("duplicate_seed", "Seed zawodnika wystepuje wiecej niz raz."));
            }

            if (tournament.settings.formatType == TournamentFormatType.SwissToBracket &&
                tournament.settings.advanceTopXToBracket > tournament.participants.Count)
            {
                messages.Add(Block("topx_too_large", "TOP X nie moze byc wieksze niz liczba uczestnikow."));
            }

            if (tournament.settings.bestOf <= 0 || tournament.settings.bestOf % 2 == 0)
            {
                messages.Add(Block("bad_best_of", "Best-of musi byc nieparzyste: BO1, BO3, BO5, BO7 albo BO9."));
            }

            if (!IsValidBestOf(tournament.settings.earlyRoundBestOf) ||
                !IsValidBestOf(tournament.settings.quarterFinalBestOf) ||
                !IsValidBestOf(tournament.settings.semiFinalBestOf) ||
                !IsValidBestOf(tournament.settings.finalBestOf))
            {
                messages.Add(Block("bad_stage_best_of", "Best-of etapow musi byc BO1, BO3, BO5, BO7 albo BO9."));
            }

            List<string> duplicatedTeamMembers = tournament.teams
                .SelectMany(team => team.memberParticipantIds)
                .GroupBy(id => id)
                .Where(group => group.Count() > 1)
                .Select(group => group.Key)
                .ToList();

            if (duplicatedTeamMembers.Count > 0)
            {
                messages.Add(Block("duplicate_team_member", "Co najmniej jeden gracz jest przypisany do wiecej niz jednej druzyny."));
            }

            return messages;
        }

        public List<ValidationMessage> ValidateResult(Tournament tournament, Match match, int scoreA, int scoreB)
        {
            List<ValidationMessage> messages = new List<ValidationMessage>();
            if (match == null)
            {
                messages.Add(Block("missing_match", "Nie znaleziono meczu."));
                return messages;
            }

            int needed = match.bestOf <= 1 ? 1 : (match.bestOf / 2) + 1;
            if (!tournament.settings.allowDraws && scoreA == scoreB)
            {
                messages.Add(Block("draw_not_allowed", "Remisy sa wylaczone w tym turnieju."));
            }

            if (scoreA < 0 || scoreB < 0 || scoreA > needed || scoreB > needed)
            {
                messages.Add(Block("score_out_of_range", "Wynik nie pasuje do formatu meczu."));
            }

            if (scoreA < needed && scoreB < needed && scoreA != scoreB)
            {
                messages.Add(Block("score_incomplete", "Jedna strona musi osiagnac wymagany wynik."));
            }

            if (match.IsFinished() && !tournament.settings.allowResultEditing)
            {
                messages.Add(Block("result_locked", "Ten wynik zostal juz wpisany, a edycja jest wylaczona."));
            }

            return messages;
        }

        public bool HasBlockingMessages(List<ValidationMessage> messages)
        {
            return messages.Any(message => message.isBlocking);
        }

        private ValidationMessage Block(string code, string message)
        {
            return new ValidationMessage { code = code, message = message, isBlocking = true };
        }

        private bool IsValidBestOf(int value)
        {
            return value == 0 || value == 1 || value == 3 || value == 5 || value == 7 || value == 9;
        }
    }
}
