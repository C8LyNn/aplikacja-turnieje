using System.Collections.Generic;
using System.IO;
using System.Linq;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class BroadcastStateService
    {
        private readonly MatchScheduleService scheduleService = new MatchScheduleService();
        private readonly StandingsService standingsService = new StandingsService();

        public string BroadcastStatePath => Path.Combine(Application.persistentDataPath, "TournamentApp", "BroadcastState.json");

        public void UpdateBroadcastState(Tournament tournament, AppViewMode viewMode)
        {
            if (tournament == null) return;
            tournament.broadcastState.currentView = viewMode;
            tournament.broadcastState.currentMatchId = tournament.currentMatchId;
            tournament.broadcastState.featuredMatchId = tournament.featuredMatchId;
            tournament.broadcastState.nextMatchIds = scheduleService.GetNextMatches(tournament, 5).Select(match => match.id).ToList();
            tournament.broadcastState.previousMatchIds = scheduleService.GetPreviousMatches(tournament, 5).Select(match => match.id).ToList();
            tournament.broadcastState.standingsSnapshot = standingsService.GetStandings(tournament);
            tournament.broadcastState.bracketSnapshot = BuildBracketSnapshot(tournament);
            SaveBroadcastState(tournament);
        }

        public void SaveBroadcastState(Tournament tournament)
        {
            if (tournament == null) return;
            Directory.CreateDirectory(Path.GetDirectoryName(BroadcastStatePath));
            File.WriteAllText(BroadcastStatePath, JsonUtility.ToJson(tournament.broadcastState, true));
        }

        private List<BracketSnapshotMatch> BuildBracketSnapshot(Tournament tournament)
        {
            List<BracketSnapshotMatch> snapshot = new List<BracketSnapshotMatch>();
            foreach (TournamentPhase phase in tournament.phases)
            {
                foreach (Round round in phase.rounds)
                {
                    foreach (Match match in round.matches)
                    {
                        snapshot.Add(new BracketSnapshotMatch
                        {
                            matchId = match.id,
                            phaseName = phase.name,
                            roundIndex = match.roundIndex,
                            matchIndex = match.matchIndex,
                            participantAId = match.participantAId,
                            participantBId = match.participantBId,
                            scoreA = match.scoreA,
                            scoreB = match.scoreB,
                            winnerId = match.winnerId,
                            status = match.status
                        });
                    }
                }
            }

            return snapshot;
        }
    }
}
