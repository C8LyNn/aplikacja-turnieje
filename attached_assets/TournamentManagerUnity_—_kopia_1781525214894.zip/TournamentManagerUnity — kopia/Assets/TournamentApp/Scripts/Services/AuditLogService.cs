using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class AuditLogService
    {
        public AuditLogEntry Add(
            Tournament tournament,
            AuditActionType actionType,
            string description,
            string relatedMatchId = "",
            string relatedParticipantId = "",
            string oldValue = "",
            string newValue = "")
        {
            if (tournament == null) return null;

            AuditLogEntry entry = new AuditLogEntry
            {
                id = TournamentIds.NewId("audit"),
                timestamp = TournamentTime.Now(),
                actionType = actionType,
                description = description,
                relatedMatchId = relatedMatchId,
                relatedParticipantId = relatedParticipantId,
                oldValue = oldValue,
                newValue = newValue
            };

            tournament.auditLog.Add(entry);
            tournament.updatedAt = entry.timestamp;
            return entry;
        }
    }
}
