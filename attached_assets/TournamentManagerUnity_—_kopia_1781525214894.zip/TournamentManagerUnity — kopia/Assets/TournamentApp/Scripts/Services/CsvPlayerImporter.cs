using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class CsvImportResult
    {
        public bool Success;
        public List<ImportedPlayer> Players = new List<ImportedPlayer>();
        public List<string> Errors = new List<string>();
        public int TotalLines;
        public int ImportedCount;
        public int SkippedCount;

        public string BuildSummary(int participantCount, int targetCount)
        {
            if (Success)
            {
                return "Import zakonczony.\n" +
                       "Wczytano zawodnikow: " + ImportedCount + "\n" +
                       "Pominieto blednych rekordow: " + SkippedCount + "\n" +
                       "Uczestnicy: " + participantCount + " / " + targetCount;
            }

            string text = "Import nieudany.\nSprawdz format pliku CSV.\nWymagany format:\nnick;ranga;seed;druzyna;kraj\n\nBledy importu:";
            foreach (string error in Errors.Take(12))
            {
                text += "\n- " + error;
            }

            if (Errors.Count > 12)
            {
                text += "\n- ... oraz " + (Errors.Count - 12) + " kolejnych bledow.";
            }

            text += "\n\nPlik powinien znajdowac sie tutaj:\nAssets/StreamingAssets/Players/players.csv";
            return text;
        }
    }

    public class ImportedPlayer
    {
        public string Nick;
        public string Rank;
        public int Seed;
        public string Team;
        public string Country;
    }

    public class CsvPlayerImporter
    {
        public const string RelativeProjectPath = "Assets/StreamingAssets/Players/players.csv";
        public const string RelativeStreamingPath = "Players/players.csv";
        public const string ExpectedHeader = "nick;ranga;seed;druzyna;kraj";

        public string GetDefaultFilePath()
        {
            return Path.Combine(Application.streamingAssetsPath, RelativeStreamingPath).Replace("\\", "/");
        }

        public CsvImportResult ImportFromDefaultFile(Tournament tournament, int targetParticipantCount)
        {
            return ImportFromFile(GetDefaultFilePath(), tournament, targetParticipantCount);
        }

        public CsvImportResult ImportFromFile(string path, Tournament tournament, int targetParticipantCount)
        {
            CsvImportResult result = new CsvImportResult();
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                result.Errors.Add("Nie znaleziono pliku CSV. Wrzuc plik tutaj: " + RelativeProjectPath);
                result.SkippedCount = 1;
                return result;
            }

            string csv;
            try
            {
                csv = File.ReadAllText(path, new UTF8Encoding(false, true));
            }
            catch (System.Exception exception)
            {
                result.Errors.Add("Nie udalo sie odczytac pliku: " + exception.Message);
                result.SkippedCount = 1;
                return result;
            }

            return ImportFromText(csv, tournament, targetParticipantCount);
        }

        public CsvImportResult ImportFromText(string csv, Tournament tournament, int targetParticipantCount)
        {
            CsvImportResult result = new CsvImportResult();
            if (string.IsNullOrWhiteSpace(csv))
            {
                result.Errors.Add("Plik CSV jest pusty.");
                result.SkippedCount = 1;
                return result;
            }

            string[] lines = csv.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            result.TotalLines = lines.Length;
            if (lines.Length == 0 || string.IsNullOrWhiteSpace(lines[0]))
            {
                result.Errors.Add("Brak naglowka CSV. Oczekiwany naglowek: " + ExpectedHeader);
                result.SkippedCount = 1;
                return result;
            }

            string header = lines[0].Trim().TrimStart('\uFEFF');
            if (header != ExpectedHeader)
            {
                result.Errors.Add("Nieprawidlowy naglowek. Oczekiwany: " + ExpectedHeader);
                result.SkippedCount = 1;
                return result;
            }

            HashSet<string> existingNicks = new HashSet<string>(
                (tournament == null || tournament.participants == null)
                    ? Enumerable.Empty<string>()
                    : tournament.participants.Select(participant => participant.displayName),
                System.StringComparer.OrdinalIgnoreCase
            );

            HashSet<int> existingSeeds = new HashSet<int>(
                (tournament == null || tournament.participants == null)
                    ? Enumerable.Empty<int>()
                    : tournament.participants.Select(participant => participant.seed)
            );

            HashSet<string> importedNicks = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            HashSet<int> importedSeeds = new HashSet<int>();
            int existingCount = tournament == null || tournament.participants == null ? 0 : tournament.participants.Count;
            int fileOrder = 0;

            for (int i = 1; i < lines.Length; i++)
            {
                string rawLine = lines[i];
                if (string.IsNullOrWhiteSpace(rawLine))
                {
                    continue;
                }

                fileOrder++;
                int lineNumber = i + 1;
                string[] values = rawLine.Split(';');
                string nick = GetValue(values, 0).Trim();
                string rank = GetValue(values, 1).Trim();
                string seedText = GetValue(values, 2).Trim();
                string team = GetValue(values, 3).Trim();
                string country = GetValue(values, 4).Trim();

                if (string.IsNullOrWhiteSpace(country))
                {
                    country = "PL";
                }

                if (string.IsNullOrWhiteSpace(nick))
                {
                    result.Errors.Add("Linia " + lineNumber + ": pusty nick.");
                    continue;
                }

                if (existingNicks.Contains(nick))
                {
                    result.Errors.Add("Linia " + lineNumber + ": nick \"" + nick + "\" juz istnieje na liscie uczestnikow.");
                    continue;
                }

                if (!importedNicks.Add(nick))
                {
                    result.Errors.Add("Linia " + lineNumber + ": nick \"" + nick + "\" wystepuje wiecej niz raz.");
                    continue;
                }

                int seed;
                if (string.IsNullOrWhiteSpace(seedText))
                {
                    seed = existingCount + fileOrder;
                }
                else if (!int.TryParse(seedText, out seed))
                {
                    result.Errors.Add("Linia " + lineNumber + ": seed \"" + seedText + "\" nie jest liczba.");
                    continue;
                }

                if (existingSeeds.Contains(seed))
                {
                    result.Errors.Add("Linia " + lineNumber + ": seed " + seed + " jest juz uzyty przez istniejacego uczestnika.");
                    continue;
                }

                if (!importedSeeds.Add(seed))
                {
                    result.Errors.Add("Linia " + lineNumber + ": seed " + seed + " jest uzyty wiecej niz raz.");
                    continue;
                }

                result.Players.Add(new ImportedPlayer
                {
                    Nick = nick,
                    Rank = rank,
                    Seed = seed,
                    Team = team,
                    Country = country
                });
            }

            int target = Mathf.Max(2, targetParticipantCount);
            if (existingCount + result.Players.Count > target)
            {
                result.Errors.Add("Import przekracza limit uczestnikow: " + (existingCount + result.Players.Count) + " / " + target + ".");
            }

            result.ImportedCount = result.Players.Count;
            result.SkippedCount = result.Errors.Count;
            result.Success = result.Errors.Count == 0 && result.Players.Count > 0;
            if (result.Players.Count == 0 && result.Errors.Count == 0)
            {
                result.Errors.Add("Brak zawodnikow do importu.");
                result.SkippedCount = 1;
            }

            return result;
        }

        private string GetValue(string[] values, int index)
        {
            if (values == null || index < 0 || index >= values.Length)
            {
                return string.Empty;
            }

            return values[index] ?? string.Empty;
        }
    }
}
