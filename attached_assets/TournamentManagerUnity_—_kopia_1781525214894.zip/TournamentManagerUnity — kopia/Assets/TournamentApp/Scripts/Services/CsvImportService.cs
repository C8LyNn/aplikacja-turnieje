using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;

namespace TournamentApp.Services
{
    public class CsvImportService
    {
        public List<Participant> ImportParticipants(string csv)
        {
            List<Participant> participants = new List<Participant>();
            if (string.IsNullOrWhiteSpace(csv)) return participants;

            string[] lines = csv.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            if (lines.Length < 2) return participants;

            List<string> headers = SplitCsvLine(lines[0]).Select(value => value.Trim().ToLowerInvariant()).ToList();
            for (int i = 1; i < lines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(lines[i])) continue;
                List<string> values = SplitCsvLine(lines[i]);
                Participant participant = Participant.Create(GetValue(headers, values, "nick", "Player " + i), participants.Count + 1);
                participant.rankName = GetValue(headers, values, "ranga", string.Empty);
                participant.country = GetValue(headers, values, "kraj", string.Empty);
                participant.teamId = GetValue(headers, values, "druzyna", string.Empty);

                int seed;
                if (int.TryParse(GetValue(headers, values, "seed", string.Empty), out seed))
                {
                    participant.seed = seed;
                }

                for (int h = 0; h < headers.Count; h++)
                {
                    string header = headers[h];
                    if (header == "nick" || header == "ranga" || header == "seed" || header == "druzyna" || header == "kraj")
                    {
                        continue;
                    }

                    if (h < values.Count)
                    {
                        participant.customFields.Add(new CustomFieldEntry { key = header, value = values[h] });
                    }
                }

                participants.Add(participant);
            }

            return participants;
        }

        private string GetValue(List<string> headers, List<string> values, string key, string fallback)
        {
            int index = headers.IndexOf(key);
            if (index < 0 || index >= values.Count) return fallback;
            return values[index];
        }

        private List<string> SplitCsvLine(string line)
        {
            List<string> values = new List<string>();
            if (line == null) return values;

            bool inQuotes = false;
            string current = string.Empty;
            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                    {
                        current += '"';
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    values.Add(current);
                    current = string.Empty;
                }
                else
                {
                    current += c;
                }
            }

            values.Add(current);
            return values;
        }
    }
}
