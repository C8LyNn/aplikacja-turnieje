using System.Collections.Generic;
using System.IO;
using System.Linq;
using TournamentApp.Core;
using UnityEngine;

namespace TournamentApp.Services
{
    public class TemplateService
    {
        public string TemplateDirectory => Path.Combine(Application.persistentDataPath, "TournamentApp", "Templates");

        public string SaveTemplate(TournamentTemplate template)
        {
            Directory.CreateDirectory(TemplateDirectory);
            if (string.IsNullOrEmpty(template.id))
            {
                template.id = TournamentIds.NewId("template");
            }

            string path = Path.Combine(TemplateDirectory, template.name.Replace(' ', '_') + ".json");
            File.WriteAllText(path, JsonUtility.ToJson(template, true));
            return path;
        }

        public TournamentTemplate LoadTemplate(string path)
        {
            if (!File.Exists(path)) return null;
            return JsonUtility.FromJson<TournamentTemplate>(File.ReadAllText(path));
        }

        public List<string> GetTemplates()
        {
            Directory.CreateDirectory(TemplateDirectory);
            return Directory.GetFiles(TemplateDirectory, "*.json").OrderBy(Path.GetFileName).ToList();
        }

        public void EnsureDefaultTemplates()
        {
            Directory.CreateDirectory(TemplateDirectory);
            if (GetTemplates().Count > 0) return;
            SaveTemplate(CreateTemplate("Swiss 5 rund + TOP 8", TournamentFormatType.SwissToBracket, 5, 8, 1));
            SaveTemplate(CreateTemplate("Single Elimination BO3", TournamentFormatType.SingleElimination, 0, 0, 3));
            SaveTemplate(CreateTemplate("Turniej 1v1 szybki", TournamentFormatType.SingleElimination, 0, 0, 1));
            SaveTemplate(CreateTemplate("Turniej drużynowy 4v4", TournamentFormatType.Swiss, 4, 0, 1));
        }

        private TournamentTemplate CreateTemplate(string name, TournamentFormatType format, int swissRounds, int topX, int bestOf)
        {
            TournamentSettings settings = TournamentSettings.CreateDefault();
            settings.tournamentName = name;
            settings.formatType = format;
            settings.swissRoundCount = swissRounds > 0 ? swissRounds : settings.swissRoundCount;
            settings.advanceTopXToBracket = topX > 0 ? topX : settings.advanceTopXToBracket;
            settings.bestOf = bestOf;
            return new TournamentTemplate
            {
                id = TournamentIds.NewId("template"),
                name = name,
                settings = settings,
                visualSettings = TournamentVisualSettings.CreateDefault()
            };
        }
    }
}
