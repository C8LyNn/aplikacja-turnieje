using System;
using System.Collections.Generic;
using System.Linq;
using TournamentApp.Core;
using TournamentApp.Formats;
using UnityEngine;

namespace TournamentApp.Services
{
    public class TournamentManager : MonoBehaviour
    {
        public Tournament CurrentTournament { get; private set; }
        public string LastMessage { get; private set; }
        public string LastSaveInfo { get; private set; } = "Ostatni zapis: brak";
        public string LastCsvImportSummary { get; private set; } = string.Empty;
        public List<ValidationMessage> LastValidationMessages { get; private set; } = new List<ValidationMessage>();
        public string HeldBracketParticipantId { get; private set; }

        public event Action TournamentChanged;

        private readonly AuditLogService auditLogService = new AuditLogService();
        private readonly ResultHistoryService resultHistoryService = new ResultHistoryService();
        private readonly StandingsService standingsService = new StandingsService();
        private readonly SaveLoadService saveLoadService = new SaveLoadService();
        private readonly BackupService backupService = new BackupService();
        private readonly ExportService exportService = new ExportService();
        private readonly MatchScheduleService scheduleService = new MatchScheduleService();
        private readonly BroadcastStateService broadcastStateService = new BroadcastStateService();
        private readonly CsvImportService csvImportService = new CsvImportService();
        private readonly CsvPlayerImporter csvPlayerImporter = new CsvPlayerImporter();
        private readonly ValidationService validationService = new ValidationService();
        private AutosaveService autosaveService;

        public SaveLoadService SaveLoad => saveLoadService;
        public BackupService Backups => backupService;
        public ExportService Exports => exportService;
        public MatchScheduleService Schedule => scheduleService;
        public ResultHistoryService Results => resultHistoryService;
        public StandingsService Standings => standingsService;

        private void Awake()
        {
            autosaveService = new AutosaveService(saveLoadService);
        }

        private void Update()
        {
            EnsureInitialized();
            autosaveService?.Tick(CurrentTournament);
        }

        public Tournament CreateNewTournament(TournamentSettings settings)
        {
            EnsureInitialized();
            CurrentTournament = Tournament.CreateNew(settings, TournamentVisualSettings.CreateDefault());
            auditLogService.Add(CurrentTournament, AuditActionType.TournamentLoaded, "Utworzono nowy turniej.");
            SetMessage("Utworzono turniej.");
            NotifyChanged(AppViewMode.Admin);
            return CurrentTournament;
        }

        public void AddParticipant(string nickname, string rankName, int seed, string teamName, string country)
        {
            if (CurrentTournament == null)
            {
                CreateNewTournament(TournamentSettings.CreateDefault());
            }

            if (string.IsNullOrWhiteSpace(nickname))
            {
                SetMessage("Nick uczestnika jest wymagany.");
                return;
            }

            int finalSeed = seed > 0 ? seed : CurrentTournament.participants.Count + 1;
            Participant participant = Participant.Create(nickname.Trim(), finalSeed);
            participant.rankName = rankName ?? string.Empty;
            participant.teamId = teamName ?? string.Empty;
            participant.country = country ?? string.Empty;
            CurrentTournament.participants.Add(participant);
            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantAdded, "Dodano uczestnika: " + participant.displayName, relatedParticipantId: participant.id);
            SetMessage("Dodano: " + participant.displayName + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void ImportParticipantsFromCsv(string csv)
        {
            if (CurrentTournament == null)
            {
                CreateNewTournament(TournamentSettings.CreateDefault());
            }

            List<Participant> imported = csvImportService.ImportParticipants(csv);
            foreach (Participant participant in imported)
            {
                CurrentTournament.participants.Add(participant);
                auditLogService.Add(CurrentTournament, AuditActionType.ParticipantAdded, "Zaimportowano uczestnika: " + participant.displayName, relatedParticipantId: participant.id);
            }

            SetMessage("Zaimportowano uczestnikow: " + imported.Count + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public string GetCsvImportProjectPath()
        {
            return CsvPlayerImporter.RelativeProjectPath;
        }

        public string GetCsvImportFilePath()
        {
            return csvPlayerImporter.GetDefaultFilePath();
        }

        public void OpenCsvImportFolder()
        {
            string folder = System.IO.Path.GetDirectoryName(GetCsvImportFilePath());
            if (string.IsNullOrWhiteSpace(folder))
            {
                SetMessage("Nie udalo sie ustalic folderu importu.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            try
            {
                System.IO.Directory.CreateDirectory(folder);
                Application.OpenURL("file:///" + folder.Replace("\\", "/"));
                SetMessage("Folder importu: " + folder);
            }
            catch (System.Exception exception)
            {
                SetMessage("Folder importu: " + folder + " (" + exception.Message + ")");
            }

            NotifyChanged(AppViewMode.Admin);
        }

        public bool ImportPlayersFromDefaultCsv(int targetParticipantCount)
        {
            EnsureInitialized();
            if (CurrentTournament == null)
            {
                CreateNewTournament(TournamentSettings.CreateDefault());
            }

            CsvImportResult result = csvPlayerImporter.ImportFromDefaultFile(CurrentTournament, targetParticipantCount);
            if (!result.Success)
            {
                LastCsvImportSummary = result.BuildSummary(CurrentTournament.participants.Count, targetParticipantCount);
                SetMessage("Import nieudany. Sprawdz panel importu CSV.");
                NotifyChanged(AppViewMode.Admin);
                return false;
            }

            if (CurrentTournament.participants.Count > 0)
            {
                string backupPath = backupService.CreateBackup(CurrentTournament, "before_csv_import");
                auditLogService.Add(CurrentTournament, AuditActionType.BackupCreated, "Snapshot przed importem CSV.", newValue: backupPath);
            }

            foreach (ImportedPlayer imported in result.Players)
            {
                Participant participant = Participant.Create(imported.Nick, imported.Seed);
                participant.rankName = imported.Rank ?? string.Empty;
                participant.teamId = imported.Team ?? string.Empty;
                participant.country = string.IsNullOrWhiteSpace(imported.Country) ? "PL" : imported.Country;
                CurrentTournament.participants.Add(participant);
                auditLogService.Add(CurrentTournament, AuditActionType.ParticipantAdded, "Zaimportowano uczestnika z CSV: " + participant.displayName, relatedParticipantId: participant.id);
            }

            LastCsvImportSummary = result.BuildSummary(CurrentTournament.participants.Count, targetParticipantCount);
            SetMessage("Import zakonczony. Wczytano zawodnikow: " + result.ImportedCount + ".");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public void ClearParticipantsInSetup()
        {
            EnsureInitialized();
            if (CurrentTournament == null || CurrentTournament.status != TournamentStatus.Setup)
            {
                SetMessage("Liste uczestnikow mozna wyczyscic tylko przed startem turnieju.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            int count = CurrentTournament.participants.Count;
            CurrentTournament.participants.Clear();
            LastCsvImportSummary = string.Empty;
            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantRemoved, "Wyczyszczono liste uczestnikow. Usunieto: " + count + ".");
            SetMessage("Wyczyszczono liste uczestnikow.");
            NotifyChanged(AppViewMode.Admin);
        }

        public void RemoveParticipant(string participantId)
        {
            if (CurrentTournament == null) return;
            Participant participant = TournamentLookup.Participant(CurrentTournament, participantId);
            if (participant == null) return;

            if (CurrentTournament.status != TournamentStatus.Setup)
            {
                participant.isDropped = true;
                auditLogService.Add(CurrentTournament, AuditActionType.ParticipantEdited, "Uczestnik usuniety z aktywnej listy: " + participant.displayName, relatedParticipantId: participant.id);
            }
            else
            {
                CurrentTournament.participants.Remove(participant);
                auditLogService.Add(CurrentTournament, AuditActionType.ParticipantRemoved, "Usunieto uczestnika: " + participant.displayName, relatedParticipantId: participant.id);
            }

            NotifyChanged(AppViewMode.Admin);
        }

        public bool StartTournament()
        {
            EnsureInitialized();
            if (CurrentTournament == null) return false;
            LastValidationMessages = validationService.ValidateBeforeStart(CurrentTournament);
            if (validationService.HasBlockingMessages(LastValidationMessages))
            {
                SetMessage(LastValidationMessages[0].message);
                NotifyChanged(AppViewMode.Admin);
                return false;
            }

            string startBackupPath = backupService.CreateBackup(CurrentTournament, "before_start");
            auditLogService.Add(CurrentTournament, AuditActionType.BackupCreated, "Snapshot przed startem turnieju.", newValue: startBackupPath);

            CurrentTournament.phases.Clear();
            CurrentTournament.resultHistory.Clear();
            CurrentTournament.currentRoundIndex = 0;
            CurrentTournament.currentMatchId = string.Empty;
            CurrentTournament.featuredMatchId = string.Empty;

            ITournamentFormat format = TournamentFormatFactory.Create(CurrentTournament.settings.formatType);
            format.GenerateInitialPhase(CurrentTournament);
            if (CurrentTournament.status == TournamentStatus.Setup)
            {
                CurrentTournament.status = TournamentStatus.Running;
            }

            standingsService.RecalculateTournament(CurrentTournament);
            RecordAutomaticByes();
            SetFirstReadyMatchAsCurrent();
            auditLogService.Add(CurrentTournament, AuditActionType.RoundGenerated, "Wygenerowano pierwsza faze turnieju.");
            AutosaveAndMark();
            SetMessage("Turniej wystartowal.");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public bool SubmitMatchResult(string matchId, int scoreA, int scoreB)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return false;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            LastValidationMessages = validationService.ValidateResult(CurrentTournament, match, scoreA, scoreB);
            if (validationService.HasBlockingMessages(LastValidationMessages))
            {
                SetMessage(LastValidationMessages[0].message);
                NotifyChanged(AppViewMode.Admin);
                return false;
            }

            bool wasFinished = match.IsFinished();
            string oldValue = match.scoreA + "-" + match.scoreB + " " + match.winnerId;
            ITournamentFormat format = TournamentFormatFactory.Create(CurrentTournament.settings.formatType);
            format.ApplyMatchResult(CurrentTournament, match, scoreA, scoreB);
            resultHistoryService.SaveResultRecord(CurrentTournament, match);
            standingsService.RecalculateTournament(CurrentTournament);
            SetFirstReadyMatchAsCurrent();

            auditLogService.Add(
                CurrentTournament,
                wasFinished ? AuditActionType.MatchResultEdited : AuditActionType.MatchResultEntered,
                (wasFinished ? "Edytowano wynik: " : "Wpisano wynik: ") + match.displayName,
                relatedMatchId: match.id,
                oldValue: oldValue,
                newValue: match.scoreA + "-" + match.scoreB + " " + match.winnerId);

            AutosaveAndMark();
            string resultBackupPath = backupService.CreateBackup(CurrentTournament, "after_result_saved");
            auditLogService.Add(CurrentTournament, AuditActionType.BackupCreated, "Snapshot po zapisaniu wyniku.", relatedMatchId: match.id, newValue: resultBackupPath);
            SetMessage("Wynik zapisany.");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public bool RevertMatchResult(string matchId)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return false;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null || !match.IsFinished()) return false;

            string backupPath = backupService.CreateBackup(CurrentTournament, "before_result_revert");
            auditLogService.Add(CurrentTournament, AuditActionType.BackupCreated, "Snapshot przed cofnieciem wyniku.", relatedMatchId: match.id, newValue: backupPath);
            string oldValue = match.scoreA + "-" + match.scoreB + " " + match.winnerId;
            match.scoreA = 0;
            match.scoreB = 0;
            match.winnerId = string.Empty;
            match.loserId = string.Empty;
            match.status = match.HasBothParticipants() ? MatchStatus.Ready : MatchStatus.Pending;
            match.games.Clear();

            standingsService.RecalculateTournament(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.MatchResultReverted, "Cofnieto wynik: " + match.displayName, relatedMatchId: match.id, oldValue: oldValue);
            AutosaveAndMark();
            SetMessage("Wynik cofniety. Sprawdz kolejne mecze, jesli awans byl juz wpisany.");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public void AdjustMatchScore(string matchId, MatchSlot slot, int delta)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null || match.IsFinished()) return;

            int needed = match.bestOf <= 1 ? 1 : (match.bestOf / 2) + 1;
            if (slot == MatchSlot.A)
            {
                match.scoreA = Mathf.Clamp(match.scoreA + delta, 0, needed);
            }
            else
            {
                match.scoreB = Mathf.Clamp(match.scoreB + delta, 0, needed);
            }

            if (match.status == MatchStatus.Ready)
            {
                match.status = MatchStatus.Live;
            }

            SetMessage("Zmieniono wynik roboczy.");
            NotifyChanged(AppViewMode.Admin);
        }

        public bool SubmitCurrentMatchResult()
        {
            Match match = GetCurrentMatch();
            return match != null && SubmitMatchResult(match.id, match.scoreA, match.scoreB);
        }

        public void SelectNextPlayableMatch()
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;

            Match current = GetCurrentMatch();
            Match next = scheduleService
                .GetNextMatches(CurrentTournament, 100)
                .FirstOrDefault(match => current == null || match.id != current.id);

            if (next == null)
            {
                SetMessage("Brak nastepnego meczu gotowego do ustawienia.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            SetCurrentMatch(next.id);
            SetMessage("Ustawiono nastepny mecz.");
        }

        public void MarkMatchProblem(string matchId)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null) return;

            match.status = MatchStatus.ResultDisputed;
            auditLogService.Add(CurrentTournament, AuditActionType.MatchResultEdited, "Mecz oznaczony jako wymagajacy korekty.", relatedMatchId: match.id);
            AutosaveAndMark();
            SetMessage("Mecz oznaczony jako wymagajacy korekty.");
            NotifyChanged(AppViewMode.Admin);
        }

        public void AssignWalkover(string matchId, MatchSlot winnerSlot)
        {
            AssignWalkover(matchId, winnerSlot, "decyzja admina");
        }

        public void AssignWalkover(string matchId, MatchSlot winnerSlot, string reason)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null || !match.HasBothParticipants()) return;
            if (!CurrentTournament.settings.allowWalkovers)
            {
                SetMessage("Walkowery sa wylaczone w ustawieniach turnieju.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            int needed = match.bestOf <= 1 ? 1 : (match.bestOf / 2) + 1;
            int scoreA = winnerSlot == MatchSlot.A ? needed : 0;
            int scoreB = winnerSlot == MatchSlot.B ? needed : 0;
            if (SubmitMatchResult(matchId, scoreA, scoreB))
            {
                match.status = MatchStatus.Walkover;
                match.note = string.IsNullOrWhiteSpace(reason) ? "Walkower" : "Walkower: " + reason;
                resultHistoryService.SaveResultRecord(CurrentTournament, match);
                auditLogService.Add(CurrentTournament, AuditActionType.WalkoverAssigned, "Walkower ustawiony. Powod: " + (string.IsNullOrWhiteSpace(reason) ? "brak" : reason) + ".", relatedMatchId: match.id, relatedParticipantId: match.winnerId);
                AutosaveAndMark();
                SetMessage("Walkower ustawiony: " + (string.IsNullOrWhiteSpace(reason) ? "brak powodu" : reason) + ".");
                NotifyChanged(AppViewMode.Admin);
            }
        }

        public bool GenerateNextRound()
        {
            EnsureInitialized();
            if (CurrentTournament == null) return false;
            ITournamentFormat format = TournamentFormatFactory.Create(CurrentTournament.settings.formatType);
            if (!format.CanGenerateNextRound(CurrentTournament))
            {
                SetMessage("Nie mozna wygenerowac rundy. Najpierw zakoncz aktualne mecze albo ten format nie wymaga recznego generowania rund.");
                NotifyChanged(AppViewMode.Admin);
                return false;
            }

            string backupPath = backupService.CreateBackup(CurrentTournament, "before_next_round");
            auditLogService.Add(CurrentTournament, AuditActionType.BackupCreated, "Snapshot przed wygenerowaniem kolejnej rundy.", oldValue: string.Empty, newValue: backupPath);
            TournamentPhase phase = format.GenerateNextRound(CurrentTournament);
            standingsService.RecalculateTournament(CurrentTournament);
            RecordAutomaticByes();
            SetFirstReadyMatchAsCurrent();
            auditLogService.Add(CurrentTournament, AuditActionType.RoundGenerated, "Wygenerowano nastepna runde: " + (phase == null ? string.Empty : phase.name));
            AutosaveAndMark();
            SetMessage("Wygenerowano nastepna runde.");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public bool CanGenerateNextRound()
        {
            if (CurrentTournament == null) return false;
            ITournamentFormat format = TournamentFormatFactory.Create(CurrentTournament.settings.formatType);
            return format.CanGenerateNextRound(CurrentTournament);
        }

        public void SetCurrentMatch(string matchId)
        {
            if (CurrentTournament == null) return;
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null) return;

            if (match.status == MatchStatus.Ready || match.status == MatchStatus.Pending)
            {
                scheduleService.SetLiveMatch(CurrentTournament, matchId);
            }
            else
            {
                CurrentTournament.currentMatchId = matchId;
            }

            auditLogService.Add(CurrentTournament, AuditActionType.CurrentMatchChanged, "Zmieniono aktualny mecz: " + match.displayName, relatedMatchId: match.id);
            AutosaveAndMark();
            NotifyChanged(AppViewMode.Admin);
        }

        public void SetFeaturedMatch(string matchId)
        {
            if (CurrentTournament == null) return;
            scheduleService.SetFeaturedMatch(CurrentTournament, matchId);
            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            auditLogService.Add(CurrentTournament, AuditActionType.CurrentMatchChanged, "Zmieniono mecz wyróżniony.", relatedMatchId: match == null ? string.Empty : match.id);
            AutosaveAndMark();
            NotifyChanged(AppViewMode.Admin);
        }

        public void MoveMatch(string matchId, int delta)
        {
            if (CurrentTournament == null) return;
            scheduleService.MoveMatch(CurrentTournament, matchId, delta);
            auditLogService.Add(CurrentTournament, AuditActionType.MatchOrderChanged, "Zmieniono kolejnosc meczu.", relatedMatchId: matchId);
            AutosaveAndMark();
            NotifyChanged(AppViewMode.Admin);
        }

        public void ToggleBracketParticipantSlot(string matchId, MatchSlot slot)
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;

            Match match = TournamentLookup.Match(CurrentTournament, matchId);
            if (match == null) return;

            TournamentPhase phase = TournamentLookup.Phase(CurrentTournament, match.phaseId);
            if (phase == null) return;

            backupService.CreateBackup(CurrentTournament, "before_manual_bracket_edit");

            string slotParticipantId = GetSlotParticipant(match, slot);
            if (string.IsNullOrEmpty(HeldBracketParticipantId))
            {
                if (string.IsNullOrEmpty(slotParticipantId))
                {
                    SetMessage("Ten slot jest pusty.");
                    NotifyChanged(AppViewMode.Admin);
                    return;
                }

                HeldBracketParticipantId = slotParticipantId;
                SetSlotParticipant(match, slot, string.Empty);
                ResetMatchAndLinkedMatches(phase, match);
                RefreshManualBracketStates(phase);
                SetMessage("Neutralny slot: " + TournamentLookup.ParticipantName(CurrentTournament, HeldBracketParticipantId) + ".");
            }
            else
            {
                SetSlotParticipant(match, slot, HeldBracketParticipantId);
                HeldBracketParticipantId = slotParticipantId;
                ResetMatchAndLinkedMatches(phase, match);
                RefreshManualBracketStates(phase);

                if (string.IsNullOrEmpty(HeldBracketParticipantId))
                {
                    SetMessage("Gracz wstawiony do drabinki.");
                }
                else
                {
                    SetMessage("Zamieniono graczy. Neutralny slot: " + TournamentLookup.ParticipantName(CurrentTournament, HeldBracketParticipantId) + ".");
                }
            }

            standingsService.RecalculateTournament(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.MatchOrderChanged, "Recznie przeniesiono gracza w drabince.", relatedMatchId: match.id);
            AutosaveAndMark();
            NotifyChanged(AppViewMode.Admin);
        }

        public void ClearHeldBracketParticipant()
        {
            HeldBracketParticipantId = string.Empty;
            SetMessage("Neutralny slot wyczyszczony.");
            NotifyChanged(AppViewMode.Admin);
        }

        public List<string> GetCurrentBracketLobbyParticipantIds()
        {
            EnsureInitialized();
            List<string> lobby = new List<string>();
            if (CurrentTournament == null)
            {
                return lobby;
            }

            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            HashSet<string> assigned = GetAssignedParticipantIds(phase);

            foreach (Participant participant in CurrentTournament.participants)
            {
                if (participant == null || participant.isDropped || participant.isDisqualified)
                {
                    continue;
                }

                if (!assigned.Contains(participant.id))
                {
                    lobby.Add(participant.id);
                }
            }

            return lobby;
        }

        public List<string> GetDisqualifiedParticipantIds()
        {
            EnsureInitialized();
            List<string> disqualified = new List<string>();
            if (CurrentTournament == null)
            {
                return disqualified;
            }

            foreach (Participant participant in CurrentTournament.participants)
            {
                if (participant != null && participant.isDisqualified)
                {
                    disqualified.Add(participant.id);
                }
            }

            return disqualified;
        }

        public void MoveBracketParticipantToLobby(string participantId)
        {
            EnsureInitialized();
            if (CurrentTournament == null || string.IsNullOrEmpty(participantId)) return;

            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            if (phase == null) return;

            backupService.CreateBackup(CurrentTournament, "before_bracket_lobby_move");
            bool removed = RemoveParticipantFromPhase(phase, participantId);
            if (HeldBracketParticipantId == participantId)
            {
                HeldBracketParticipantId = string.Empty;
                removed = true;
            }

            if (!removed)
            {
                SetMessage("Ten gracz jest juz w lobby.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            RefreshAfterManualBracketChange(phase);
            auditLogService.Add(CurrentTournament, AuditActionType.MatchOrderChanged, "Przeniesiono gracza do lobby drabinki.", relatedParticipantId: participantId);
            SetMessage("Przeniesiono do lobby: " + TournamentLookup.ParticipantName(CurrentTournament, participantId) + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void MoveBracketParticipantToSlot(string participantId, string targetMatchId, MatchSlot targetSlot, string sourceMatchId = "", MatchSlot sourceSlot = MatchSlot.A)
        {
            EnsureInitialized();
            if (CurrentTournament == null || string.IsNullOrEmpty(participantId) || string.IsNullOrEmpty(targetMatchId)) return;

            Participant participant = TournamentLookup.Participant(CurrentTournament, participantId);
            if (participant == null || participant.isDisqualified || participant.isDropped)
            {
                SetMessage("Ten gracz nie moze zostac ustawiony w drabince.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            Match target = TournamentLookup.Match(phase, targetMatchId);
            if (phase == null || target == null) return;

            Match source = string.IsNullOrEmpty(sourceMatchId) ? null : TournamentLookup.Match(phase, sourceMatchId);
            MatchSlot actualSourceSlot = sourceSlot;
            if (source == null || GetSlotParticipant(source, sourceSlot) != participantId)
            {
                FindParticipantSlot(phase, participantId, out source, out actualSourceSlot);
            }

            if (source == target && actualSourceSlot == targetSlot)
            {
                SetMessage("Gracz jest już w tym slocie.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            backupService.CreateBackup(CurrentTournament, "before_bracket_slot_move");

            string replacedParticipantId = GetSlotParticipant(target, targetSlot);
            if (source != null)
            {
                SetSlotParticipant(source, actualSourceSlot, replacedParticipantId == participantId ? string.Empty : replacedParticipantId);
            }

            SetSlotParticipant(target, targetSlot, participantId);
            HeldBracketParticipantId = HeldBracketParticipantId == participantId ? string.Empty : HeldBracketParticipantId;

            if (source != null)
            {
                ResetMatchAndLinkedMatches(phase, source);
            }

            ResetMatchAndLinkedMatches(phase, target);
            RefreshAfterManualBracketChange(phase);

            auditLogService.Add(CurrentTournament, AuditActionType.MatchOrderChanged, "Przeniesiono gracza w drabince.", relatedMatchId: target.id, relatedParticipantId: participantId);
            SetMessage("Ustawiono gracza: " + TournamentLookup.ParticipantName(CurrentTournament, participantId) + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void DisqualifyParticipant(string participantId)
        {
            EnsureInitialized();
            if (CurrentTournament == null || string.IsNullOrEmpty(participantId)) return;

            Participant participant = TournamentLookup.Participant(CurrentTournament, participantId);
            if (participant == null) return;

            backupService.CreateBackup(CurrentTournament, "before_disqualification");
            participant.isDisqualified = true;
            participant.isDropped = true;

            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            if (phase != null)
            {
                RemoveParticipantFromPhase(phase, participantId);
                RefreshAfterManualBracketChange(phase);
            }

            if (HeldBracketParticipantId == participantId)
            {
                HeldBracketParticipantId = string.Empty;
            }

            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantEdited, "Zdyskwalifikowano uczestnika: " + participant.displayName, relatedParticipantId: participantId);
            AutosaveAndMark();
            SetMessage("Zdyskwalifikowano: " + participant.displayName + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void ReinstateParticipant(string participantId)
        {
            EnsureInitialized();
            if (CurrentTournament == null || string.IsNullOrEmpty(participantId)) return;

            Participant participant = TournamentLookup.Participant(CurrentTournament, participantId);
            if (participant == null) return;

            participant.isDisqualified = false;
            participant.isDropped = false;
            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantEdited, "Przywrocono uczestnika: " + participant.displayName, relatedParticipantId: participantId);
            AutosaveAndMark();
            SetMessage("Przywrocono do lobby: " + participant.displayName + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void RandomizeCurrentBracketParticipants()
        {
            EnsureInitialized();
            if (CurrentTournament == null) return;

            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            if (phase == null || phase.rounds == null || phase.rounds.Count == 0)
            {
                SetMessage("Brak drabinki do losowania.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            Round firstRound = phase.rounds[0];
            if (firstRound == null || firstRound.matches == null || firstRound.matches.Count == 0)
            {
                SetMessage("Brak pierwszej rundy do losowania.");
                NotifyChanged(AppViewMode.Admin);
                return;
            }

            backupService.CreateBackup(CurrentTournament, "before_bracket_reroll");

            HashSet<string> participantSet = new HashSet<string>();
            foreach (Match match in firstRound.matches)
            {
                if (!string.IsNullOrEmpty(match.participantAId)) participantSet.Add(match.participantAId);
                if (!string.IsNullOrEmpty(match.participantBId)) participantSet.Add(match.participantBId);
            }

            foreach (string lobbyParticipantId in GetCurrentBracketLobbyParticipantIds())
            {
                participantSet.Add(lobbyParticipantId);
            }

            if (!string.IsNullOrEmpty(HeldBracketParticipantId))
            {
                participantSet.Add(HeldBracketParticipantId);
                HeldBracketParticipantId = string.Empty;
            }

            List<string> participantIds = participantSet
                .Where(participantId =>
                {
                    Participant participant = TournamentLookup.Participant(CurrentTournament, participantId);
                    return participant != null && !participant.isDropped && !participant.isDisqualified;
                })
                .ToList();

            System.Random rng = CurrentTournament.useFixedRandomSeed
                ? new System.Random(CurrentTournament.randomSeed + Environment.TickCount)
                : new System.Random(Environment.TickCount);

            participantIds = participantIds.OrderBy(_ => rng.Next()).ToList();
            ResetFullBracket(phase);

            int index = 0;
            foreach (Match match in firstRound.matches)
            {
                match.participantAId = index < participantIds.Count ? participantIds[index++] : string.Empty;
                match.participantBId = index < participantIds.Count ? participantIds[index++] : string.Empty;
            }

            ResolveManualFirstRoundByes(phase);
            RefreshManualBracketStates(phase);
            CurrentTournament.resultHistory.RemoveAll(record => record.phaseId == phase.id);
            standingsService.RecalculateTournament(CurrentTournament);
            SetFirstReadyMatchAsCurrent();
            auditLogService.Add(CurrentTournament, AuditActionType.SeedChanged, "Ponownie wylosowano graczy w drabince.");
            AutosaveAndMark();
            SetMessage("Gracze w drabince zostali ponownie wylosowani.");
            NotifyChanged(AppViewMode.Admin);
        }

        public List<Standing> GetStandings()
        {
            return standingsService.GetStandings(CurrentTournament);
        }

        public Round GetCurrentRound()
        {
            TournamentPhase phase = TournamentLookup.CurrentPhase(CurrentTournament);
            if (phase == null) return null;
            return TournamentLookup.Round(phase, CurrentTournament.currentRoundIndex);
        }

        public Match GetCurrentMatch()
        {
            return TournamentLookup.Match(CurrentTournament, CurrentTournament == null ? string.Empty : CurrentTournament.currentMatchId);
        }

        public string SaveTournament()
        {
            EnsureInitialized();
            if (CurrentTournament == null) return string.Empty;
            string path = saveLoadService.SaveTournament(CurrentTournament);
            saveLoadService.SaveLastTournament(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.TournamentSaved, "Zapisano turniej.", newValue: path);
            autosaveService.MarkSavedNow();
            MarkSavedNow();
            SetMessage("Zapisano turniej: " + path);
            NotifyChanged(AppViewMode.Admin);
            return path;
        }

        public bool LoadLastTournament()
        {
            EnsureInitialized();
            Tournament loaded = saveLoadService.LoadLastTournament();
            if (loaded == null)
            {
                SetMessage("Nie znaleziono ostatniego zapisu turnieju.");
                NotifyChanged(AppViewMode.Admin);
                return false;
            }

            CurrentTournament = loaded;
            standingsService.RecalculateTournament(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.TournamentLoaded, "Wczytano ostatni turniej.");
            SetMessage("Wczytano ostatni turniej.");
            NotifyChanged(AppViewMode.Admin);
            return true;
        }

        public string ExportResultsCsv()
        {
            if (CurrentTournament == null) return string.Empty;
            string path = exportService.ExportResultsToCsv(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.ExportCreated, "Wyeksportowano wyniki CSV.", newValue: path);
            SetMessage("Wyniki wyeksportowane: " + path);
            NotifyChanged(AppViewMode.Admin);
            return path;
        }

        public string ExportStandingsCsv()
        {
            if (CurrentTournament == null) return string.Empty;
            string path = exportService.ExportStandingsToCsv(CurrentTournament);
            auditLogService.Add(CurrentTournament, AuditActionType.ExportCreated, "Wyeksportowano tabele CSV.", newValue: path);
            SetMessage("Tabela wyeksportowana: " + path);
            NotifyChanged(AppViewMode.Admin);
            return path;
        }

        public void GenerateTestParticipants(int count)
        {
            if (CurrentTournament == null)
            {
                CreateNewTournament(TournamentSettings.CreateDefault());
            }

            CurrentTournament.settings.participantCount = count;
            CurrentTournament.participants.Clear();
            string[] ranks = { "Bronze", "Silver", "Gold", "Platinum", "Diamond" };
            for (int i = 0; i < count; i++)
            {
                Participant participant = Participant.Create("Player " + (i + 1), i + 1);
                participant.rankName = ranks[i % ranks.Length];
                participant.rankValue = i % ranks.Length;
                participant.teamId = "Team " + ((i % 4) + 1);
                participant.country = "PL";
                CurrentTournament.participants.Add(participant);
            }

            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantAdded, "Wygenerowano testowych uczestnikow: " + count + ".");
            SetMessage("Wygenerowano testowych uczestnikow: " + count + ".");
            NotifyChanged(AppViewMode.Admin);
        }

        public void CreateDemoTournament(TournamentFormatType formatType, int count)
        {
            TournamentSettings settings = TournamentSettings.CreateDefault();
            settings.tournamentName = "Bear Pit Tournament";
            settings.formatType = formatType;
            settings.participantCount = count;
            settings.bestOf = 1;
            settings.earlyRoundBestOf = 1;
            settings.quarterFinalBestOf = 1;
            settings.semiFinalBestOf = 1;
            settings.finalBestOf = 1;
            settings.swissRoundCount = formatType == TournamentFormatType.Swiss ? 4 : settings.swissRoundCount;
            settings.advanceTopXToBracket = Mathf.Min(8, Mathf.Max(2, count));

            CreateNewTournament(settings);
            GenerateTestParticipants(count);
            auditLogService.Add(CurrentTournament, AuditActionType.ParticipantAdded, "Utworzono turniej demo: " + formatType + ", uczestnicy: " + count + ".");
            SetMessage("Utworzono turniej demo: " + count + " graczy.");
            NotifyChanged(AppViewMode.Admin);
        }

        public void RandomlyCompleteCurrentRound()
        {
            if (CurrentTournament == null) return;
            Round round = GetCurrentRound();
            if (round == null) return;

            System.Random rng = CurrentTournament.useFixedRandomSeed
                ? new System.Random(CurrentTournament.randomSeed + CurrentTournament.currentRoundIndex)
                : new System.Random(Environment.TickCount);

            List<Match> playable = round.matches.Where(match => match.HasBothParticipants() && !match.IsFinished()).ToList();
            foreach (Match match in playable)
            {
                bool aWins = rng.NextDouble() >= 0.5d;
                int needed = match.bestOf <= 1 ? 1 : (match.bestOf / 2) + 1;
                SubmitMatchResult(match.id, aWins ? needed : rng.Next(0, needed), aWins ? rng.Next(0, needed) : needed);
            }

            SetMessage("Testowo zasymulowano aktualna runde.");
            NotifyChanged(AppViewMode.Admin);
        }

        private string GetSlotParticipant(Match match, MatchSlot slot)
        {
            return slot == MatchSlot.A ? match.participantAId : match.participantBId;
        }

        private void SetSlotParticipant(Match match, MatchSlot slot, string participantId)
        {
            if (slot == MatchSlot.A)
            {
                match.participantAId = participantId;
            }
            else
            {
                match.participantBId = participantId;
            }
        }

        private HashSet<string> GetAssignedParticipantIds(TournamentPhase phase)
        {
            HashSet<string> assigned = new HashSet<string>();
            if (phase == null || phase.rounds == null)
            {
                return assigned;
            }

            foreach (Round round in phase.rounds)
            {
                if (round == null || round.matches == null)
                {
                    continue;
                }

                foreach (Match match in round.matches)
                {
                    if (match == null)
                    {
                        continue;
                    }

                    if (!string.IsNullOrEmpty(match.participantAId))
                    {
                        assigned.Add(match.participantAId);
                    }

                    if (!string.IsNullOrEmpty(match.participantBId))
                    {
                        assigned.Add(match.participantBId);
                    }
                }
            }

            return assigned;
        }

        private bool FindParticipantSlot(TournamentPhase phase, string participantId, out Match foundMatch, out MatchSlot foundSlot)
        {
            foundMatch = null;
            foundSlot = MatchSlot.A;
            if (phase == null || string.IsNullOrEmpty(participantId))
            {
                return false;
            }

            foreach (Round round in phase.rounds)
            {
                foreach (Match match in round.matches)
                {
                    if (match.participantAId == participantId)
                    {
                        foundMatch = match;
                        foundSlot = MatchSlot.A;
                        return true;
                    }

                    if (match.participantBId == participantId)
                    {
                        foundMatch = match;
                        foundSlot = MatchSlot.B;
                        return true;
                    }
                }
            }

            return false;
        }

        private bool RemoveParticipantFromPhase(TournamentPhase phase, string participantId)
        {
            bool removed = false;
            if (phase == null || string.IsNullOrEmpty(participantId))
            {
                return false;
            }

            foreach (Round round in phase.rounds)
            {
                foreach (Match match in round.matches)
                {
                    bool changed = false;
                    if (match.participantAId == participantId)
                    {
                        match.participantAId = string.Empty;
                        changed = true;
                    }

                    if (match.participantBId == participantId)
                    {
                        match.participantBId = string.Empty;
                        changed = true;
                    }

                    if (changed)
                    {
                        removed = true;
                        ResetMatchAndLinkedMatches(phase, match);
                    }
                }
            }

            return removed;
        }

        private void RefreshAfterManualBracketChange(TournamentPhase phase)
        {
            RefreshManualBracketStates(phase);
            standingsService.RecalculateTournament(CurrentTournament);
            SetFirstReadyMatchAsCurrent();
            AutosaveAndMark();
        }

        private void ResetFullBracket(TournamentPhase phase)
        {
            foreach (Round round in phase.rounds)
            {
                foreach (Match match in round.matches)
                {
                    if (round.roundIndex > 0)
                    {
                        match.participantAId = string.Empty;
                        match.participantBId = string.Empty;
                    }

                    ResetMatchState(match);
                }
            }
        }

        private void ResetMatchAndLinkedMatches(TournamentPhase phase, Match match)
        {
            if (phase == null || match == null) return;

            ResetMatchState(match);
            if (string.IsNullOrEmpty(match.bracketNextMatchId)) return;

            Match next = TournamentLookup.Match(phase, match.bracketNextMatchId);
            if (next == null) return;

            if (match.bracketNextSlot == MatchSlot.A)
            {
                next.participantAId = string.Empty;
            }
            else
            {
                next.participantBId = string.Empty;
            }

            ResetMatchAndLinkedMatches(phase, next);
        }

        private void ResetMatchState(Match match)
        {
            if (CurrentTournament != null)
            {
                CurrentTournament.resultHistory.RemoveAll(record => record.matchId == match.id);
            }

            match.scoreA = 0;
            match.scoreB = 0;
            match.winnerId = string.Empty;
            match.loserId = string.Empty;
            match.games.Clear();
            match.isBye = false;
            match.status = match.HasBothParticipants() ? MatchStatus.Ready : MatchStatus.Pending;
        }

        private void RefreshManualBracketStates(TournamentPhase phase)
        {
            if (phase == null) return;

            foreach (Round round in phase.rounds)
            {
                foreach (Match match in round.matches)
                {
                    if (match.IsFinished()) continue;
                    match.status = match.HasBothParticipants() ? MatchStatus.Ready : MatchStatus.Pending;
                }
            }
        }

        private void ResolveManualFirstRoundByes(TournamentPhase phase)
        {
            if (phase == null || phase.rounds == null || phase.rounds.Count == 0) return;

            Round firstRound = phase.rounds[0];
            foreach (Match match in firstRound.matches)
            {
                bool hasA = !string.IsNullOrEmpty(match.participantAId);
                bool hasB = !string.IsNullOrEmpty(match.participantBId);
                if (hasA == hasB) continue;

                match.status = MatchStatus.Bye;
                match.isBye = true;
                match.scoreA = hasA ? 1 : 0;
                match.scoreB = hasB ? 1 : 0;
                match.winnerId = hasA ? match.participantAId : match.participantBId;
                match.loserId = string.Empty;
                AdvanceManualWinner(phase, match);
            }
        }

        private void AdvanceManualWinner(TournamentPhase phase, Match completedMatch)
        {
            if (phase == null || completedMatch == null || string.IsNullOrEmpty(completedMatch.winnerId) || string.IsNullOrEmpty(completedMatch.bracketNextMatchId))
            {
                return;
            }

            Match next = TournamentLookup.Match(phase, completedMatch.bracketNextMatchId);
            if (next == null) return;

            if (completedMatch.bracketNextSlot == MatchSlot.A)
            {
                next.participantAId = completedMatch.winnerId;
            }
            else
            {
                next.participantBId = completedMatch.winnerId;
            }
        }

        public void UpdateBroadcast(AppViewMode viewMode)
        {
            broadcastStateService.UpdateBroadcastState(CurrentTournament, viewMode);
        }

        private void RecordAutomaticByes()
        {
            if (CurrentTournament == null) return;
            foreach (Match match in TournamentLookup.AllMatches(CurrentTournament).Where(match => match.status == MatchStatus.Bye))
            {
                if (CurrentTournament.resultHistory.Any(record => record.matchId == match.id))
                {
                    continue;
                }

                resultHistoryService.SaveResultRecord(CurrentTournament, match);
                auditLogService.Add(CurrentTournament, AuditActionType.ByeAssigned, "BYE assigned.", relatedMatchId: match.id, relatedParticipantId: match.winnerId);
            }

            standingsService.RecalculateTournament(CurrentTournament);
        }

        private void SetFirstReadyMatchAsCurrent()
        {
            if (CurrentTournament == null) return;
            Match current = TournamentLookup.Match(CurrentTournament, CurrentTournament.currentMatchId);
            if (current != null && !current.IsFinished()) return;

            Match next = scheduleService.GetNextMatches(CurrentTournament, 1).FirstOrDefault();
            if (next != null)
            {
                CurrentTournament.currentMatchId = next.id;
                CurrentTournament.currentPhaseId = next.phaseId;
                CurrentTournament.currentRoundIndex = next.roundIndex;
            }
        }

        private void EnsureInitialized()
        {
            if (autosaveService == null)
            {
                autosaveService = new AutosaveService(saveLoadService);
            }
        }

        private void AutosaveAndMark()
        {
            autosaveService.AutosaveNow(CurrentTournament);
            if (CurrentTournament != null && CurrentTournament.settings.enableAutosave)
            {
                MarkSavedNow();
            }
        }

        private void MarkSavedNow()
        {
            LastSaveInfo = "Ostatni zapis: " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void NotifyChanged(AppViewMode mode)
        {
            broadcastStateService.UpdateBroadcastState(CurrentTournament, mode);
            TournamentChanged?.Invoke();
        }

        public void SetMessage(string message)
        {
            LastMessage = message;
            Debug.Log("[TournamentApp] " + message);
        }
    }
}
