using TournamentApp.Core;

namespace TournamentApp.Customization
{
    public class HostCustomizationService
    {
        public void ApplyTheme(
            Tournament tournament,
            string primaryColor,
            string secondaryColor,
            string backgroundColor,
            string matchCardColor,
            LayoutMode layoutMode)
        {
            if (tournament == null) return;
            tournament.visualSettings.primaryColor = primaryColor;
            tournament.visualSettings.secondaryColor = secondaryColor;
            tournament.visualSettings.backgroundColor = backgroundColor;
            tournament.visualSettings.matchCardColor = matchCardColor;
            tournament.visualSettings.layoutMode = layoutMode;
            tournament.updatedAt = TournamentTime.Now();
        }

        public void SetPlayerCardVisibility(Tournament tournament, bool showRanks, bool showSeeds, bool showTeams)
        {
            if (tournament == null) return;
            tournament.visualSettings.showRanks = showRanks;
            tournament.visualSettings.showSeeds = showSeeds;
            tournament.visualSettings.showTeams = showTeams;
            tournament.updatedAt = TournamentTime.Now();
        }
    }
}
