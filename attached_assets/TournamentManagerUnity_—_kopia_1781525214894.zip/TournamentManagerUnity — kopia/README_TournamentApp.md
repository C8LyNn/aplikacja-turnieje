# Tournament Manager Unity MVP

Unity 2D application scaffold for running tournaments from a Canvas UI.

Open this folder as a Unity project:

`LOCAL_PATH_REDACTED\Desktop\TournamentManagerUnity`

If the scene is not generated yet, use:

`Tools/Tournament App/Create Basic Tournament Scene`

Runtime save folders are created under:

`Application.persistentDataPath/TournamentApp/`

