# Replit HTML prototypes v1

Recovered unchanged HTML prototypes from prior project files.

Contents:
- Evolution Vehicles v0.10.77
- Wheel v19 TDS 128
- Marble/Pinball v24 TDS 128
- Cards v8 physical deck manipulation

The archive mirrors the repository paths under artifacts/tournament-manager/public/prototypes/.
Replace the placeholder index.html files with these files without editing their contents.
